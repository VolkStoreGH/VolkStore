/**
 * Интеграция админ-панели с основным сайтом VolkStore
 * Этот скрипт обеспечивает взаимодействие между админ-панелью и основным сайтом
 */

// Объект для хранения данных сайта
const siteData = {
    games: [],
    categories: [],
    promoСodes: [],
    settings: {},
    reviews: []
};

// Функция для загрузки данных с сайта
function loadSiteData() {
    // В реальном проекте здесь был бы AJAX запрос к API
    // Для демонстрации используем локальное хранилище
    const savedGames = localStorage.getItem('volkstore_games');
    if (savedGames) {
        siteData.games = JSON.parse(savedGames);
    } else {
        // Загружаем начальные данные из DOM
        loadGamesFromDOM();
    }

    const savedCategories = localStorage.getItem('volkstore_categories');
    if (savedCategories) {
        siteData.categories = JSON.parse(savedCategories);
    } else {
        // Загружаем категории из DOM
        loadCategoriesFromDOM();
    }

    const savedPromoCodes = localStorage.getItem('volkstore_promo_codes');
    if (savedPromoCodes) {
        siteData.promoСodes = JSON.parse(savedPromoCodes);
    }

    const savedSettings = localStorage.getItem('volkstore_settings');
    if (savedSettings) {
        siteData.settings = JSON.parse(savedSettings);
    }
}

// Функция для извлечения данных об играх из DOM
function loadGamesFromDOM() {
    const gameCards = document.querySelectorAll('.game-card');
    
    gameCards.forEach(card => {
        const title = card.querySelector('.game-title').textContent;
        const genre = card.querySelector('.game-genre').textContent;
        const priceElement = card.querySelector('.game-price');
        const price = priceElement ? priceElement.textContent.replace(/[^\d]/g, '') : '0';
        const oldPriceElement = card.querySelector('.old-price');
        const oldPrice = oldPriceElement ? oldPriceElement.textContent.replace(/[^\d]/g, '') : '';
        const imageElement = card.querySelector('.game-image-container img');
        const image = imageElement ? imageElement.src : '';
        const ratingElement = card.querySelector('.rating span');
        const rating = ratingElement ? parseFloat(ratingElement.textContent.replace(/[()]/g, '')) : 5.0;
        const categories = card.dataset.categories ? card.dataset.categories.split(' ') : [];
        const platform = card.dataset.platform ? card.dataset.platform.split(' ') : [];
        const buyLink = card.querySelector('.buy-btn') ? card.querySelector('.buy-btn').href : '';
        const isNew = card.querySelector('.card-badge.new') !== null;
        const discountElement = card.querySelector('.discount-label');
        const discount = discountElement ? discountElement.textContent.replace(/[^\d]/g, '') : '0';
        
        const descriptionElement = card.querySelector('.overlay-content p');
        const description = descriptionElement ? descriptionElement.textContent : '';
        
        const featuresElements = card.querySelectorAll('.game-features span');
        const features = Array.from(featuresElements).map(el => el.textContent);
        
        const inStock = priceElement && !priceElement.textContent.includes('Нет в наличие');
        
        siteData.games.push({
            id: 'GAME-' + (siteData.games.length + 1).toString().padStart(3, '0'),
            title,
            genre,
            price: parseInt(price) || 0,
            oldPrice: parseInt(oldPrice) || 0,
            image,
            rating,
            categories,
            platform,
            buyLink,
            isNew,
            discount: parseInt(discount) || 0,
            description,
            features,
            inStock
        });
    });
    
    // Сохраняем в localStorage
    localStorage.setItem('volkstore_games', JSON.stringify(siteData.games));
}

// Функция для извлечения категорий из DOM
function loadCategoriesFromDOM() {
    const categoryButtons = document.querySelectorAll('.category-btn');
    
    categoryButtons.forEach(button => {
        const category = button.dataset.category;
        if (category && category !== 'all') {
            siteData.categories.push({
                id: category,
                name: button.textContent.trim()
            });
        }
    });
    
    // Сохраняем в localStorage
    localStorage.setItem('volkstore_categories', JSON.stringify(siteData.categories));
}

// Функция для сохранения данных на сайт
function saveSiteData() {
    // Сохраняем в localStorage
    localStorage.setItem('volkstore_games', JSON.stringify(siteData.games));
    localStorage.setItem('volkstore_categories', JSON.stringify(siteData.categories));
    localStorage.setItem('volkstore_promo_codes', JSON.stringify(siteData.promoСodes));
    localStorage.setItem('volkstore_settings', JSON.stringify(siteData.settings));
    
    // В реальном проекте здесь был бы AJAX запрос к API для сохранения на сервере
    
    // Обновляем DOM
    updateSiteDOM();
}

// Функция для обновления DOM сайта
function updateSiteDOM() {
    // В реальном проекте здесь был бы код для обновления DOM
    // Для демонстрации просто перезагружаем страницу
    if (window.location.pathname.includes('index.html')) {
        window.location.reload();
    }
}

// Функции для работы с играми
const gameManager = {
    // Получить все игры
    getAllGames() {
        return siteData.games;
    },
    
    // Получить игру по ID
    getGameById(id) {
        return siteData.games.find(game => game.id === id);
    },
    
    // Добавить новую игру
    addGame(game) {
        // Генерируем ID
        game.id = 'GAME-' + (siteData.games.length + 1).toString().padStart(3, '0');
        siteData.games.push(game);
        saveSiteData();
        return game;
    },
    
    // Обновить игру
    updateGame(id, updatedGame) {
        const index = siteData.games.findIndex(game => game.id === id);
        if (index !== -1) {
            siteData.games[index] = { ...siteData.games[index], ...updatedGame };
            saveSiteData();
            return siteData.games[index];
        }
        return null;
    },
    
    // Удалить игру
    deleteGame(id) {
        const index = siteData.games.findIndex(game => game.id === id);
        if (index !== -1) {
            siteData.games.splice(index, 1);
            saveSiteData();
            return true;
        }
        return false;
    }
};

// Функции для работы с категориями
const categoryManager = {
    // Получить все категории
    getAllCategories() {
        return siteData.categories;
    },
    
    // Добавить новую категорию
    addCategory(category) {
        siteData.categories.push(category);
        saveSiteData();
        return category;
    },
    
    // Обновить категорию
    updateCategory(id, updatedCategory) {
        const index = siteData.categories.findIndex(cat => cat.id === id);
        if (index !== -1) {
            siteData.categories[index] = { ...siteData.categories[index], ...updatedCategory };
            saveSiteData();
            return siteData.categories[index];
        }
        return null;
    },
    
    // Удалить категорию
    deleteCategory(id) {
        const index = siteData.categories.findIndex(cat => cat.id === id);
        if (index !== -1) {
            siteData.categories.splice(index, 1);
            saveSiteData();
            return true;
        }
        return false;
    }
};

// Функции для работы с промокодами
const promoCodeManager = {
    // Получить все промокоды
    getAllPromoCodes() {
        return siteData.promoСodes;
    },
    
    // Получить промокод по коду
    getPromoCodeByCode(code) {
        return siteData.promoСodes.find(promo => promo.code === code);
    },
    
    // Добавить новый промокод
    addPromoCode(promoCode) {
        siteData.promoСodes.push(promoCode);
        saveSiteData();
        return promoCode;
    },
    
    // Обновить промокод
    updatePromoCode(code, updatedPromoCode) {
        const index = siteData.promoСodes.findIndex(promo => promo.code === code);
        if (index !== -1) {
            siteData.promoСodes[index] = { ...siteData.promoСodes[index], ...updatedPromoCode };
            saveSiteData();
            return siteData.promoСodes[index];
        }
        return null;
    },
    
    // Удалить промокод
    deletePromoCode(code) {
        const index = siteData.promoСodes.findIndex(promo => promo.code === code);
        if (index !== -1) {
            siteData.promoСodes.splice(index, 1);
            saveSiteData();
            return true;
        }
        return false;
    }
};

// Функции для работы с настройками сайта
const settingsManager = {
    // Получить все настройки
    getAllSettings() {
        return siteData.settings;
    },
    
    // Обновить настройки
    updateSettings(updatedSettings) {
        siteData.settings = { ...siteData.settings, ...updatedSettings };
        saveSiteData();
        return siteData.settings;
    }
};

// Инициализация данных при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    loadSiteData();
    
    // Проверяем, находимся ли мы на странице админ-панели
    if (window.location.pathname.includes('admin-panel.html')) {
        initAdminPanel();
    }
});

// Инициализация админ-панели
function initAdminPanel() {
    // Заполняем таблицы данными
    populateGamesTable();
    populatePromoCodesTable();
    populateSettingsForm();
    
    // Добавляем обработчики событий для форм и кнопок
    setupEventListeners();
}

// Заполнение таблицы игр
function populateGamesTable() {
    const gamesTable = document.getElementById('games-tbody');
    if (!gamesTable) return;
    
    gamesTable.innerHTML = '';
    
    siteData.games.forEach(game => {
        const row = document.createElement('tr');
        row.className = 'draggable';
        row.setAttribute('draggable', 'true');
        row.dataset.id = game.id;
        
        row.innerHTML = `
            <td>${game.id}</td>
            <td><img src="${game.image}" alt="${game.title}" width="40"></td>
            <td>${game.title}</td>
            <td>${game.genre}</td>
            <td>${game.platform.join(', ')}</td>
            <td>₽${game.price.toLocaleString()}</td>
            <td>${game.discount}%</td>
            <td>${Math.floor(Math.random() * 100) + 10}+</td>
            <td><span class="status-badge ${game.inStock ? 'status-completed' : 'status-cancelled'}">${game.inStock ? 'Активна' : 'Неактивна'}</span></td>
            <td>
                <button class="action-btn tooltip" onclick="viewGame('${game.id}')">
                    <i class="fas fa-eye"></i>
                    <span class="tooltip-text">Просмотр</span>
                </button>
                <button class="action-btn tooltip" onclick="editGame('${game.id}')">
                    <i class="fas fa-edit"></i>
                    <span class="tooltip-text">Редактировать</span>
                </button>
                <button class="action-btn tooltip" onclick="confirmDelete('игру', '${game.id}')">
                    <i class="fas fa-trash"></i>
                    <span class="tooltip-text">Удалить</span>
                </button>
            </td>
        `;
        
        gamesTable.appendChild(row);
    });
}

// Заполнение таблицы промокодов
function populatePromoCodesTable() {
    const promoList = document.querySelector('.promo-list');
    if (!promoList) return;
    
    promoList.innerHTML = '';
    
    siteData.promoСodes.forEach(promo => {
        const promoCard = document.createElement('div');
        promoCard.className = 'promo-card';
        
        const statusClass = promo.active ? 'status-completed' : 
                           (promo.scheduled ? 'status-pending' : 'status-cancelled');
        const statusText = promo.active ? 'Активен' : 
                          (promo.scheduled ? 'Запланирован' : 'Истек');
        
        promoCard.innerHTML = `
            <span class="promo-status status-badge ${statusClass}">${statusText}</span>
            <div class="promo-header">
                <div class="promo-title">${promo.title}</div>
            </div>
            <div class="promo-code">
                <span>${promo.code}</span>
                <button class="promo-copy" onclick="copyToClipboard('${promo.code}')">
                    <i class="fas fa-copy"></i>
                </button>
            </div>
            <div class="promo-details">
                <div class="promo-detail">
                    <span class="promo-detail-label">Тип скидки</span>
                    <span class="promo-detail-value">${promo.type === 'percent' ? promo.value + '% от суммы' : '₽' + promo.value + ' фиксированная'}</span>
                </div>
                <div class="promo-detail">
                    <span class="promo-detail-label">Мин. сумма</span>
                    <span class="promo-detail-value">₽${promo.minAmount}</span>
                </div>
                <div class="promo-detail">
                    <span class="promo-detail-label">Макс. скидка</span>
                    <span class="promo-detail-value">${promo.maxDiscount ? '₽' + promo.maxDiscount : ''}</span>
                </div>
                <div class="promo-detail">
                    <span class="promo-detail-label">Использований</span>
                    <span class="promo-detail-value">${promo.usedCount} / ${promo.maxUses}</span>
                </div>
                <div class="promo-detail">
                    <span class="promo-detail-label">${promo.active ? 'Действует до' : (promo.scheduled ? 'Действует с' : 'Действовал до')}</span>
                    <span class="promo-detail-value">${promo.active ? promo.endDate : (promo.scheduled ? promo.startDate : promo.endDate)}</span>
                </div>
            </div>
            <div class="promo-actions">
                <button class="btn btn-outline" onclick="editPromoCode('${promo.code}')">
                    <i class="fas fa-edit"></i> Редактировать
                </button>
                <button class="btn btn-outline" onclick="${promo.active ? 'togglePromoStatus' : (promo.scheduled ? 'activatePromoNow' : 'renewPromoCode')}('${promo.code}')">
                    <i class="fas ${promo.active ? 'fa-pause' : (promo.scheduled ? 'fa-play' : 'fa-redo')}"></i> 
                    ${promo.active ? 'Приостановить' : (promo.scheduled ? 'Активировать сейчас' : 'Возобновить')}
                </button>
                <button class="btn btn-outline" onclick="confirmDelete('промокод', '${promo.code}')">
                    <i class="fas fa-trash"></i> Удалить
                </button>
            </div>
        `;
        
        promoList.appendChild(promoCard);
    });
}

// Заполнение формы настроек
function populateSettingsForm() {
    const storeNameInput = document.getElementById('store-name');
    const storeEmailInput = document.getElementById('store-email');
    const storePhoneInput = document.getElementById('store-phone');
    const steamCommissionInput = document.getElementById('steam-commission');
    const darkThemeSwitch = document.getElementById('dark-theme-switch');
    
    if (storeNameInput && siteData.settings.storeName) {
        storeNameInput.value = siteData.settings.storeName;
    }
    
    if (storeEmailInput && siteData.settings.storeEmail) {
        storeEmailInput.value = siteData.settings.storeEmail;
    }
    
    if (storePhoneInput && siteData.settings.storePhone) {
        storePhoneInput.value = siteData.settings.storePhone;
    }
    
    if (steamCommissionInput && siteData.settings.steamCommission) {
        steamCommissionInput.value = siteData.settings.steamCommission;
    }
    
    if (darkThemeSwitch && siteData.settings.darkTheme) {
        darkThemeSwitch.checked = siteData.settings.darkTheme;
        if (siteData.settings.darkTheme) {
            document.documentElement.setAttribute('data-theme', 'dark');
        }
    }
}

// Настройка обработчиков событий
function setupEventListeners() {
    // Обработчик для формы настроек
    const settingsForm = document.getElementById('settings-form');
    if (settingsForm) {
        settingsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveSettings();
        });
    }
    
    // Обработчик для переключателя темной темы
    const darkThemeSwitch = document.getElementById('dark-theme-switch');
    if (darkThemeSwitch) {
        darkThemeSwitch.addEventListener('change', function() {
            toggleDarkTheme(this.checked);
        });
    }
    
    // Обработчики для модальных окон добавления/редактирования игр и промокодов
    setupModalEventListeners();
}

// Настройка обработчиков событий для модальных окон
function setupModalEventListeners() {
    // Модальное окно добавления игры
    const addGameModal = document.getElementById('add-game-modal');
    if (addGameModal) {
        const addGameForm = document.getElementById('add-game-form');
        if (addGameForm) {
            addGameForm.addEventListener('submit', function(e) {
                e.preventDefault();
                addNewGame();
            });
        }
    }
    
    // Модальное окно добавления промокода
    const addPromoModal = document.getElementById('add-promo-modal');
    if (addPromoModal) {
        const addPromoForm = document.getElementById('add-promo-form');
        if (addPromoForm) {
            addPromoForm.addEventListener('submit', function(e) {
                e.preventDefault();
                addNewPromoCode();
            });
        }
    }
}

// Функция для сохранения настроек
function saveSettings() {
    const storeName = document.getElementById('store-name').value;
    const storeEmail = document.getElementById('store-email').value;
    const storePhone = document.getElementById('store-phone').value;
    const steamCommission = document.getElementById('steam-commission').value;
    const darkTheme = document.getElementById('dark-theme-switch').checked;
    
    const updatedSettings = {
        storeName,
        storeEmail,
        storePhone,
        steamCommission,
        darkTheme
    };
    
    settingsManager.updateSettings(updatedSettings);
    showNotification('Настройки успешно сохранены');
}

// Функция для переключения темной темы
function toggleDarkTheme(enabled) {
    if (enabled) {
        document.documentElement.setAttribute('data-theme', 'dark');
    } else {
        document.documentElement.removeAttribute('data-theme');
    }
    
    settingsManager.updateSettings({ darkTheme: enabled });
}

// Функция для добавления новой игры
function addNewGame() {
    const gameNameInput = document.getElementById('product-name');
    const gameCategoryInput = document.getElementById('product-category');
    const gamePriceInput = document.getElementById('product-price');
    const gameDiscountInput = document.getElementById('product-discount');
    const gameStatusInput = document.getElementById('product-status');
    const gameDescriptionInput = document.getElementById('product-description');
    
    if (!gameNameInput || !gameCategoryInput || !gamePriceInput) {
        showNotification('Ошибка: не все поля заполнены', 'error');
        return;
    }
    
    const newGame = {
        title: gameNameInput.value,
        genre: gameCategoryInput.value,
        price: parseInt(gamePriceInput.value) || 0,
        discount: parseInt(gameDiscountInput.value) || 0,
        inStock: gameStatusInput.value === 'active',
        description: gameDescriptionInput.value,
        image: 'https://via.placeholder.com/400x600',
        rating: 5.0,
        categories: [gameCategoryInput.value.toLowerCase()],
        platform: ['pc'],
        features: ['Новая игра'],
        isNew: true
    };
    
    gameManager.addGame(newGame);
    
    // Закрываем модальное окно
    closeModal('add-game-modal');
    
    // Обновляем таблицу игр
    populateGamesTable();
    
    showNotification('Игра успешно добавлена');
}

// Функция для редактирования игры
function editGame(id) {
    const game = gameManager.getGameById(id);
    if (!game) {
        showNotification('Игра не найдена', 'error');
        return;
    }
    
    // Заполняем форму редактирования
    document.getElementById('edit-game-id').value = game.id;
    document.getElementById('edit-game-name').value = game.title;
    document.getElementById('edit-game-category').value = game.genre;
    document.getElementById('edit-game-price').value = game.price;
    document.getElementById('edit-game-discount').value = game.discount;
    document.getElementById('edit-game-status').value = game.inStock ? 'active' : 'inactive';
    document.getElementById('edit-game-description').value = game.description;
    
    // Открываем модальное окно редактирования
    openModal('edit-game-modal');
}

// Функция для сохранения отредактированной игры
function saveEditedGame() {
    const gameId = document.getElementById('edit-game-id').value;
    const gameNameInput = document.getElementById('edit-game-name');
    const gameCategoryInput = document.getElementById('edit-game-category');
    const gamePriceInput = document.getElementById('edit-game-price');
    const gameDiscountInput = document.getElementById('edit-game-discount');
    const gameStatusInput = document.getElementById('edit-game-status');
    const gameDescriptionInput = document.getElementById('edit-game-description');
    
    if (!gameId || !gameNameInput || !gameCategoryInput || !gamePriceInput) {
        showNotification('Ошибка: не все поля заполнены', 'error');
        return;
    }
    
    const updatedGame = {
        title: gameNameInput.value,
        genre: gameCategoryInput.value,
        price: parseInt(gamePriceInput.value) || 0,
        discount: parseInt(gameDiscountInput.value) || 0,
        inStock: gameStatusInput.value === 'active',
        description: gameDescriptionInput.value
    };
    
    gameManager.updateGame(gameId, updatedGame);
    
    // Закрываем модальное окно
    closeModal('edit-game-modal');
    
    // Обновляем таблицу игр
    populateGamesTable();
    
    showNotification('Игра успешно обновлена');
}

// Функция для добавления нового промокода
function addNewPromoCode() {
    const promoTitleInput = document.getElementById('promo-title');
    const promoCodeInput = document.getElementById('promo-code');
    const promoTypeInput = document.getElementById('promo-type');
    const promoValueInput = document.getElementById('promo-value');
    const promoMinAmountInput = document.getElementById('promo-min-amount');
    const promoMaxDiscountInput = document.getElementById('promo-max-discount');
    const promoMaxUsesInput = document.getElementById('promo-max-uses');
    const promoStartDateInput = document.getElementById('promo-start-date');
    const promoEndDateInput = document.getElementById('promo-end-date');
    const promoStatusInput = document.getElementById('promo-status');
    
    if (!promoTitleInput || !promoCodeInput || !promoTypeInput || !promoValueInput) {
        showNotification('Ошибка: не все поля заполнены', 'error');
        return;
    }
    
    const newPromoCode = {
        title: promoTitleInput.value,
        code: promoCodeInput.value,
        type: promoTypeInput.value,
        value: parseInt(promoValueInput.value) || 0,
        minAmount: parseInt(promoMinAmountInput.value) || 0,
        maxDiscount: parseInt(promoMaxDiscountInput.value) || 0,
        maxUses: parseInt(promoMaxUsesInput.value) || 100,
        usedCount: 0,
        startDate: promoStartDateInput.value,
        endDate: promoEndDateInput.value,
        active: promoStatusInput.value === 'active',
        scheduled: promoStatusInput.value === 'scheduled'
    };
    
    promoCodeManager.addPromoCode(newPromoCode);
    
    // Закрываем модальное окно
    closeModal('add-promo-modal');
    
    // Обновляем список промокодов
    populatePromoCodesTable();
    
    showNotification('Промокод успешно добавлен');
}

// Функция для редактирования промокода
function editPromoCode(code) {
    const promo = promoCodeManager.getPromoCodeByCode(code);
    if (!promo) {
        showNotification('Промокод не найден', 'error');
        return;
    }
    
    // Заполняем форму редактирования
    document.getElementById('edit-promo-title').value = promo.title;
    document.getElementById('edit-promo-code').value = promo.code;
    document.getElementById('edit-promo-type').value = promo.type;
    document.getElementById('edit-promo-value').value = promo.value;
    document.getElementById('edit-promo-min-amount').value = promo.minAmount;
    document.getElementById('edit-promo-max-discount').value = promo.maxDiscount;
    document.getElementById('edit-promo-max-uses').value = promo.maxUses;
    document.getElementById('edit-promo-start-date').value = promo.startDate;
    document.getElementById('edit-promo-end-date').value = promo.endDate;
    
    if (promo.active) {
        document.getElementById('edit-promo-status').value = 'active';
    } else if (promo.scheduled) {
        document.getElementById('edit-promo-status').value = 'scheduled';
    } else {
        document.getElementById('edit-promo-status').value = 'expired';
    }
    
    // Открываем модальное окно редактирования
    openModal('edit-promo-modal');
}

// Функция для сохранения отредактированного промокода
function saveEditedPromoCode() {
    const originalCode = document.getElementById('edit-promo-code').value;
    const promoTitleInput = document.getElementById('edit-promo-title');
    const promoTypeInput = document.getElementById('edit-promo-type');
    const promoValueInput = document.getElementById('edit-promo-value');
    const promoMinAmountInput = document.getElementById('edit-promo-min-amount');
    const promoMaxDiscountInput = document.getElementById('edit-promo-max-discount');
    const promoMaxUsesInput = document.getElementById('edit-promo-max-uses');
    const promoStartDateInput = document.getElementById('edit-promo-start-date');
    const promoEndDateInput = document.getElementById('edit-promo-end-date');
    const promoStatusInput = document.getElementById('edit-promo-status');
    
    if (!originalCode || !promoTitleInput || !promoTypeInput || !promoValueInput) {
        showNotification('Ошибка: не все поля заполнены', 'error');
        return;
    }
    
    const updatedPromoCode = {
        title: promoTitleInput.value,
        type: promoTypeInput.value,
        value: parseInt(promoValueInput.value) || 0,
        minAmount: parseInt(promoMinAmountInput.value) || 0,
        maxDiscount: parseInt(promoMaxDiscountInput.value) || 0,
        maxUses: parseInt(promoMaxUsesInput.value) || 100,
        startDate: promoStartDateInput.value,
        endDate: promoEndDateInput.value,
        active: promoStatusInput.value === 'active',
        scheduled: promoStatusInput.value === 'scheduled'
    };
    
    promoCodeManager.updatePromoCode(originalCode, updatedPromoCode);
    
    // Закрываем модальное окно
    closeModal('edit-promo-modal');
    
    // Обновляем список промокодов
    populatePromoCodesTable();
    
    showNotification('Промокод успешно обновлен');
}

// Функция для изменения статуса промокода
function togglePromoStatus(code) {
    const promo = promoCodeManager.getPromoCodeByCode(code);
    if (!promo) {
        showNotification('Промокод не найден', 'error');
        return;
    }
    
    const updatedPromo = {
        active: !promo.active,
        scheduled: false
    };
    
    promoCodeManager.updatePromoCode(code, updatedPromo);
    
    // Обновляем список промокодов
    populatePromoCodesTable();
    
    showNotification(`Промокод ${promo.active ? 'приостановлен' : 'активирован'}`);
}

// Функция для активации запланированного промокода
function activatePromoNow(code) {
    const promo = promoCodeManager.getPromoCodeByCode(code);
    if (!promo) {
        showNotification('Промокод не найден', 'error');
        return;
    }
    
    const updatedPromo = {
        active: true,
        scheduled: false
    };
    
    promoCodeManager.updatePromoCode(code, updatedPromo);
    
    // Обновляем список промокодов
    populatePromoCodesTable();
    
    showNotification('Промокод активирован');
}

// Функция для возобновления истекшего промокода
function renewPromoCode(code) {
    const promo = promoCodeManager.getPromoCodeByCode(code);
    if (!promo) {
        showNotification('Промокод не найден', 'error');
        return;
    }
    
    // Устанавливаем новую дату окончания (текущая дата + 30 дней)
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + 30);
    
    const updatedPromo = {
        active: true,
        scheduled: false,
        endDate: endDate.toISOString().split('T')[0]
    };
    
    promoCodeManager.updatePromoCode(code, updatedPromo);
    
    // Обновляем список промокодов
    populatePromoCodesTable();
    
    showNotification('Промокод возобновлен');
}

// Функция для удаления элемента (игры или промокода)
function confirmDelete(type, id) {
    if (confirm(`Вы уверены, что хотите удалить ${type} ${id}?`)) {
        if (type === 'игру') {
            gameManager.deleteGame(id);
            populateGamesTable();
        } else if (type === 'промокод') {
            promoCodeManager.deletePromoCode(id);
            populatePromoCodesTable();
        }
        
        showNotification(`${type} ${id} успешно удален(а)`);
    }
}

// Вспомогательные функции
function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    const notificationMessage = document.getElementById('notification-message');
    
    notificationMessage.textContent = message;
    
    // Установить цвет в зависимости от типа
    if (type === 'error') {
        notification.style.backgroundColor = 'var(--danger-color)';
    } else if (type === 'info') {
        notification.style.backgroundColor = 'var(--info-color)';
    } else {
        notification.style.backgroundColor = 'var(--success-color)';
    }
    
    notification.classList.add('show');
    
    // Автоматически скрыть уведомление через 3 секунды
    setTimeout(() => {
        hideNotification();
    }, 3000);
}

function hideNotification() {
    const notification = document.getElementById('notification');
    notification.classList.remove('show');
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
    }
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showNotification('Скопировано в буфер обмена');
    }).catch(err => {
        showNotification('Не удалось скопировать текст', 'error');
    });
}

// Экспортируем функции для использования в других скриптах
window.gameManager = gameManager;
window.categoryManager = categoryManager;
window.promoCodeManager = promoCodeManager;
window.settingsManager = settingsManager;
window.editGame = editGame;
window.saveEditedGame = saveEditedGame;
window.editPromoCode = editPromoCode;
window.saveEditedPromoCode = saveEditedPromoCode;
window.togglePromoStatus = togglePromoStatus;
window.activatePromoNow = activatePromoNow;
window.renewPromoCode = renewPromoCode;
window.confirmDelete = confirmDelete;
window.showNotification = showNotification;
window.hideNotification = hideNotification;
window.openModal = openModal;
window.closeModal = closeModal;
window.copyToClipboard = copyToClipboard;