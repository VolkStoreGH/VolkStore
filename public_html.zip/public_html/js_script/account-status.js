// Function to update the navigation based on login status
function updateNavigation() {
    // Check if user is logged in
    const isUserLoggedIn = localStorage.getItem('currentUser') !== null;
    
    // Get the navigation element
    const nav = document.querySelector('nav');
    
    // If user is logged in, add account link
    if (isUserLoggedIn) {
        // Check if account link already exists
        if (!document.querySelector('.account-link')) {
            // Get current user data
            const userData = JSON.parse(localStorage.getItem('currentUser'));
            
            // Create account link
            const accountLink = document.createElement('a');
            accountLink.href = 'profile.html';
            accountLink.className = 'nav-link account-link';
            
            // Create user icon
            const userIcon = document.createElement('i');
            userIcon.className = 'fas fa-user-circle';
            userIcon.style.marginRight = '5px';
            
            // Add icon and text to link
            accountLink.appendChild(userIcon);
            accountLink.appendChild(document.createTextNode(userData.name));
            
            // Add link to navigation
            nav.appendChild(accountLink);
        }
    } else {
        // If user is not logged in, add login/register link if it doesn't exist
        if (!document.querySelector('.auth-link')) {
            const authLink = document.createElement('a');
            authLink.href = 'login.html';
            authLink.className = 'nav-link auth-link';
            
            // Create user icon
            const userIcon = document.createElement('i');
            userIcon.className = 'fas fa-sign-in-alt';
            userIcon.style.marginRight = '5px';
            
            // Add icon and text to link
            authLink.appendChild(userIcon);
            authLink.appendChild(document.createTextNode('Войти / Регистрация'));
            
            // Add link to navigation
            nav.appendChild(authLink);
        }
    }
}

// Run when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    updateNavigation();
});