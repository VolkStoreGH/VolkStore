// Добавьте этот код в ваш файл script.js

// Modify the getGamePlatform function to handle direct platform names
function getGamePlatform(card) {
  // Get the platform data attribute from the card
  const platformData = card.getAttribute("data-platform") || ""

  // Check if the platform is directly specified as "steam" or "rockstar"
  if (platformData.toLowerCase().includes("steam")) {
    // Add Steam logo
    addPlatformLogo(card, "steam")
    return "steam"
  } else if (platformData.toLowerCase().includes("rockstar") || platformData.toLowerCase().includes("rock star")) {
    // Add Rockstar Games logo
    addPlatformLogo(card, "rockstar")
    return "rockstar"
  } else if (platformData.includes("pc")) {
    // Default PC to Steam
    addPlatformLogo(card, "steam")
    return "steam"
  } else if (platformData.includes("playstation") || platformData.includes("xbox")) {
    // Default console to Rockstar
    addPlatformLogo(card, "rockstar")
    return "rockstar"
  }

  return "other"
}

// Update the addPlatformLogo function to position the logo at the bottom right
function addPlatformLogo(card, platform) {
  // Check if logo already exists
  if (card.querySelector(".platform-logo")) {
    return
  }

  // Create logo element
  const logoDiv = document.createElement("div")
  logoDiv.className = "platform-logo"

  // Set logo path based on platform
  const logoPath = platform === "steam" ? "img site/steam-logo.png" : "img site/rockstar-logo.jpg"
  const logoAlt = platform === "steam" ? "Steam" : "Rockstar Games"

  // Create HTML for logo
  logoDiv.innerHTML = `<img src="${logoPath}" alt="${logoAlt}">`

  // Add logo to card
  card.appendChild(logoDiv)
}

// Обновляем функцию фильтрации игр в расширенном поиске
document.addEventListener("DOMContentLoaded", () => {
  const applySearchButton = document.getElementById("apply-search")

  if (applySearchButton) {
    applySearchButton.addEventListener("click", () => {
      const searchName = document.getElementById("search-name").value.toLowerCase()
      const searchMinPrice = Number.parseInt(document.getElementById("search-min-price").value)
      const searchMaxPrice = Number.parseInt(document.getElementById("search-max-price").value)
      const searchRating = Number.parseInt(document.getElementById("search-rating").value)
      const gameCards = document.querySelectorAll(".game-card")
      const searchResultsContainer = document.getElementById("search-results-container")

      // Получаем выбранные категории
      const selectedCategories = []
      document.querySelectorAll(".search-category input:checked").forEach((checkbox) => {
        selectedCategories.push(checkbox.value)
      })

      // Получаем выбранные платформы
      const selectedPlatforms = []
      document.querySelectorAll(".search-platform input:checked").forEach((checkbox) => {
        selectedPlatforms.push(checkbox.value)
      })

      // Фильтруем игры
      const filteredGames = Array.from(gameCards).filter((card) => {
        const title = card.querySelector(".game-title").textContent.toLowerCase()
        const priceText = card.querySelector(".game-price").textContent
        let price = 0

        // Извлекаем числовое значение цены
        if (priceText !== "Нет в наличие" && priceText !== "Скоро...") {
          price = Number.parseInt(priceText.replace(/\D/g, ""))
        }

        const cardCategories = card.getAttribute("data-categories") || ""
        const cardPlatform = getGamePlatform(card) // Используем новую функцию

        // Проверяем рейтинг
        const ratingElement = card.querySelector(".rating span")
        let rating = 0
        if (ratingElement) {
          const ratingText = ratingElement.textContent
          rating = Number.parseFloat(ratingText.replace(/[()]/g, ""))
        }

        // Проверяем соответствие всем критериям
        const nameMatch = searchName === "" || title.includes(searchName)
        const priceMatch = price >= searchMinPrice && price <= searchMaxPrice
        const ratingMatch = searchRating === 0 || rating >= searchRating

        // Проверяем категории
        let categoryMatch = true
        if (selectedCategories.length > 0) {
          categoryMatch = selectedCategories.some((category) => cardCategories.includes(category))
        }

        // Проверяем платформы
        let platformMatch = true
        if (selectedPlatforms.length > 0) {
          platformMatch = selectedPlatforms.includes(cardPlatform)
        }

        return nameMatch && priceMatch && ratingMatch && categoryMatch && platformMatch
      })

      // Отображаем результаты поиска
      displaySearchResults(filteredGames, searchResultsContainer)
    })
  }

  // Добавляем стили для логотипов платформ
  const style = document.createElement("style")
  style.textContent = `
    .platform-logo {
      position: absolute;
      bottom: 10px;
      right: 10px;
      width: 32px;
      height: 32px;
      background-color: rgba(0, 0, 0, 0.7);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 5;
      transition: all 0.3s ease;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
      overflow: hidden;
    }
    
    .platform-logo img {
      width: 22px;
      height: 22px;
      object-fit: contain;
      border-radius: 50%;
    }
    
    .game-card:hover .platform-logo {
      transform: scale(1.1);
      box-shadow: 0 0 10px rgba(164, 113, 247, 0.5);
    }
  `
  document.head.appendChild(style)
})

// Функция для отображения результатов поиска
function displaySearchResults(filteredGames, container) {
  // Очищаем контейнер
  container.innerHTML = ""

  if (filteredGames.length === 0) {
    container.innerHTML = '<div class="no-results">Игры не найдены</div>'
  } else {
    // Добавляем счетчик найденных игр
    const resultsCount = document.createElement("div")
    resultsCount.className = "results-count"
    resultsCount.innerHTML = `Найдено игр: <strong>${filteredGames.length}</strong>`
    container.appendChild(resultsCount)

    // Создаем контейнер для карточек
    const resultsGrid = document.createElement("div")
    resultsGrid.className = "search-results-grid"
    container.appendChild(resultsGrid)

    filteredGames.forEach((game) => {
      const title = game.querySelector(".game-title").textContent
      const price = game.querySelector(".game-price").textContent
      const imgSrc = game.querySelector("img").src

      // Определяем платформу
      const platform = getGamePlatform(game)
      const displayPlatform = platform === "steam" ? "Steam" : platform === "rockstar" ? "Rockstar Games" : "Другие"

      // Создаем карточку результата поиска
      const resultCard = document.createElement("div")
      resultCard.className = "search-result-card"

      resultCard.innerHTML = `
        <img src="${imgSrc}" alt="${title}">
        <div class="search-result-info">
          <h4 class="search-result-title">${title}</h4>
          <div class="search-result-price">${price}</div>
          <div class="search-result-platform">Платформа: ${displayPlatform}</div>
          <button class="search-result-btn" data-game="${title}">Подробнее</button>
        </div>
      `

      resultsGrid.appendChild(resultCard)
    })

    // Добавляем обработчики для кнопок "Подробнее"
    document.querySelectorAll(".search-result-btn").forEach((button) => {
      button.addEventListener("click", function () {
        const gameName = this.getAttribute("data-game")
        const gameCards = document.querySelectorAll(".game-card")

        // Находим соответствующую карточку игры
        const gameCard = Array.from(gameCards).find((card) => {
          return card.querySelector(".game-title").textContent === gameName
        })

        if (gameCard) {
          // Закрываем модальное окно
          document.getElementById("search-modal").style.display = "none"
          document.body.style.overflow = "" // Разблокируем прокрутку страницы

          setTimeout(() => {
            gameCard.scrollIntoView({ behavior: "smooth", block: "center" })

            // Подсвечиваем карточку
            gameCard.classList.add("highlight")
            setTimeout(() => {
              gameCard.classList.remove("highlight")
            }, 2000)
          }, 300)
        }
      })
    })
  }
}

// Инициализация анимаций для карточек игр и чекбоксов
document.addEventListener("DOMContentLoaded", () => {
  // Инициализация анимаций для карточек игр
  initGameCardAnimations()

  // Инициализация стилизованных чекбоксов
  initCustomCheckboxes()
})

// Функция для инициализации анимаций карточек игр
function initGameCardAnimations() {
  // Сбрасываем анимации для всех карточек
  const gameCards = document.querySelectorAll(".game-card")
  gameCards.forEach((card) => {
    card.style.animation = "none"
    card.offsetHeight // Форсируем перерисовку
    card.style.animation = ""

    // Добавляем обработчики для эффектов при наведении
    card.addEventListener("mouseenter", function () {
      this.classList.add("hover-effect")
    })

    card.addEventListener("mouseleave", function () {
      this.classList.remove("hover-effect")
    })
  })

  // Добавляем обработчик для анимации при прокрутке
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible")
          // Отключаем наблюдение после появления
          observer.unobserve(entry.target)
        }
      })
    },
    {
      threshold: 0.1, // Элемент считается видимым, когда 10% его площади видно
    },
  )

  // Наблюдаем за всеми карточками
  gameCards.forEach((card) => {
    observer.observe(card)
  })
}

// Функция для инициализации стилизованных чекбоксов
function initCustomCheckboxes() {
  // Находим все контейнеры чекбоксов
  const checkboxContainers = document.querySelectorAll(".search-category, .search-platform")

  checkboxContainers.forEach((container) => {
    const checkbox = container.querySelector('input[type="checkbox"]')
    const label = document.createElement("label")

    // Если чекбокс уже обернут в label, пропускаем
    if (checkbox.parentNode.tagName === "LABEL") return

    // Получаем текст после чекбокса
    let text = checkbox.nextSibling
    while (text && text.nodeType !== 1) {
      text = text.nextSibling
    }

    // Если текст найден, используем его содержимое
    if (text) {
      label.textContent = text.textContent
      container.removeChild(text)
    } else {
      // Иначе используем значение чекбокса
      label.textContent = checkbox.value
    }

    // Устанавливаем атрибуты для связи label и checkbox
    const id = checkbox.id || `checkbox-${Math.random().toString(36).substr(2, 9)}`
    checkbox.id = id
    label.setAttribute("for", id)

    // Вставляем label после чекбокса
    checkbox.insertAdjacentElement("afterend", label)

    // Добавляем обработчик для изменения состояния контейнера
    checkbox.addEventListener("change", function () {
      if (this.checked) {
        container.classList.add("active")
      } else {
        container.classList.remove("active")
      }
    })
  })

  // Обрабатываем остальные чекбоксы на странице
  const otherCheckboxes = document.querySelectorAll(
    'input[type="checkbox"]:not(.search-category input):not(.search-platform input)',
  )
  otherCheckboxes.forEach((checkbox) => {
    // Добавляем класс для стилизации
    checkbox.classList.add("custom-checkbox")
  })
}

// Функция для анимации выделения карточки
function highlightGameCard(cardElement) {
  if (!cardElement) return

  // Удаляем предыдущие классы анимации
  cardElement.classList.remove("highlight")

  // Форсируем перерисовку
  cardElement.offsetWidth

  // Добавляем класс анимации
  cardElement.classList.add("highlight")

  // Удаляем класс через некоторое время
  setTimeout(() => {
    cardElement.classList.remove("highlight")
  }, 4000)
}

// Обновляем обработчик для кнопок "Подробнее"
document.addEventListener("click", (e) => {
  if (e.target && e.target.classList.contains("search-result-btn")) {
    const gameName = e.target.getAttribute("data-game")
    const gameCards = document.querySelectorAll(".game-card")

    // Находим соответствующую карточку игры
    const gameCard = Array.from(gameCards).find((card) => {
      return card.querySelector(".game-title").textContent === gameName
    })

    if (gameCard) {
      // Закрываем модальное окно
      const searchModal = document.getElementById("search-modal")
      if (searchModal) {
        searchModal.style.display = "none"
      }
      document.body.style.overflow = "" // Разблокируем прокрутку страницы

      setTimeout(() => {
        gameCard.scrollIntoView({ behavior: "smooth", block: "center" })

        // Анимируем выделение карточки
        highlightGameCard(gameCard)
      }, 300)
    }
  }
})

// Функция для анимации карточек результатов поиска
function animateSearchResults() {
  // Сбрасываем анимации для всех карточек
  const cards = document.querySelectorAll(".search-result-card")
  cards.forEach((card) => {
    card.style.animation = "none"
    card.offsetHeight // Форсируем перерисовку
    card.style.animation = ""
  })

  // Анимируем счетчик результатов
  const resultsCount = document.querySelector(".results-count")
  if (resultsCount) {
    resultsCount.style.animation = "none"
    resultsCount.offsetHeight // Форсируем перерисовку
    resultsCount.style.animation = "fadeInDown 0.5s forwards"
  }

  // Анимируем сообщение "Игры не найдены"
  const noResults = document.querySelector(".no-results")
  if (noResults) {
    noResults.style.animation = "none"
    noResults.offsetHeight // Форсируем перерисовку
    noResults.style.animation = "fadeInUp 0.5s forwards"
  }
}

// Обновляем функцию отображения результатов поиска
document.addEventListener("DOMContentLoaded", () => {
  const applySearchButton = document.getElementById("apply-search")
  const searchResultsContainer = document.getElementById("search-results-container")

  if (applySearchButton && searchResultsContainer) {
    applySearchButton.addEventListener("click", () => {
      // Существующий код фильтрации игр...

      // После обновления результатов поиска запускаем анимацию
      setTimeout(animateSearchResults, 10)
    })
  }

  // Добавляем обработчик для кнопок "Подробнее"
  document.addEventListener("click", (e) => {
    if (e.target && e.target.classList.contains("search-result-btn")) {
      const gameName = e.target.getAttribute("data-game")
      const gameCards = document.querySelectorAll(".game-card")

      // Находим соответствующую карточку игры
      const gameCard = Array.from(gameCards).find((card) => {
        return card.querySelector(".game-title").textContent === gameName
      })

      if (gameCard) {
        // Закрываем модальное окно
        const searchModal = document.getElementById("search-modal")
        if (searchModal) {
          searchModal.style.display = "none"
        }
        document.body.style.overflow = "" // Разблокируем прокрутку страницы

        setTimeout(() => {
          gameCard.scrollIntoView({ behavior: "smooth", block: "center" })

          // Добавляем класс для анимации и удаляем его через некоторое время
          gameCard.classList.add("highlight")
          setTimeout(() => {
            gameCard.classList.remove("highlight")
          }, 3000)
        }, 300)
      }
    }
  })
})
document.addEventListener("DOMContentLoaded", () => {
  // Прелоадер
  const preloader = document.querySelector(".preloader")
  window.addEventListener("load", () => {
    setTimeout(() => {
      preloader.classList.add("hidden")
    }, 500)
  })

  // Анимация счетчиков
  const statNumbers = document.querySelectorAll(".stat-number")

  function animateStats() {
    statNumbers.forEach((stat) => {
      const target = stat.getAttribute("data-count")
      const isPlus = target.includes("+")
      const numTarget = Number.parseInt(target)
      let count = 0
      const duration = 2000 // 2 секунды
      const interval = 50 // 50 миллисекунд
      const increment = numTarget / (duration / interval)

      const timer = setInterval(() => {
        count += increment
        if (count >= numTarget) {
          clearInterval(timer)
          stat.textContent = isPlus ? numTarget + "+" : numTarget
        } else {
          stat.textContent = Math.floor(count)
        }
      }, interval)
    })
  }

  // Функция для открытия модальных окон с анимацией
  function openModal(modalId) {
    const modal = document.getElementById(modalId)
    if (modal) {
      // Добавляем анимацию появления
      modal.style.display = "block"
      modal.style.opacity = "0"
      document.body.style.overflow = "hidden" // Блокируем прокрутку страницы

      setTimeout(() => {
        modal.style.opacity = "1"
        modal.style.transition = "opacity 0.3s ease"
      }, 10)
    }
  }

  // Функция для закрытия всех модальных окон с анимацией
  function closeAllModals() {
    const modals = document.querySelectorAll(".modal")
    modals.forEach((modal) => {
      modal.style.opacity = "0"
      modal.style.transition = "opacity 0.3s ease"

      setTimeout(() => {
        modal.style.display = "none"
      }, 300)
    })
    document.body.style.overflow = "" // Разблокируем прокрутку страницы
  }

  // Кнопка "Наверх"
  const backToTopButton = document.getElementById("backToTop")

  window.addEventListener("scroll", () => {
    if (window.pageYOffset > 300) {
      backToTopButton.classList.add("visible")
    } else {
      backToTopButton.classList.remove("visible")
    }

    // Анимация счетчиков при прокрутке до них
    const statsSection = document.querySelector(".stats")
    if (statsSection && isElementInViewport(statsSection) && !statsSection.classList.contains("animated")) {
      statsSection.classList.add("animated")
      animateStats()
    }
  })

  backToTopButton.addEventListener("click", () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    })
  })

  // Функция проверки, находится ли элемент в видимой области
  function isElementInViewport(el) {
    const rect = el.getBoundingClientRect()
    return rect.top <= window.innerHeight && rect.bottom >= 0
  }

  // Анимация появления карточек игр
  const gameCards = document.querySelectorAll(".game-card")

  function checkGameCards() {
    gameCards.forEach((card) => {
      if (isElementInViewport(card) && !card.classList.contains("visible")) {
        card.classList.add("visible")
      }
    })
  }

  window.addEventListener("scroll", checkGameCards)
  window.addEventListener("resize", checkGameCards)
  checkGameCards() // Проверяем при загрузке страницы

  // Фильтрация игр по категориям
  const categoryButtons = document.querySelectorAll(".category-btn")

  categoryButtons.forEach((button) => {
    button.addEventListener("click", function () {
      // Удаляем активный класс у всех кнопок
      categoryButtons.forEach((btn) => btn.classList.remove("active"))
      // Добавляем активный класс нажатой кнопке
      this.classList.add("active")

      const category = this.getAttribute("data-category")

      // Фильтруем игры по категории
      gameCards.forEach((card) => {
        if (category === "all") {
          card.style.display = "block"
        } else {
          const cardCategories = card.getAttribute("data-categories")
          if (cardCategories && cardCategories.includes(category)) {
            card.style.display = "block"
          } else {
            card.style.display = "none"
          }
        }
      })
    })
  })

  // Поиск игр
  const searchInput = document.getElementById("searchInput")
  const searchButton = document.getElementById("searchButton")

  searchButton.addEventListener("click", () => {
    const searchTerm = searchInput.value.toLowerCase()
    searchGames(searchTerm)
  })

  searchInput.addEventListener("keyup", (event) => {
    if (event.key === "Enter") {
      const searchTerm = searchInput.value.toLowerCase()
      searchGames(searchTerm)
    }
  })

  // Добавляем поиск в реальном времени
  searchInput.addEventListener("input", () => {
    const searchTerm = searchInput.value.toLowerCase()
    if (searchTerm.length >= 3) {
      // Поиск начинается от 3 символов
      searchGames(searchTerm)
    } else if (searchTerm.length === 0) {
      // Если поле поиска пустое, показываем все игры
      gameCards.forEach((card) => {
        card.style.display = "block"
      })
    }
  })

  function searchGames(searchTerm) {
    gameCards.forEach((card) => {
      const title = card.querySelector(".game-title").textContent.toLowerCase()
      const genre = card.querySelector(".game-genre").textContent.toLowerCase()

      if (title.includes(searchTerm) || genre.includes(searchTerm)) {
        card.style.display = "block"
      } else {
        card.style.display = "none"
      }
    })
  }

  // Модальное окно для доната
  const donateNavLink = document.getElementById("donate-nav-link")
  const donateBottomLink = document.getElementById("donate-bottom-link")
  const donateModal = document.getElementById("donate-modal")
  const closeModalButtons = document.querySelectorAll(".close-modal")
  const donateOptionsList = document.getElementById("donate-options-list")
  const donateGameTabs = document.querySelectorAll(".donate-game-tab")

  // Данные для опций доната по играм
  const donateOptions = {
    "Elden Ring": [
      { title: "Elden Ring: Интернет-подписка", description: "Доступ к онлайн-функциям игры на 30 дней", price: 299 },
      { title: "Elden Ring: 60 монохромов", description: "Базовый набор внутриигровой валюты", price: 499 },
      { title: "Elden Ring: 300 + 30 монохромов в подарок", description: "Стандартный набор с бонусом", price: 999 },
      { title: "Elden Ring: 980 + 110 монохромов в подарок", description: "Расширенный набор с бонусом", price: 1999 },
      { title: "Elden Ring: 1 980 + 260 монохромов в подарок", description: "Премиум набор с бонусом", price: 3999 },
      { title: "Elden Ring: 3 280 + 600 монохромов в подарок", description: "VIP набор с бонусом", price: 5999 },
      {
        title: "Elden Ring: 6 480 + 1 600 монохромов в подарок",
        description: "Максимальный набор с бонусом",
        price: 9999,
      },
    ],
    "Genshin Impact": [
      {
        title: "Genshin Impact: Благословение полой луны",
        description: "Ежедневные примогемы в течение 30 дней",
        price: 299,
      },
      { title: "Genshin Impact: 60 кристаллов", description: "Базовый набор внутриигровой валюты", price: 499 },
      {
        title: "Genshin Impact: 300 + 30 кристаллов в подарок",
        description: "Стандартный набор с бонусом",
        price: 999,
      },
      {
        title: "Genshin Impact: 980 + 110 кристаллов в подарок",
        description: "Расширенный набор с бонусом",
        price: 1999,
      },
      {
        title: "Genshin Impact: 1 980 + 260 кристаллов в подарок",
        description: "Премиум набор с бонусом",
        price: 3999,
      },
      { title: "Genshin Impact: 3 280 + 600 кристаллов в подарок", description: "VIP набор с бонусом", price: 5999 },
      {
        title: "Genshin Impact: 6 480 + 1 600 кристаллов в подарок",
        description: "Максимальный набор с бонусом",
        price: 9999,
      },
    ],
    "Zenless Zone Zero": [
      {
        title: "Zenless Zone Zero: Интернет-подписка",
        description: "Доступ к онлайн-функциям игры на 30 дней",
        price: 299,
      },
      { title: "Zenless Zone Zero: 60 монохромов", description: "Базовый набор внутриигровой валюты", price: 499 },
      {
        title: "Zenless Zone Zero: 300 + 30 монохромов в подарок",
        description: "Стандартный набор с бонусом",
        price: 999,
      },
      {
        title: "Zenless Zone Zero: 980 + 110 монохромов в подарок",
        description: "Расширенный набор с бонусом",
        price: 1999,
      },
      {
        title: "Zenless Zone Zero: 1 980 + 260 монохромов в подарок",
        description: "Премиум набор с бонусом",
        price: 3999,
      },
      { title: "Zenless Zone Zero: 3 280 + 600 монохромов в подарок", description: "VIP набор с бонусом", price: 5999 },
      {
        title: "Zenless Zone Zero: 6 480 + 1 600 монохромов в подарок",
        description: "Максимальный набор с бонусом",
        price: 9999,
      },
    ],
    "Cyberpunk 2077": [
      {
        title: "Cyberpunk 2077: Интернет-подписка",
        description: "Доступ к онлайн-функциям игры на 30 дней",
        price: 299,
      },
      { title: "Cyberpunk 2077: 60 эдди", description: "Базовый набор внутриигровой валюты", price: 499 },
      { title: "Cyberpunk 2077: 300 + 30 эдди в подарок", description: "Стандартный набор с бонусом", price: 999 },
      { title: "Cyberpunk 2077: 980 + 110 эдди в подарок", description: "Расширенный набор с бонусом", price: 1999 },
      { title: "Cyberpunk 2077: 1 980 + 260 эдди в подарок", description: "Премиум набор с бонусом", price: 3999 },
      { title: "Cyberpunk 2077: 3 280 + 600 эдди в подарок", description: "VIP набор с бонусом", price: 5999 },
      {
        title: "Cyberpunk 2077: 6 480 + 1 600 эдди в подарок",
        description: "Максимальный набор с бонусом",
        price: 9999,
      },
    ],
    "S.T.A.L.K.E.R 2": [
      {
        title: "S.T.A.L.K.E.R 2: Интернет-подписка",
        description: "Доступ к онлайн-функциям игры на 30 дней",
        price: 299,
      },
      { title: "S.T.A.L.K.E.R 2: 60 артефактов", description: "Базовый набор внутриигровой валюты", price: 499 },
      {
        title: "S.T.A.L.K.E.R 2: 300 + 30 артефактов в подарок",
        description: "Стандартный набор с бонусом",
        price: 999,
      },
      {
        title: "S.T.A.L.K.E.R 2: 980 + 110 артефактов в подарок",
        description: "Расширенный набор с бонусом",
        price: 1999,
      },
      {
        title: "S.T.A.L.K.E.R 2: 1 980 + 260 артефактов в подарок",
        description: "Премиум набор с бонусом",
        price: 3999,
      },
      { title: "S.T.A.L.K.E.R 2: 3 280 + 600 артефактов в подарок", description: "VIP набор с бонусом", price: 5999 },
      {
        title: "S.T.A.L.K.E.R 2: 6 480 + 1 600 артефактов в подарок",
        description: "Максимальный набор с бонусом",
        price: 9999,
      },
    ],
  }

  // Функция для отображения опций доната для выбранной игры
  function showDonateOptions(gameName) {
    // Очищаем список опций
    donateOptionsList.innerHTML = ""

    // Получаем опции для выбранной игры
    const options = donateOptions[gameName] || []

    // Добавляем опции в список
    options.forEach((option, index) => {
      const optionItem = document.createElement("div")
      optionItem.className = "donate-option-item"
      optionItem.setAttribute("data-index", index)

      optionItem.innerHTML = `
        <div class="donate-option-icon">
          <i class="fas fa-gift"></i>
        </div>
        <div class="donate-option-info">
          <div class="donate-option-title">${option.title}</div>
          <div class="donate-option-description">${option.description || "Поддержите разработчиков и получите внутриигровые предметы"}</div>
        </div>
        <div class="donate-option-price">${option.price} ₽</div>
      `

      optionItem.addEventListener("click", function () {
        // Удаляем класс selected у всех опций
        document.querySelectorAll(".donate-option-item").forEach((item) => {
          item.classList.remove("selected")
        })
        // Добавляем класс selected выбранной опции
        this.classList.add("selected")

        // Обновляем информацию о выбранной опции
        updateSelectedDonateInfo(option)
      })

      donateOptionsList.appendChild(optionItem)
    })

    // Выбираем первую опцию по умолчанию
    if (donateOptionsList.firstChild) {
      donateOptionsList.firstChild.classList.add("selected")
      // Обновляем информацию о выбранной опции
      updateSelectedDonateInfo(options[0])
    }
  }

  // Функция для обновления информации о выбранной опции доната
  function updateSelectedDonateInfo(option) {
    const selectedInfoContainer = document.getElementById("selected-donate-info")
    if (selectedInfoContainer) {
      selectedInfoContainer.innerHTML = `
        <h3>Выбранная опция:</h3>
        <div class="selected-donate-details">
          <div class="selected-donate-title">${option.title}</div>
          <div class="selected-donate-description">${option.description || "Поддержите разработчиков и получите внутриигровые предметы"}</div>
          <div class="selected-donate-price">Стоимость: ${option.price} ₽</div>
        </div>
      `
    }
  }

  // Обработчики для вкладок игр
  donateGameTabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      // Удаляем активный класс у всех вкладок
      donateGameTabs.forEach((t) => t.classList.remove("active"))
      // Добавляем активный класс нажатой вкладке
      this.classList.add("active")

      // Показываем опции для выбранной игры
      const gameName = this.getAttribute("data-game")
      showDonateOptions(gameName)
    })
  })

  // Открытие модального окна доната при клике на ссылку в навигации
  if (donateNavLink) {
    donateNavLink.addEventListener("click", (e) => {
      e.preventDefault()
      openDonateModal()
    })
  }

  // Открытие модального окна доната при клике на ссылку в нижней навигации
  if (donateBottomLink) {
    donateBottomLink.addEventListener("click", (e) => {
      e.preventDefault()
      openDonateModal()
    })
  }

  // Функция открытия модального окна доната
  function openDonateModal() {
    // Показываем опции для игры по умолчанию (первая вкладка)
    const defaultGameTab =
      document.querySelector(".donate-game-tab.active") || document.querySelector(".donate-game-tab")
    if (defaultGameTab) {
      defaultGameTab.classList.add("active")
      const gameName = defaultGameTab.getAttribute("data-game")
      showDonateOptions(gameName)
    }

    // Открываем модальное окно
    openModal("donate-modal")
  }

  // Закрытие модальных окон
  closeModalButtons.forEach((button) => {
    button.addEventListener("click", closeAllModals)
  })

  // Закрытие модального окна при клике вне его содержимого
  window.addEventListener("click", (event) => {
    const modals = document.querySelectorAll(".modal")
    modals.forEach((modal) => {
      if (event.target === modal) {
        closeAllModals()
      }
    })
  })

  // Закрытие модального окна при нажатии клавиши Escape
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeAllModals()
    }
  })

  // Кнопка "Посмотреть больше игр"
  const moreGamesButton = document.getElementById("more-games-btn")
  const searchModal = document.getElementById("search-modal")

  if (moreGamesButton) {
    moreGamesButton.addEventListener("click", () => {
      // Открываем модальное окно расширенного поиска
      openModal("search-modal")

      // Сбрасываем фильтры при открытии
      resetSearchFilters()

      // Обновляем платформы в модальном окне
      updatePlatformsInModal()
    })
  }

  // Функция для обновления платформ в модальном окне
  function updatePlatformsInModal() {
    const platformsContainer = document.querySelector(".search-platforms")
    if (platformsContainer) {
      // Очищаем контейнер платформ
      platformsContainer.innerHTML = ""

      // Добавляем только Steam и Rock Star Games
      platformsContainer.innerHTML = `
        <label class="search-platform">
          <input type="checkbox" value="steam"> Steam
        </label>
        <label class="search-platform">
          <input type="checkbox" value="rockstar"> Rock Star Games
        </label>
      `
    }
  }

  // Функция сброса фильтров поиска
  function resetSearchFilters() {
    // Сбрасываем поле поиска
    const searchNameInput = document.getElementById("search-name")
    if (searchNameInput) {
      searchNameInput.value = ""
    }

    // Сбрасываем чекбоксы категорий
    document.querySelectorAll(".search-category input").forEach((checkbox) => {
      checkbox.checked = false
    })

    // Сбрасываем чекбоксы платформ
    document.querySelectorAll(".search-platform input").forEach((checkbox) => {
      checkbox.checked = false
    })

    // Сбрасываем диапазон цен
    const minPriceInput = document.getElementById("search-min-price")
    const maxPriceInput = document.getElementById("search-max-price")
    if (minPriceInput && maxPriceInput) {
      minPriceInput.value = "0"
      maxPriceInput.value = "5000"
    }

    // Сбрасываем рейтинг
    const ratingSelect = document.getElementById("search-rating")
    if (ratingSelect) {
      ratingSelect.value = "0"
    }

    // Очищаем результаты поиска
    const searchResultsContainer = document.getElementById("search-results-container")
    if (searchResultsContainer) {
      searchResultsContainer.innerHTML = '<div class="no-results">Используйте фильтры для поиска игр</div>'
    }
  }

  // Расширенный поиск игр
  const applySearchButton = document.getElementById("apply-search")
  const searchResultsContainer = document.getElementById("search-results-container")

  if (applySearchButton) {
    applySearchButton.addEventListener("click", () => {
      const searchName = document.getElementById("search-name").value.toLowerCase()
      const searchMinPrice = Number.parseInt(document.getElementById("search-min-price").value)
      const searchMaxPrice = Number.parseInt(document.getElementById("search-max-price").value)
      const searchRating = Number.parseInt(document.getElementById("search-rating").value)

      // Получаем выбранные категории
      const selectedCategories = []
      document.querySelectorAll(".search-category input:checked").forEach((checkbox) => {
        selectedCategories.push(checkbox.value)
      })

      // Получаем выбранные платформы
      const selectedPlatforms = []
      document.querySelectorAll(".search-platform input:checked").forEach((checkbox) => {
        selectedPlatforms.push(checkbox.value)
      })

      // Фильтруем игры
      const filteredGames = Array.from(gameCards).filter((card) => {
        const title = card.querySelector(".game-title").textContent.toLowerCase()
        const priceText = card.querySelector(".game-price").textContent
        let price = 0

        // Извлекаем числовое значение цены
        if (priceText !== "Нет в наличие") {
          price = Number.parseInt(priceText.replace(/\D/g, ""))
        }

        const cardCategories = card.getAttribute("data-categories") || ""
        const cardPlatforms = card.getAttribute("data-platform") || ""

        // Проверяем рейтинг
        const ratingElement = card.querySelector(".rating span")
        let rating = 0
        if (ratingElement) {
          const ratingText = ratingElement.textContent
          rating = Number.parseFloat(ratingText.replace(/[()]/g, ""))
        }

        // Проверяем соответствие всем критериям
        const nameMatch = searchName === "" || title.includes(searchName)
        const priceMatch = price >= searchMinPrice && price <= searchMaxPrice
        const ratingMatch = searchRating === 0 || rating >= searchRating

        // Проверяем категории
        let categoryMatch = true
        if (selectedCategories.length > 0) {
          categoryMatch = selectedCategories.some((category) => cardCategories.includes(category))
        }

        // Проверяем платформы
        let platformMatch = true
        if (selectedPlatforms.length > 0) {
          // Преобразуем платформы карточки в соответствии с новыми значениями
          const mappedPlatforms = cardPlatforms.includes("pc")
            ? "steam"
            : cardPlatforms.includes("playstation")
              ? "rockstar"
              : cardPlatforms

          platformMatch = selectedPlatforms.some((platform) => mappedPlatforms.includes(platform))
        }

        return nameMatch && priceMatch && ratingMatch && categoryMatch && platformMatch
      })

      // Отображаем результаты поиска
      searchResultsContainer.innerHTML = ""

      if (filteredGames.length === 0) {
        searchResultsContainer.innerHTML = '<div class="no-results">Игры не найдены</div>'
      } else {
        // Добавляем счетчик найденных игр
        const resultsCount = document.createElement("div")
        resultsCount.className = "results-count"
        resultsCount.innerHTML = `Найдено игр: <strong>${filteredGames.length}</strong>`
        searchResultsContainer.appendChild(resultsCount)

        // Создаем контейнер для карточек
        const resultsGrid = document.createElement("div")
        resultsGrid.className = "search-results-grid"
        // Устанавливаем стиль для отображения 3 игр в ряд
        resultsGrid.style.gridTemplateColumns = "repeat(3, 1fr)"
        searchResultsContainer.appendChild(resultsGrid)

        filteredGames.forEach((game) => {
          const title = game.querySelector(".game-title").textContent
          const price = game.querySelector(".game-price").textContent
          const imgSrc = game.querySelector("img").src
          const platforms = game.getAttribute("data-platform") || ""

          // Преобразуем платформы для отображения
          const displayPlatforms = platforms.includes("pc")
            ? "Steam"
            : platforms.includes("playstation")
              ? "Rock Star Games"
              : formatPlatforms(platforms)

          // Создаем карточку результата поиска
          const resultCard = document.createElement("div")
          resultCard.className = "search-result-card"

          resultCard.innerHTML = `
            <img src="${imgSrc}" alt="${title}">
            <div class="search-result-info">
              <h4 class="search-result-title">${title}</h4>
              <div class="search-result-price">${price}</div>
              <div class="search-result-platform">Платформа: ${displayPlatforms}</div>
              <button class="search-result-btn" data-game="${title}">Подробнее</button>
            </div>
          `

          resultsGrid.appendChild(resultCard)
        })

        // Добавляем обработчики для кнопок "Подробнее"
        document.querySelectorAll(".search-result-btn").forEach((button) => {
          button.addEventListener("click", function () {
            const gameName = this.getAttribute("data-game")

            // Находим соответствующую карточку игры
            const gameCard = Array.from(gameCards).find((card) => {
              return card.querySelector(".game-title").textContent === gameName
            })

            if (gameCard) {
              // Прокручиваем к карточке игры
              closeAllModals()

              setTimeout(() => {
                gameCard.scrollIntoView({ behavior: "smooth", block: "center" })

                // Подсвечиваем карточку
                gameCard.classList.add("highlight")
                setTimeout(() => {
                  gameCard.classList.remove("highlight")
                }, 2000)
              }, 300)
            }
          })
        })
      }
    })
  }

  // Форматирование платформ для отображения
  function formatPlatforms(platforms) {
    if (!platforms) return "Не указано"

    // Обновленная карта платформ
    const platformMap = {
      pc: "Steam",
      playstation: "Rock Star Games",
      xbox: "Xbox",
      nintendo: "Nintendo",
    }

    return platforms
      .split(" ")
      .map((p) => platformMap[p] || p)
      .join(", ")
  }

  // Инициализация первой вкладки доната при загрузке страницы
  const firstDonateTab = document.querySelector(".donate-game-tab")
  if (firstDonateTab) {
    firstDonateTab.classList.add("active")
    const gameName = firstDonateTab.getAttribute("data-game")
    if (gameName) {
      showDonateOptions(gameName)
    }
  }

  // Обновляем платформы в модальном окне при загрузке страницы
  document.addEventListener("DOMContentLoaded", () => {
    updatePlatformsInModal()

    // Добавляем стили для сетки результатов поиска
    const style = document.createElement("style")
    style.textContent = `
      .search-results-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr) !important;
        gap: 20px;
      }
      
      @media (max-width: 768px) {
        .search-results-grid {
          grid-template-columns: repeat(2, 1fr) !important;
        }
      }
      
      @media (max-width: 480px) {
        .search-results-grid {
          grid-template-columns: 1fr !important;
        }
      }
    `
    document.head.appendChild(style)
  })
})

// Добавляем стили для кастомных чекбоксов
document.addEventListener("DOMContentLoaded", () => {
  const style = document.createElement("style")
  style.textContent = `
    /* Стили для кастомных чекбоксов */
    .search-category, .search-platform {
      position: relative;
      display: flex;
      align-items: center;
      background-color: rgba(164, 113, 247, 0.1);
      border: 1px solid rgba(164, 113, 247, 0.3);
    }
    
    .search-category input[type="checkbox"],
    .search-platform input[type="checkbox"] {
      margin-right: 8px;
      accent-color: var(--accent-color);
      cursor: pointer;
      width: 16px;
      height: 16px;
    }
    
    /* Стили для контейнеров категорий и платформ */
    .search-categories {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: 10px;
    }
    
    .search-platforms {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
    }
    
    /* Стили для выбранных элементов */
    .search-category.selected, .search-platform.selected {
      background-color: rgba(164, 113, 247, 0.3);
      border-color: var(--accent-color);
    }
    
    /* Анимация для модальных окон */
    .modal {
      transition: opacity 0.3s ease;
    }
    
    /* Стили для выбранной опции доната */
    .selected-donate-info {
      margin-top: 20px;
      padding: 15px;
      background-color: rgba(255, 255, 255, 0.05);
      border-radius: 10px;
      border-left: 3px solid var(--accent-color);
    }
    
    .selected-donate-info h3 {
      margin-bottom: 10px;
      font-size: 1.1em;
      color: var(--accent-color);
    }
    
    .selected-donate-details {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    
    .selected-donate-title {
      font-weight: bold;
    }
    
    .selected-donate-description {
      font-size: 0.9em;
      color: rgba(255, 255, 255, 0.8);
    }
    
    .selected-donate-price {
      font-weight: bold;
      color: var(--accent-color);
    }
    
    /* Стили для счетчика результатов поиска */
    .results-count {
      margin-bottom: 15px;
      font-size: 1em;
      color: rgba(255, 255, 255, 0.9);
    }
    
    /* Стили для подсветки карточки игры */
    .game-card.highlight {
      box-shadow: 0 0 20px var(--accent-color), 0 0 40px rgba(164, 113, 247, 0.5);
      animation: pulse 1s ease-in-out;
    }
    
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
  `

  document.head.appendChild(style)

  // Добавляем контейнер для информации о выбранной опции доната
  const donatePaymentMethods = document.querySelector(".donate-payment-methods")
  if (donatePaymentMethods) {
    const selectedInfoContainer = document.createElement("div")
    selectedInfoContainer.id = "selected-donate-info"
    selectedInfoContainer.className = "selected-donate-info"

    // Вставляем контейнер перед методами оплаты
    donatePaymentMethods.parentNode.insertBefore(selectedInfoContainer, donatePaymentMethods)
  }
})

// Добавляем стили для бейджа "Новинки" в правом верхнем углу
const badgeStyle = document.createElement("style")
badgeStyle.textContent = `
  .card-badge.new {
    position: absolute;
    top: 10px;
    right: 10px;
    background-color: var(--success-color);
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-size: 0.8em;
    font-weight: bold;
    z-index: 2;
  }
`
document.head.appendChild(badgeStyle)

// Add a function to initialize platform logos on page load
document.addEventListener("DOMContentLoaded", () => {
  // Find all game cards
  const gameCards = document.querySelectorAll(".game-card")

  // Process each card
  gameCards.forEach((card) => {
    getGamePlatform(card)
  })

  // Add styles for platform logos and new items badge
  const style = document.createElement("style")
  style.textContent = `
    .platform-logo {
      position: absolute;
      bottom: 10px;
      right: 10px;
      width: 32px;
      height: 32px;
      background-color: rgba(0, 0, 0, 0.7);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 5;
      transition: all 0.3s ease;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
      overflow: hidden;
    }
    
    .platform-logo img {
      width: 22px;
      height: 22px;
      object-fit: contain;
    }
    
    .game-card:hover .platform-logo {
      transform: scale(1.1);
      box-shadow: 0 0 10px rgba(164, 113, 247, 0.5);
    }
    
    .card-badge.new {
      position: absolute;
      top: 10px;
      right: 10px;
      background-color: var(--success-color);
      color: white;
      padding: 5px 10px;
      border-radius: 5px;
      font-size: 0.8em;
      font-weight: bold;
      z-index: 2;
    }
  `
  document.head.appendChild(style)
})


// Инициализация анимаций для карточек игр и чекбоксов
document.addEventListener("DOMContentLoaded", function() {
  // Инициализация анимаций для карточек игр
  initGameCardAnimations();
  
  // Инициализация стилизованных чекбоксов
  initCustomCheckboxes();
});

// Функция для инициализации анимаций карточек игр
function initGameCardAnimations() {
  // Сбрасываем анимации для всех карточек
  const gameCards = document.querySelectorAll('.game-card');
  gameCards.forEach(card => {
    card.style.animation = 'none';
    card.offsetHeight; // Форсируем перерисовку
    card.style.animation = '';
    
    // Добавляем обработчики для эффектов при наведении
    card.addEventListener('mouseenter', function() {
      this.classList.add('hover-effect');
    });
    
    card.addEventListener('mouseleave', function() {
      this.classList.remove('hover-effect');
    });
  });
  
  // Добавляем обработчик для анимации при прокрутке
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        // Отключаем наблюдение после появления
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1 // Элемент считается видимым, когда 10% его площади видно
  });
  
  // Наблюдаем за всеми карточками
  gameCards.forEach(card => {
    observer.observe(card);
  });
}

// Функция для инициализации стилизованных чекбоксов
function initCustomCheckboxes() {
  // Находим все контейнеры чекбоксов
  const checkboxContainers = document.querySelectorAll('.search-category, .search-platform');
  
  checkboxContainers.forEach(container => {
    const checkbox = container.querySelector('input[type="checkbox"]');
    const label = document.createElement('label');
    
    // Если чекбокс уже обернут в label, пропускаем
    if (checkbox.parentNode.tagName === 'LABEL') return;
    
    // Получаем текст после чекбокса
    let text = checkbox.nextSibling;
    while (text && text.nodeType !== 1) {
      text = text.nextSibling;
    }
    
    // Если текст найден, используем его содержимое
    if (text) {
      label.textContent = text.textContent;
      container.removeChild(text);
    } else {
      // Иначе используем значение чекбокса
      label.textContent = checkbox.value;
    }
    
    // Устанавливаем атрибуты для связи label и checkbox
    const id = checkbox.id || `checkbox-${Math.random().toString(36).substr(2, 9)}`;
    checkbox.id = id;
    label.setAttribute('for', id);
    
    // Вставляем label после чекбокса
    checkbox.insertAdjacentElement('afterend', label);
    
    // Добавляем обработчик для изменения состояния контейнера
    checkbox.addEventListener('change', function() {
      if (this.checked) {
        container.classList.add('active');
      } else {
        container.classList.remove('active');
      }
    });
  });
  
  // Обрабатываем остальные чекбоксы на странице
  const otherCheckboxes = document.querySelectorAll('input[type="checkbox"]:not(.search-category input):not(.search-platform input)');
  otherCheckboxes.forEach(checkbox => {
    // Добавляем класс для стилизации
    checkbox.classList.add('custom-checkbox');
  });
}

// Функция для анимации выделения карточки
function highlightGameCard(cardElement) {
  if (!cardElement) return;
  
  // Удаляем предыдущие классы анимации
  cardElement.classList.remove('highlight');
  
  // Форсируем перерисовку
  cardElement.offsetWidth;
  
  // Добавляем класс анимации
  cardElement.classList.add('highlight');
  
  // Удаляем класс через некоторое время
  setTimeout(() => {
    cardElement.classList.remove('highlight');
  }, 4000);
}

// Обновляем обработчик для кнопок "Подробнее"
document.addEventListener('click', function(e) {
  if (e.target && e.target.classList.contains('search-result-btn')) {
    const gameName = e.target.getAttribute('data-game');
    const gameCards = document.querySelectorAll('.game-card');
    
    // Находим соответствующую карточку игры
    const gameCard = Array.from(gameCards).find((card) => {
      return card.querySelector('.game-title').textContent === gameName;
    });
    
    if (gameCard) {
      // Закрываем модальное окно
      const searchModal = document.getElementById('search-modal');
      if (searchModal) {
        searchModal.style.display = 'none';
      }
      document.body.style.overflow = ''; // Разблокируем прокрутку страницы
      
      setTimeout(() => {
        gameCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Анимируем выделение карточки
        highlightGameCard(gameCard);
      }, 300);
    }
  }
});

// Функция для анимации карточек результатов поиска
function animateSearchResults() {
  // Сбрасываем анимации для всех карточек
  const cards = document.querySelectorAll('.search-result-card');
  cards.forEach(card => {
    card.style.animation = 'none';
    card.offsetHeight; // Форсируем перерисовку
    card.style.animation = '';
  });
  
  // Анимируем счетчик результатов
  const resultsCount = document.querySelector('.results-count');
  if (resultsCount) {
    resultsCount.style.animation = 'none';
    resultsCount.offsetHeight; // Форсируем перерисовку
    resultsCount.style.animation = 'fadeInDown 0.5s forwards';
  }
  
  // Анимируем сообщение "Игры не найдены"
  const noResults = document.querySelector('.no-results');
  if (noResults) {
    noResults.style.animation = 'none';
    noResults.offsetHeight; // Форсируем перерисовку
    noResults.style.animation = 'fadeInUp 0.5s forwards';
  }
}

// Обновляем функцию отображения результатов поиска
document.addEventListener("DOMContentLoaded", function() {
  const applySearchButton = document.getElementById("apply-search");
  const searchResultsContainer = document.getElementById("search-results-container");

  if (applySearchButton && searchResultsContainer) {
    applySearchButton.addEventListener("click", function() {
      // Существующий код фильтрации игр...
      
      // После обновления результатов поиска запускаем анимацию
      setTimeout(animateSearchResults, 10);
    });
  }
  
  // Добавляем обработчик для кнопок "Подробнее"
  document.addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('search-result-btn')) {
      const gameName = e.target.getAttribute('data-game');
      const gameCards = document.querySelectorAll('.game-card');
      
      // Находим соответствующую карточку игры
      const gameCard = Array.from(gameCards).find((card) => {
        return card.querySelector('.game-title').textContent === gameName;
      });
      
      if (gameCard) {
        // Закрываем модальное окно
        const searchModal = document.getElementById('search-modal');
        if (searchModal) {
          searchModal.style.display = 'none';
        }
        document.body.style.overflow = ''; // Разблокируем прокрутку страницы
        
        setTimeout(() => {
          gameCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
          
          // Добавляем класс для анимации и удаляем его через некоторое время
          gameCard.classList.add('highlight');
          setTimeout(() => {
            gameCard.classList.remove('highlight');
          }, 3000);
        }, 300);
      }
    }
  });
});
document.addEventListener("DOMContentLoaded", function() {
  // Прелоадер
  const preloader = document.querySelector(".preloader");
  window.addEventListener("load", function() {
      setTimeout(() => {
          preloader.classList.add("hidden");
      }, 500);
  });

  // Анимация счетчиков
  const statNumbers = document.querySelectorAll(".stat-number");

  function animateStats() {
    statNumbers.forEach((stat) => {
      const target = stat.getAttribute("data-count");
      const isPlus = target.includes("+");
      const numTarget = parseInt(target);
      let count = 0;
      const duration = 2000; // 2 секунды
      const interval = 50; // 50 миллисекунд
      const increment = numTarget / (duration / interval);

      const timer = setInterval(() => {
        count += increment;
        if (count >= numTarget) {
          clearInterval(timer);
          stat.textContent = isPlus ? numTarget + "+" : numTarget;
        } else {
          stat.textContent = Math.floor(count);
        }
      }, interval);
    });
  }

  // Функция для открытия модальных окон с анимацией
  function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      // Добавляем анимацию появления
      modal.style.display = "block";
      modal.style.opacity = "0";
      document.body.style.overflow = "hidden"; // Блокируем прокрутку страницы
      
      setTimeout(() => {
        modal.style.opacity = "1";
        modal.style.transition = "opacity 0.3s ease";
      }, 10);
    }
  }

  // Функция для закрытия всех модальных окон с анимацией
  function closeAllModals() {
    const modals = document.querySelectorAll(".modal");
    modals.forEach((modal) => {
      modal.style.opacity = "0";
      modal.style.transition = "opacity 0.3s ease";
      
      setTimeout(() => {
        modal.style.display = "none";
      }, 300);
    });
    document.body.style.overflow = ""; // Разблокируем прокрутку страницы
  }

  // Кнопка "Наверх"
  const backToTopButton = document.getElementById("backToTop");

  window.addEventListener("scroll", () => {
    if (window.pageYOffset > 300) {
      backToTopButton.classList.add("visible");
    } else {
      backToTopButton.classList.remove("visible");
    }

    // Анимация счетчиков при прокрутке до них
    const statsSection = document.querySelector(".stats");
    if (statsSection && isElementInViewport(statsSection) && !statsSection.classList.contains("animated")) {
      statsSection.classList.add("animated");
      animateStats();
    }
  });

  backToTopButton.addEventListener("click", () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  });

  // Функция проверки, находится ли элемент в видимой области
  function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return rect.top <= window.innerHeight && rect.bottom >= 0;
  }

  // Анимация появления карточек игр
  const gameCards = document.querySelectorAll(".game-card");

  function checkGameCards() {
    gameCards.forEach((card) => {
      if (isElementInViewport(card) && !card.classList.contains("visible")) {
        card.classList.add("visible");
      }
    });
  }

  window.addEventListener("scroll", checkGameCards);
  window.addEventListener("resize", checkGameCards);
  checkGameCards(); // Проверяем при загрузке страницы

  // Фильтрация игр по категориям
  const categoryButtons = document.querySelectorAll(".category-btn");

  categoryButtons.forEach((button) => {
    button.addEventListener("click", function() {
      // Удаляем активный класс у всех кнопок
      categoryButtons.forEach((btn) => btn.classList.remove("active"));
      // Добавляем активный класс нажатой кнопке
      this.classList.add("active");

      const category = this.getAttribute("data-category");

      // Фильтруем игры по категории
      gameCards.forEach((card) => {
        if (category === "all") {
          card.style.display = "block";
        } else {
          const cardCategories = card.getAttribute("data-categories");
          if (cardCategories && cardCategories.includes(category)) {
            card.style.display = "block";
          } else {
            card.style.display = "none";
          }
        }
      });
    });
  });

  // Поиск игр
  const searchInput = document.getElementById("searchInput");
  const searchButton = document.getElementById("searchButton");

  searchButton.addEventListener("click", () => {
    const searchTerm = searchInput.value.toLowerCase();
    searchGames(searchTerm);
  });

  searchInput.addEventListener("keyup", (event) => {
    if (event.key === "Enter") {
      const searchTerm = searchInput.value.toLowerCase();
      searchGames(searchTerm);
    }
  });

  // Добавляем поиск в реальном времени
  searchInput.addEventListener("input", () => {
    const searchTerm = searchInput.value.toLowerCase();
    if (searchTerm.length >= 3) { // Поиск начинается от 3 символов
      searchGames(searchTerm);
    } else if (searchTerm.length === 0) {
      // Если поле поиска пустое, показываем все игры
      gameCards.forEach((card) => {
        card.style.display = "block";
      });
    }
  });

  function searchGames(searchTerm) {
    gameCards.forEach((card) => {
      const title = card.querySelector(".game-title").textContent.toLowerCase();
      const genre = card.querySelector(".game-genre").textContent.toLowerCase();

      if (title.includes(searchTerm) || genre.includes(searchTerm)) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  }

  // Модальное окно для доната
  const donateNavLink = document.getElementById("donate-nav-link");
  const donateBottomLink = document.getElementById("donate-bottom-link");
  const donateModal = document.getElementById("donate-modal");
  const closeModalButtons = document.querySelectorAll(".close-modal");
  const donateOptionsList = document.getElementById("donate-options-list");
  const donateGameTabs = document.querySelectorAll(".donate-game-tab");

  // Данные для опций доната по играм
  const donateOptions = {
    "Elden Ring": [
      { title: "Elden Ring: Интернет-подписка", description: "Доступ к онлайн-функциям игры на 30 дней", price: 299 },
      { title: "Elden Ring: 60 монохромов", description: "Базовый набор внутриигровой валюты", price: 499 },
      { title: "Elden Ring: 300 + 30 монохромов в подарок", description: "Стандартный набор с бонусом", price: 999 },
      { title: "Elden Ring: 980 + 110 монохромов в подарок", description: "Расширенный набор с бонусом", price: 1999 },
      { title: "Elden Ring: 1 980 + 260 монохромов в подарок", description: "Премиум набор с бонусом", price: 3999 },
      { title: "Elden Ring: 3 280 + 600 монохромов в подарок", description: "VIP набор с бонусом", price: 5999 },
      { title: "Elden Ring: 6 480 + 1 600 монохромов в подарок", description: "Максимальный набор с бонусом", price: 9999 },
    ],
    "Genshin Impact": [
      { title: "Genshin Impact: Благословение полой луны", description: "Ежедневные примогемы в течение 30 дней", price: 299 },
      { title: "Genshin Impact: 60 кристаллов", description: "Базовый набор внутриигровой валюты", price: 499 },
      { title: "Genshin Impact: 300 + 30 кристаллов в подарок", description: "Стандартный набор с бонусом", price: 999 },
      { title: "Genshin Impact: 980 + 110 кристаллов в подарок", description: "Расширенный набор с бонусом", price: 1999 },
      { title: "Genshin Impact: 1 980 + 260 кристаллов в подарок", description: "Премиум набор с бонусом", price: 3999 },
      { title: "Genshin Impact: 3 280 + 600 кристаллов в подарок", description: "VIP набор с бонусом", price: 5999 },
      { title: "Genshin Impact: 6 480 + 1 600 кристаллов в подарок", description: "Максимальный набор с бонусом", price: 9999 },
    ],
    "Zenless Zone Zero": [
      { title: "Zenless Zone Zero: Интернет-подписка", description: "Доступ к онлайн-функциям игры на 30 дней", price: 299 },
      { title: "Zenless Zone Zero: 60 монохромов", description: "Базовый набор внутриигровой валюты", price: 499 },
      { title: "Zenless Zone Zero: 300 + 30 монохромов в подарок", description: "Стандартный набор с бонусом", price: 999 },
      { title: "Zenless Zone Zero: 980 + 110 монохромов в подарок", description: "Расширенный набор с бонусом", price: 1999 },
      { title: "Zenless Zone Zero: 1 980 + 260 монохромов в подарок", description: "Премиум набор с бонусом", price: 3999 },
      { title: "Zenless Zone Zero: 3 280 + 600 монохромов в подарок", description: "VIP набор с бонусом", price: 5999 },
      { title: "Zenless Zone Zero: 6 480 + 1 600 монохромов в подарок", description: "Максимальный набор с бонусом", price: 9999 },
    ],
    "Cyberpunk 2077": [
      { title: "Cyberpunk 2077: Интернет-подписка", description: "Доступ к онлайн-функциям игры на 30 дней", price: 299 },
      { title: "Cyberpunk 2077: 60 эдди", description: "Базовый набор внутриигровой валюты", price: 499 },
      { title: "Cyberpunk 2077: 300 + 30 эдди в подарок", description: "Стандартный набор с бонусом", price: 999 },
      { title: "Cyberpunk 2077: 980 + 110 эдди в подарок", description: "Расширенный набор с бонусом", price: 1999 },
      { title: "Cyberpunk 2077: 1 980 + 260 эдди в подарок", description: "Премиум набор с бонусом", price: 3999 },
      { title: "Cyberpunk 2077: 3 280 + 600 эдди в подарок", description: "VIP набор с бонусом", price: 5999 },
      { title: "Cyberpunk 2077: 6 480 + 1 600 эдди в подарок", description: "Максимальный набор с бонусом", price: 9999 },
    ],
    "S.T.A.L.K.E.R 2": [
      { title: "S.T.A.L.K.E.R 2: Интернет-подписка", description: "Доступ к онлайн-функциям игры на 30 дней", price: 299 },
      { title: "S.T.A.L.K.E.R 2: 60 артефактов", description: "Базовый набор внутриигровой валюты", price: 499 },
      { title: "S.T.A.L.K.E.R 2: 300 + 30 артефактов в подарок", description: "Стандартный набор с бонусом", price: 999 },
      { title: "S.T.A.L.K.E.R 2: 980 + 110 артефактов в подарок", description: "Расширенный набор с бонусом", price: 1999 },
      { title: "S.T.A.L.K.E.R 2: 1 980 + 260 артефактов в подарок", description: "Премиум набор с бонусом", price: 3999 },
      { title: "S.T.A.L.K.E.R 2: 3 280 + 600 артефактов в подарок", description: "VIP набор с бонусом", price: 5999 },
      { title: "S.T.A.L.K.E.R 2: 6 480 + 1 600 артефактов в подарок", description: "Максимальный набор с бонусом", price: 9999 },
    ],
  };

  // Функция для отображения опций доната для выбранной игры
  function showDonateOptions(gameName) {
    // Очищаем список опций
    donateOptionsList.innerHTML = "";

    // Получаем опции для выбранной игры
    const options = donateOptions[gameName] || [];

    // Добавляем опции в список
    options.forEach((option, index) => {
      const optionItem = document.createElement("div");
      optionItem.className = "donate-option-item";
      optionItem.setAttribute("data-index", index);

      optionItem.innerHTML = `
        <div class="donate-option-icon">
          <i class="fas fa-gift"></i>
        </div>
        <div class="donate-option-info">
          <div class="donate-option-title">${option.title}</div>
          <div class="donate-option-description">${option.description || "Поддержите разработчиков и получите внутриигровые предметы"}</div>
        </div>
        <div class="donate-option-price">${option.price} ₽</div>
      `;

      optionItem.addEventListener("click", function() {
        // Удаляем класс selected у всех опций
        document.querySelectorAll(".donate-option-item").forEach((item) => {
          item.classList.remove("selected");
        });
        // Добавляем класс selected выбранной опции
        this.classList.add("selected");
        
        // Обновляем информацию о выбранной опции
        updateSelectedDonateInfo(option);
      });

      donateOptionsList.appendChild(optionItem);
    });

    // Выбираем первую опцию по умолчанию
    if (donateOptionsList.firstChild) {
      donateOptionsList.firstChild.classList.add("selected");
      // Обновляем информацию о выбранной опции
      updateSelectedDonateInfo(options[0]);
    }
  }
  
  // Функция для обновления информации о выбранной опции доната
  function updateSelectedDonateInfo(option) {
    const selectedInfoContainer = document.getElementById("selected-donate-info");
    if (selectedInfoContainer) {
      selectedInfoContainer.innerHTML = `
        <h3>Выбранная опция:</h3>
        <div class="selected-donate-details">
          <div class="selected-donate-title">${option.title}</div>
          <div class="selected-donate-description">${option.description || "Поддержите разработчиков и получите внутриигровые предметы"}</div>
          <div class="selected-donate-price">Стоимость: ${option.price} ₽</div>
        </div>
      `;
    }
  }

  // Обработчики для вкладок игр
  donateGameTabs.forEach((tab) => {
    tab.addEventListener("click", function() {
      // Удаляем активный класс у всех вкладок
      donateGameTabs.forEach((t) => t.classList.remove("active"));
      // Добавляем активный класс нажатой вкладке
      this.classList.add("active");

      // Показываем опции для выбранной игры
      const gameName = this.getAttribute("data-game");
      showDonateOptions(gameName);
    });
  });

  // Открытие модального окна доната при клике на ссылку в навигации
  if (donateNavLink) {
    donateNavLink.addEventListener("click", function(e) {
      e.preventDefault();
      openDonateModal();
    });
  }

  // Открытие модального окна доната при клике на ссылку в нижней навигации
  if (donateBottomLink) {
    donateBottomLink.addEventListener("click", function(e) {
      e.preventDefault();
      openDonateModal();
    });
  }

  // Функция открытия модального окна доната
  function openDonateModal() {
    // Показываем опции для игры по умолчанию (первая вкладка)
    const defaultGameTab = document.querySelector(".donate-game-tab.active") || document.querySelector(".donate-game-tab");
    if (defaultGameTab) {
      defaultGameTab.classList.add("active");
      const gameName = defaultGameTab.getAttribute("data-game");
      showDonateOptions(gameName);
    }

    // Открываем модальное окно
    openModal("donate-modal");
  }

  // Закрытие модальных окон
  closeModalButtons.forEach((button) => {
    button.addEventListener("click", closeAllModals);
  });

  // Закрытие модального окна при клике вне его содержимого
  window.addEventListener("click", (event) => {
    const modals = document.querySelectorAll(".modal");
    modals.forEach((modal) => {
      if (event.target === modal) {
        closeAllModals();
      }
    });
  });

  // Закрытие модального окна при нажатии клавиши Escape
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeAllModals();
    }
  });

  // Кнопка "Посмотреть больше игр"
  const moreGamesButton = document.getElementById("more-games-btn");
  const searchModal = document.getElementById("search-modal");

  if (moreGamesButton) {
    moreGamesButton.addEventListener("click", function() {
      // Открываем модальное окно расширенного поиска
      openModal("search-modal");
      
      // Сбрасываем фильтры при открытии
      resetSearchFilters();
      
      // Обновляем платформы в модальном окне
      updatePlatformsInModal();
    });
  }
  
  // Функция для обновления платформ в модальном окне
  function updatePlatformsInModal() {
    const platformsContainer = document.querySelector(".search-platforms");
    if (platformsContainer) {
      // Очищаем контейнер платформ
      platformsContainer.innerHTML = "";
      
      // Добавляем только Steam и Rock Star Games
      platformsContainer.innerHTML = `
        <label class="search-platform">
          <input type="checkbox" value="steam"> Steam
        </label>
        <label class="search-platform">
          <input type="checkbox" value="rockstar"> Rock Star Games
        </label>
      `;
    }
  }
  
  // Функция сброса фильтров поиска
  function resetSearchFilters() {
    // Сбрасываем поле поиска
    const searchNameInput = document.getElementById("search-name");
    if (searchNameInput) {
      searchNameInput.value = "";
    }
    
    // Сбрасываем чекбоксы категорий
    document.querySelectorAll(".search-category input").forEach(checkbox => {
      checkbox.checked = false;
    });
    
    // Сбрасываем чекбоксы платформ
    document.querySelectorAll(".search-platform input").forEach(checkbox => {
      checkbox.checked = false;
    });
    
    // Сбрасываем диапазон цен
    const minPriceInput = document.getElementById("search-min-price");
    const maxPriceInput = document.getElementById("search-max-price");
    if (minPriceInput && maxPriceInput) {
      minPriceInput.value = "0";
      maxPriceInput.value = "5000";
    }
    
    // Сбрасываем рейтинг
    const ratingSelect = document.getElementById("search-rating");
    if (ratingSelect) {
      ratingSelect.value = "0";
    }
    
    // Очищаем результаты поиска
    const searchResultsContainer = document.getElementById("search-results-container");
    if (searchResultsContainer) {
      searchResultsContainer.innerHTML = '<div class="no-results">Используйте фильтры для поиска игр</div>';
    }
  }

  // Расширенный поиск игр
  const applySearchButton = document.getElementById("apply-search");
  const searchResultsContainer = document.getElementById("search-results-container");

  if (applySearchButton) {
    applySearchButton.addEventListener("click", function() {
      const searchName = document.getElementById("search-name").value.toLowerCase();
      const searchMinPrice = parseInt(document.getElementById("search-min-price").value);
      const searchMaxPrice = parseInt(document.getElementById("search-max-price").value);
      const searchRating = parseInt(document.getElementById("search-rating").value);

      // Получаем выбранные категории
      const selectedCategories = [];
      document.querySelectorAll(".search-category input:checked").forEach((checkbox) => {
        selectedCategories.push(checkbox.value);
      });

      // Получаем выбранные платформы
      const selectedPlatforms = [];
      document.querySelectorAll(".search-platform input:checked").forEach((checkbox) => {
        selectedPlatforms.push(checkbox.value);
      });

      // Фильтруем игры
      const filteredGames = Array.from(gameCards).filter((card) => {
        const title = card.querySelector(".game-title").textContent.toLowerCase();
        const priceText = card.querySelector(".game-price").textContent;
        let price = 0;

        // Извлекаем числовое значение цены
        if (priceText !== "Нет в наличие") {
          price = parseInt(priceText.replace(/\D/g, ""));
        }

        const cardCategories = card.getAttribute("data-categories") || "";
        const cardPlatforms = card.getAttribute("data-platform") || "";

        // Проверяем рейтинг
        const ratingElement = card.querySelector(".rating span");
        let rating = 0;
        if (ratingElement) {
          const ratingText = ratingElement.textContent;
          rating = parseFloat(ratingText.replace(/[()]/g, ""));
        }

        // Проверяем соответствие всем критериям
        const nameMatch = searchName === "" || title.includes(searchName);
        const priceMatch = price >= searchMinPrice && price <= searchMaxPrice;
        const ratingMatch = searchRating === 0 || rating >= searchRating;

        // Проверяем категории
        let categoryMatch = true;
        if (selectedCategories.length > 0) {
          categoryMatch = selectedCategories.some((category) => cardCategories.includes(category));
        }

        // Проверяем платформы
        let platformMatch = true;
        if (selectedPlatforms.length > 0) {
          // Преобразуем платформы карточки в соответствии с новыми значениями
          const mappedPlatforms = cardPlatforms.includes("pc") ? "steam" : 
                                 (cardPlatforms.includes("playstation") ? "rockstar" : cardPlatforms);
          
          platformMatch = selectedPlatforms.some((platform) => mappedPlatforms.includes(platform));
        }

        return nameMatch && priceMatch && ratingMatch && categoryMatch && platformMatch;
      });

      // Отображаем результаты поиска
      searchResultsContainer.innerHTML = "";

      if (filteredGames.length === 0) {
        searchResultsContainer.innerHTML = '<div class="no-results">Игры не найдены</div>';
      } else {
        // Добавляем счетчик найденных игр
        const resultsCount = document.createElement("div");
        resultsCount.className = "results-count";
        resultsCount.innerHTML = `Найдено игр: <strong>${filteredGames.length}</strong>`;
        searchResultsContainer.appendChild(resultsCount);
        
        // Создаем контейнер для карточек
        const resultsGrid = document.createElement("div");
        resultsGrid.className = "search-results-grid";
        // Устанавливаем стиль для отображения 3 игр в ряд
        resultsGrid.style.gridTemplateColumns = "repeat(3, 1fr)";
        searchResultsContainer.appendChild(resultsGrid);
        
        filteredGames.forEach((game) => {
          const title = game.querySelector(".game-title").textContent;
          const price = game.querySelector(".game-price").textContent;
          const imgSrc = game.querySelector("img").src;
          const platforms = game.getAttribute("data-platform") || "";

          // Преобразуем платформы для отображения
          const displayPlatforms = platforms.includes("pc") ? "Steam" : 
                                  (platforms.includes("playstation") ? "Rock Star Games" : formatPlatforms(platforms));

          // Создаем карточку результата поиска
          const resultCard = document.createElement("div");
          resultCard.className = "search-result-card";

          resultCard.innerHTML = `
            <img src="${imgSrc}" alt="${title}">
            <div class="search-result-info">
              <h4 class="search-result-title">${title}</h4>
              <div class="search-result-price">${price}</div>
              <div class="search-result-platform">Платформа: ${displayPlatforms}</div>
              <button class="search-result-btn" data-game="${title}">Подробнее</button>
            </div>
          `;

          resultsGrid.appendChild(resultCard);
        });

        // Добавляем обработчики для кнопок "Подробнее"
        document.querySelectorAll(".search-result-btn").forEach((button) => {
          button.addEventListener("click", function() {
            const gameName = this.getAttribute("data-game");

            // Находим соответствующую карточку игры
            const gameCard = Array.from(gameCards).find((card) => {
              return card.querySelector(".game-title").textContent === gameName;
            });

            if (gameCard) {
              // Прокручиваем к карточке игры
              closeAllModals();

              setTimeout(() => {
                gameCard.scrollIntoView({ behavior: "smooth", block: "center" });

                // Подсвечиваем карточку
                gameCard.classList.add("highlight");
                setTimeout(() => {
                  gameCard.classList.remove("highlight");
                }, 2000);
              }, 300);
            }
          });
        });
      }
    });
  }

  // Форматирование платформ для отображения
  function formatPlatforms(platforms) {
    if (!platforms) return "Не указано";

    // Обновленная карта платформ
    const platformMap = {
      pc: "Steam",
      playstation: "Rock Star Games",
      xbox: "Xbox",
      nintendo: "Nintendo",
    };

    return platforms
      .split(" ")
      .map((p) => platformMap[p] || p)
      .join(", ");
  }

  // Инициализация первой вкладки доната при загрузке страницы
  const firstDonateTab = document.querySelector(".donate-game-tab");
  if (firstDonateTab) {
    firstDonateTab.classList.add("active");
    const gameName = firstDonateTab.getAttribute("data-game");
    if (gameName) {
      showDonateOptions(gameName);
    }
  }
  
  // Обновляем платформы в модальном окне при загрузке страницы
  document.addEventListener("DOMContentLoaded", function() {
    updatePlatformsInModal();
    
    // Добавляем стили для сетки результатов поиска
    const style = document.createElement("style");
    style.textContent = `
      .search-results-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr) !important;
        gap: 20px;
      }
      
      @media (max-width: 768px) {
        .search-results-grid {
          grid-template-columns: repeat(2, 1fr) !important;
        }
      }
      
      @media (max-width: 480px) {
        .search-results-grid {
          grid-template-columns: 1fr !important;
        }
      }
    `;
    document.head.appendChild(style);
  });
});

// Добавляем стили для кастомных чекбоксов
document.addEventListener("DOMContentLoaded", function() {
  const style = document.createElement("style");
  style.textContent = `
    /* Стили для кастомных чекбоксов */
    .search-category, .search-platform {
      position: relative;
      display: flex;
      align-items: center;
      background-color: rgba(164, 113, 247, 0.1);
      border: 1px solid rgba(164, 113, 247, 0.3);
    }
    
    .search-category input[type="checkbox"],
    .search-platform input[type="checkbox"] {
      margin-right: 8px;
      accent-color: var(--accent-color);
      cursor: pointer;
      width: 16px;
      height: 16px;
    }
    
    /* Стили для контейнеров категорий и платформ */
    .search-categories {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: 10px;
    }
    
    .search-platforms {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
    }
    
    /* Стили для выбранных элементов */
    .search-category.selected, .search-platform.selected {
      background-color: rgba(164, 113, 247, 0.3);
      border-color: var(--accent-color);
    }
    
    /* Анимация для модальных окон */
    .modal {
      transition: opacity 0.3s ease;
    }
    
    /* Стили для выбранной опции доната */
    .selected-donate-info {
      margin-top: 20px;
      padding: 15px;
      background-color: rgba(255, 255, 255, 0.05);
      border-radius: 10px;
      border-left: 3px solid var(--accent-color);
    }
    
    .selected-donate-info h3 {
      margin-bottom: 10px;
      font-size: 1.1em;
      color: var(--accent-color);
    }
    
    .selected-donate-details {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    
    .selected-donate-title {
      font-weight: bold;
    }
    
    .selected-donate-description {
      font-size: 0.9em;
      color: rgba(255, 255, 255, 0.8);
    }
    
    .selected-donate-price {
      font-weight: bold;
      color: var(--accent-color);
    }
    
    /* Стили для счетчика результатов поиска */
    .results-count {
      margin-bottom: 15px;
      font-size: 1em;
      color: rgba(255, 255, 255, 0.9);
    }
    
    /* Стили для подсветки карточки игры */
    .game-card.highlight {
      box-shadow: 0 0 20px var(--accent-color), 0 0 40px rgba(164, 113, 247, 0.5);
      animation: pulse 1s ease-in-out;
    }
    
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
  `;
  
  document.head.appendChild(style);
  
  // Добавляем контейнер для информации о выбранной опции доната
  const donatePaymentMethods = document.querySelector(".donate-payment-methods");
  if (donatePaymentMethods) {
    const selectedInfoContainer = document.createElement("div");
    selectedInfoContainer.id = "selected-donate-info";
    selectedInfoContainer.className = "selected-donate-info";
    
    // Вставляем контейнер перед методами оплаты
    donatePaymentMethods.parentNode.insertBefore(selectedInfoContainer, donatePaymentMethods);
  }
});