// Function to check if user is logged in
function isLoggedIn() {
  return localStorage.getItem('currentUser') !== null;
}

// Function to get current user data
function getCurrentUser() {
  const userData = localStorage.getItem('currentUser');
  return userData ? JSON.parse(userData) : null;
}

// Function to register a new user
function registerUser(name, email, password) {
  // Get existing users or initialize empty array
  const users = JSON.parse(localStorage.getItem('users')) || [];
  
  // Check if user with this email already exists
  const existingUser = users.find(user => user.email === email);
  if (existingUser) {
    return { success: false, message: 'Пользователь с таким email уже существует' };
  }
  
  // Create new user object
  const newUser = {
    id: Date.now().toString(),
    name,
    email,
    password, // In a real app, you should hash the password
    createdAt: new Date().toISOString()
  };
  
  // Add to users array
  users.push(newUser);
  
  // Save back to localStorage
  localStorage.setItem('users', JSON.stringify(users));
  
  return { success: true, message: 'Регистрация прошла успешно' };
}

// Function to login a user
function loginUser(email, password) {
  // Get existing users
  const users = JSON.parse(localStorage.getItem('users')) || [];
  
  // Find user with matching credentials
  const user = users.find(user => user.email === email && user.password === password);
  
  if (!user) {
    return { success: false, message: 'Неверный email или пароль' };
  }
  
  // Store current user in localStorage (without password for security)
  const currentUser = { ...user };
  delete currentUser.password;
  localStorage.setItem('currentUser', JSON.stringify(currentUser));
  
  return { success: true, message: 'Вход выполнен успешно' };
}

// Function to logout user
function logoutUser() {
  localStorage.removeItem('currentUser');
  return { success: true, message: 'Выход выполнен успешно' };
}

// Function to update user profile
function updateUserProfile(name, email) {
  // Get current user
  const currentUser = getCurrentUser();
  if (!currentUser) {
    return { success: false, message: 'Пользователь не авторизован' };
  }
  
  // Get all users
  const users = JSON.parse(localStorage.getItem('users')) || [];
  
  // Find and update user
  const userIndex = users.findIndex(user => user.id === currentUser.id);
  if (userIndex === -1) {
    return { success: false, message: 'Пользователь не найден' };
  }
  
  // Update user data
  users[userIndex].name = name;
  
  // Only update email if it's different
  if (email !== users[userIndex].email) {
    // Check if new email already exists
    const emailExists = users.some(user => user.email === email && user.id !== currentUser.id);
    if (emailExists) {
      return { success: false, message: 'Пользователь с таким email уже существует' };
    }
    users[userIndex].email = email;
  }
  
  // Save back to localStorage
  localStorage.setItem('users', JSON.stringify(users));
  
  // Update current user
  const updatedUser = { ...users[userIndex] };
  delete updatedUser.password;
  localStorage.setItem('currentUser', JSON.stringify(updatedUser));
  
  return { success: true, message: 'Профиль успешно обновлен' };
}

// Function to change password
function changePassword(currentPassword, newPassword) {
  // Get current user
  const currentUser = getCurrentUser();
  if (!currentUser) {
    return { success: false, message: 'Пользователь не авторизован' };
  }
  
  // Get all users
  const users = JSON.parse(localStorage.getItem('users')) || [];
  
  // Find user
  const userIndex = users.findIndex(user => user.id === currentUser.id);
  if (userIndex === -1) {
    return { success: false, message: 'Пользователь не найден' };
  }
  
  // Verify current password
  if (users[userIndex].password !== currentPassword) {
    return { success: false, message: 'Текущий пароль неверен' };
  }
  
  // Update password
  users[userIndex].password = newPassword;
  
  // Save back to localStorage
  localStorage.setItem('users', JSON.stringify(users));
  
  return { success: true, message: 'Пароль успешно изменен' };
}