import telebot
import json
import os
import time
import threading
import random
import string
import csv
import io
from telebot import types
from datetime import datetime, timedelta

# Initialize bot with your token (you'll need to replace this with your actual token)
TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
bot = telebot.TeleBot(TOKEN)

# Files for data storage
ORDERS_FILE = "orders.json"
INVENTORY_FILE = "inventory.json"
USERS_FILE = "users.json"
PROMO_FILE = "promo_codes.json"
STATS_FILE = "statistics.json"
REFERRAL_FILE = "referrals.json"

# Initialize files if they don't exist
def initialize_files():
    files = {
        ORDERS_FILE: [],
        INVENTORY_FILE: {},
        USERS_FILE: {},
        PROMO_FILE: {},
        STATS_FILE: {"daily_sales": {}, "total_sales": 0, "total_revenue": 0},
        REFERRAL_FILE: {}
    }

    for file_path, default_data in files.items():
        if not os.path.exists(file_path):
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(default_data, f, indent=4)

    # Initialize inventory with sample codes if empty
    inventory = load_data(INVENTORY_FILE)
    if not inventory:
        inventory = {
            "1": generate_sample_codes(5, "500₽"),  # 5 codes for 500₽ cards
            "2": generate_sample_codes(5, "1000₽"),  # 5 codes for 1000₽ cards
            "3": generate_sample_codes(3, "2000₽"),  # 3 codes for 2000₽ cards
            "4": generate_sample_codes(2, "5000₽"),  # 2 codes for 5000₽ cards
        }
        save_data(inventory, INVENTORY_FILE)

    # Initialize promo codes if empty
    promo_codes = load_data(PROMO_FILE)
    if not promo_codes:
        promo_codes = {
            "WELCOME10": {
                "discount_percent": 10,
                "valid_until": (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d"),
                "max_uses": 100,
                "used": 0,
                "description": "Скидка 10% для новых пользователей"
            },
            "STEAM20": {
                "discount_percent": 20,
                "valid_until": (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d"),
                "max_uses": 50,
                "used": 0,
                "description": "Скидка 20% на все карты Steam"
            }
        }
        save_data(promo_codes, PROMO_FILE)

# Generate sample Steam codes for testing
def generate_sample_codes(count, value):
    codes = []
    for _ in range(count):
        # Format: XXXXX-XXXXX-XXXXX (Steam-like code)
        code = "-".join(
            "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
            for _ in range(3)
        )
        codes.append({
            "code": code,
            "value": value,
            "status": "available",
            "added_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
    return codes

# Available Steam gift cards
steam_cards = [
    {"id": 1, "name": "Steam Gift Card 500₽", "price": 550, "image": "🎮"},
    {"id": 2, "name": "Steam Gift Card 1000₽", "price": 1100, "image": "🎮"},
    {"id": 3, "name": "Steam Gift Card 2000₽", "price": 2200, "image": "🎮"},
    {"id": 4, "name": "Steam Gift Card 5000₽", "price": 5500, "image": "🎮"}
]

# Payment methods (simulated)
payment_methods = [
    {"id": 1, "name": "QIWI", "icon": "💳"},
    {"id": 2, "name": "Банковская карта", "icon": "💳"},
    {"id": 3, "name": "Криптовалюта", "icon": "💰"},
    {"id": 4, "name": "Яндекс.Деньги", "icon": "💵"}
]

# Admin user IDs (replace with actual admin Telegram IDs)
ADMIN_IDS = [123456789]

# User states
user_states = {}

# Helper functions for data management
def load_data(filename):
    try:
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_data(data, filename):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def load_orders():
    return load_data(ORDERS_FILE)

def save_order(order_data):
    orders = load_orders()
    orders.append(order_data)
    save_data(orders, ORDERS_FILE)

    # Update statistics
    update_statistics(order_data)

def load_inventory():
    return load_data(INVENTORY_FILE)

def save_inventory(inventory):
    save_data(inventory, INVENTORY_FILE)

def load_users():
    return load_data(USERS_FILE)

def save_users(users):
    save_data(users, USERS_FILE)

def load_promo_codes():
    return load_data(PROMO_FILE)

def save_promo_codes(promo_codes):
    save_data(promo_codes, PROMO_FILE)

def load_statistics():
    return load_data(STATS_FILE)

def save_statistics(stats):
    save_data(stats, STATS_FILE)

def load_referrals():
    return load_data(REFERRAL_FILE)

def save_referrals(referrals):
    save_data(referrals, REFERRAL_FILE)

def update_statistics(order_data):
    stats = load_statistics()

    # Update total stats
    stats["total_sales"] += 1
    stats["total_revenue"] += order_data.get("price", 0)

    # Update daily stats
    today = datetime.now().strftime("%Y-%m-%d")
    if today not in stats["daily_sales"]:
        stats["daily_sales"][today] = {"sales": 0, "revenue": 0}

    stats["daily_sales"][today]["sales"] += 1
    stats["daily_sales"][today]["revenue"] += order_data.get("price", 0)

    save_statistics(stats)

def get_user_data(user_id):
    users = load_users()
    user_id_str = str(user_id)
    if user_id_str not in users:
        users[user_id_str] = {
            "orders": [],
            "registration_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "last_activity": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "verified": False,
            "referral_code": generate_referral_code(),
            "referred_by": None,
            "bonus_balance": 0
        }
        save_users(users)
    return users[user_id_str]

def update_user_activity(user_id):
    users = load_users()
    user_id_str = str(user_id)
    if user_id_str in users:
        users[user_id_str]["last_activity"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        save_users(users)

def add_order_to_user(user_id, order_id):
    users = load_users()
    user_id_str = str(user_id)
    if user_id_str in users:
        if "orders" not in users[user_id_str]:
            users[user_id_str]["orders"] = []
        users[user_id_str]["orders"].append(order_id)
        save_users(users)

def get_available_code(card_id):
    inventory = load_inventory()
    card_id_str = str(card_id)

    if card_id_str in inventory:
        for code_data in inventory[card_id_str]:
            if code_data["status"] == "available":
                code_data["status"] = "sold"
                code_data["sold_date"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                save_inventory(inventory)
                return code_data["code"]

    return None

def count_available_codes(card_id):
    inventory = load_inventory()
    card_id_str = str(card_id)

    if card_id_str in inventory:
        return sum(1 for code in inventory[card_id_str] if code["status"] == "available")

    return 0

def generate_order_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

def generate_referral_code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

def apply_promo_code(promo_code, price):
    promo_codes = load_promo_codes()

    if promo_code.upper() in promo_codes:
        promo_data = promo_codes[promo_code.upper()]
        
        # Check if promo code is still valid
        valid_until = datetime.strptime(promo_data["valid_until"], "%Y-%m-%d")
        if valid_until < datetime.now():
            return None, "Промокод истек"
        
        # Check if promo code has reached max uses
        if promo_data["used"] >= promo_data["max_uses"]:
            return None, "Промокод больше не действителен"
        
        # Apply discount
        discount_percent = promo_data["discount_percent"]
        discount_amount = int(price * discount_percent / 100)
        new_price = price - discount_amount
        
        # Update promo code usage
        promo_data["used"] += 1
        save_promo_codes(promo_codes)
        
        return new_price, f"Применена скидка {discount_percent}%"

    return None, "Промокод не найден"

def process_referral(user_id, order_amount):
    users = load_users()
    referrals = load_referrals()
    user_id_str = str(user_id)

    if user_id_str in users and users[user_id_str]["referred_by"]:
        referrer_id = users[user_id_str]["referred_by"]
        
        # Calculate bonus (5% of order amount)
        bonus_amount = int(order_amount * 0.05)
        
        # Add bonus to referrer
        if referrer_id in users:
            users[referrer_id]["bonus_balance"] = users[referrer_id].get("bonus_balance", 0) + bonus_amount
            
            # Update referral stats
            if referrer_id not in referrals:
                referrals[referrer_id] = {"referrals": [], "total_bonus": 0}
            
            if user_id_str not in referrals[referrer_id]["referrals"]:
                referrals[referrer_id]["referrals"].append(user_id_str)
            
            referrals[referrer_id]["total_bonus"] += bonus_amount
            
            # Save changes
            save_users(users)
            save_referrals(referrals)
            
            # Notify referrer
            try:
                bot.send_message(
                    int(referrer_id),
                    f"🎁 Вы получили реферальный бонус в размере {bonus_amount}₽ за покупку вашего друга!"
                )
            except Exception:
                pass

# Process order (simulated payment)
def process_order(user_id, card_id, payment_method_id, steam_id, promo_code=None):
    selected_card = next((card for card in steam_cards if card["id"] == card_id), None)
    payment_method = next((method for method in payment_methods if method["id"] == payment_method_id), None)

    if not selected_card or not payment_method:
        return None

    # Get a code from inventory
    code = get_available_code(card_id)
    if not code:
        return None

    # Apply promo code if provided
    price = selected_card["price"]
    discount_message = ""

    if promo_code:
        new_price, message = apply_promo_code(promo_code, price)
        if new_price:
            price = new_price
            discount_message = message

    # Generate unique order ID
    order_id = generate_order_id()

    # Create order
    order_data = {
        "order_id": order_id,
        "user_id": user_id,
        "user_name": f"User {user_id}",  # In a real bot, you'd get the actual username
        "product_id": card_id,
        "product_name": selected_card["name"],
        "original_price": selected_card["price"],
        "price": price,
        "discount": selected_card["price"] - price if price != selected_card["price"] else 0,
        "promo_code": promo_code.upper() if promo_code else None,
        "payment_method": payment_method["name"],
        "steam_id": steam_id,
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status": "completed",
        "code": code
    }

    # Process referral bonus
    process_referral(user_id, price)

    # Save order
    save_order(order_data)

    # Add order to user's history
    add_order_to_user(user_id, order_id)

    return order_data, discount_message

# Start command handler
@bot.message_handler(commands=['start'])
def start(message):
    user_id = message.from_user.id
    user_states[user_id] = {"state": "main_menu"}

    # Check if this is a referral link
    if len(message.text.split()) > 1:
        referral_code = message.text.split()[1]
        handle_referral(user_id, referral_code)

    # Initialize user data
    user_data = get_user_data(user_id)
    update_user_activity(user_id)

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(types.KeyboardButton("🎮 Купить Steam карту"))
    markup.add(types.KeyboardButton("📋 Мои заказы"), types.KeyboardButton("🔍 Проверить наличие"))
    markup.add(types.KeyboardButton("🎁 Промокоды"), types.KeyboardButton("👥 Реферальная программа"))
    markup.add(types.KeyboardButton("ℹ️ О магазине"), types.KeyboardButton("📞 Поддержка"))

    bot.send_message(
        message.chat.id,
        f"👋 Добро пожаловать в VolkStore!\n\n"
        f"Здесь вы можете приобрести карты пополнения Steam по выгодным ценам.",
        reply_markup=markup
    )

def handle_referral(user_id, referral_code):
    users = load_users()
    user_id_str = str(user_id)

    # Find user with this referral code
    referrer_id = None
    for uid, data in users.items():
        if data.get("referral_code") == referral_code:
            referrer_id = uid
            break

    if referrer_id and referrer_id != user_id_str:
        # Check if user is already in the system
        if user_id_str in users:
            # Only set referrer if not already set
            if not users[user_id_str]["referred_by"]:
                users[user_id_str]["referred_by"] = referrer_id
                save_users(users)
                
                # Notify referrer
                try:
                    bot.send_message(
                        int(referrer_id),
                        f"🎉 Новый пользователь присоединился по вашей реферальной ссылке!"
                    )
                except Exception:
                    pass
                
                bot.send_message(
                    user_id,
                    "🎉 Вы успешно присоединились по реферальной ссылке! При покупке ваш друг получит бонус."
                )
        else:
            # New user, set referrer
            user_data = get_user_data(user_id)
            user_data["referred_by"] = referrer_id
            users[user_id_str] = user_data
            save_users(users)
            
            # Notify referrer
            try:
                bot.send_message(
                    int(referrer_id),
                    f"🎉 Новый пользователь присоединился по вашей реферальной ссылке!"
                )
            except Exception:
                pass
            
            bot.send_message(
                user_id,
                "🎉 Вы успешно присоединились по реферальной ссылке! При покупке ваш друг получит бонус."
            )

# Handle admin commands
@bot.message_handler(commands=['admin'])
def admin_panel(message):
    user_id = message.from_user.id
    if user_id not in ADMIN_IDS:
        bot.send_message(message.chat.id, "У вас нет доступа к этой команде.")
        return

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(types.KeyboardButton("📊 Просмотр заказов"))
    markup.add(types.KeyboardButton("📦 Управление инвентарем"))
    markup.add(types.KeyboardButton("🎁 Управление промокодами"))
    markup.add(types.KeyboardButton("👥 Пользователи"))
    markup.add(types.KeyboardButton("📈 Статистика"))
    markup.add(types.KeyboardButton("📨 Рассылка"))
    markup.add(types.KeyboardButton("🔙 Вернуться в главное меню"))

    bot.send_message(
        message.chat.id,
        "🔐 Панель администратора",
        reply_markup=markup
    )
    user_states[user_id] = {"state": "admin_menu"}

# Show available Steam cards
def show_steam_cards(chat_id):
    markup = types.InlineKeyboardMarkup(row_width=1)

    for card in steam_cards:
        available_count = count_available_codes(card["id"])
        status_text = "✅ В наличии" if available_count > 0 else "❌ Нет в наличии"
        button_text = f"{card['image']} {card['name']} - {card['price']}₽ ({status_text})"
        
        # Only allow purchase if codes are available
        if available_count > 0:
            markup.add(types.InlineKeyboardButton(
                text=button_text,
                callback_data=f"card_{card['id']}"
            ))
        else:
            markup.add(types.InlineKeyboardButton(
                text=button_text,
                callback_data=f"unavailable_{card['id']}"
            ))

    bot.send_message(
        chat_id,
        "🎮 Выберите карту пополнения Steam:",
        reply_markup=markup
    )

# Show payment methods
def show_payment_methods(chat_id, card_id):
    markup = types.InlineKeyboardMarkup(row_width=2)

    for method in payment_methods:
        markup.add(types.InlineKeyboardButton(
            text=f"{method['icon']} {method['name']}",
            callback_data=f"pay_{card_id}_{method['id']}"
        ))

    markup.add(types.InlineKeyboardButton(
        text="🎁 Использовать промокод",
        callback_data=f"use_promo_{card_id}"
    ))

    markup.add(types.InlineKeyboardButton(
        text="❌ Отменить",
        callback_data="cancel_purchase"
    ))

    bot.send_message(
        chat_id,
        "💳 Выберите способ оплаты:",
        reply_markup=markup
    )

# Show user orders
def show_user_orders(chat_id, user_id):
    user_data = get_user_data(user_id)
    orders = load_orders()

    user_orders = []
    for order_id in user_data.get("orders", []):
        for order in orders:
            if order.get("order_id") == order_id:
                user_orders.append(order)

    if not user_orders:
        bot.send_message(chat_id, "У вас пока нет заказов.")
        return

    for order in user_orders:
        status_emoji = "✅" if order.get("status") == "completed" else "⏳"
        
        message_text = (
            f"{status_emoji} *Заказ #{order.get('order_id')}*\n"
            f"🎮 Товар: {order.get('product_name')}\n"
            f"💰 Цена: {order.get('price')}₽\n"
        )
        
        if order.get("discount", 0) > 0:
            message_text += f"🏷️ Скидка: {order.get('discount')}₽\n"
            if order.get("promo_code"):
                message_text += f"🎟️ Промокод: {order.get('promo_code')}\n"
        
        message_text += f"🕒 Дата: {order.get('date')}\n"
        
        if order.get("status") == "completed" and "code" in order:
            message_text += f"\n🔑 Код: `{order.get('code')}`\n"
        
        bot.send_message(
            chat_id,
            message_text,
            parse_mode="Markdown"
        )

# Check inventory availability
def check_inventory_availability(chat_id):
    inventory = load_inventory()

    message_text = "📦 *Наличие товаров:*\n\n"

    for card in steam_cards:
        card_id_str = str(card["id"])
        available_count = 0
        
        if card_id_str in inventory:
            available_count = sum(1 for code in inventory[card_id_str] if code["status"] == "available")
        
        status_emoji = "✅" if available_count > 0 else "❌"
        message_text += f"{status_emoji} {card['name']}: {available_count} шт.\n"

    bot.send_message(
        chat_id,
        message_text,
        parse_mode="Markdown"
    )

# Show promo codes
def show_promo_codes(chat_id):
    promo_codes = load_promo_codes()

    if not promo_codes:
        bot.send_message(chat_id, "В данный момент нет активных промокодов.")
        return

    message_text = "🎁 *Активные промокоды:*\n\n"

    for code, data in promo_codes.items():
        valid_until = datetime.strptime(data["valid_until"], "%Y-%m-%d")
        if valid_until >= datetime.now() and data["used"] < data["max_uses"]:
            message_text += f"🎟️ *{code}*\n"
            message_text += f"📝 {data['description']}\n"
            message_text += f"💰 Скидка: {data['discount_percent']}%\n"
            message_text += f"⏰ Действует до: {data['valid_until']}\n\n"

    bot.send_message(
        chat_id,
        message_text,
        parse_mode="Markdown"
    )

# Show referral program
def show_referral_program(chat_id, user_id):
    user_data = get_user_data(user_id)
    referrals = load_referrals()

    referral_code = user_data.get("referral_code", "")
    referral_link = f"https://t.me/your_bot_username?start={referral_code}"

    message_text = "👥 *Реферальная программа*\n\n"
    message_text += "Приглашайте друзей и получайте 5% от суммы их покупок на ваш бонусный счет!\n\n"
    message_text += f"🔗 Ваша реферальная ссылка:\n`{referral_link}`\n\n"
    message_text += f"📋 Ваш реферальный код: `{referral_code}`\n\n"

    # Show bonus balance
    bonus_balance = user_data.get("bonus_balance", 0)
    message_text += f"💰 Ваш бонусный баланс: {bonus_balance}₽\n\n"

    # Show referrals
    user_id_str = str(user_id)
    if user_id_str in referrals:
        referral_count = len(referrals[user_id_str]["referrals"])
        total_bonus = referrals[user_id_str]["total_bonus"]
        message_text += f"👥 Вы пригласили: {referral_count} пользователей\n"
        message_text += f"💰 Всего получено бонусов: {total_bonus}₽\n"
    else:
        message_text += "👥 Вы еще не пригласили ни одного пользователя\n"

    bot.send_message(
        chat_id,
        message_text,
        parse_mode="Markdown"
    )

# Handle callback queries (for inline buttons)
@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    user_id = call.from_user.id
    update_user_activity(user_id)

    # Initialize user state if not exists
    if user_id not in user_states:
        user_states[user_id] = {"state": "main_menu"}

    if call.data.startswith("card_"):
        card_id = int(call.data.split("_")[1])
        selected_card = next((card for card in steam_cards if card["id"] == card_id), None)
        
        if selected_card:
            user_states[user_id] = {
                "state": "selecting_payment",
                "selected_card": selected_card
            }
            
            bot.edit_message_text(
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                text=f"🛒 Вы выбрали: {selected_card['name']}\n"
                     f"💰 Цена: {selected_card['price']}₽\n\n"
                     f"Выберите способ оплаты:"
            )
            
            show_payment_methods(call.message.chat.id, card_id)

    elif call.data.startswith("unavailable_"):
        bot.answer_callback_query(
            call.id,
            "К сожалению, данный товар временно отсутствует в наличии.",
            show_alert=True
        )

    elif call.data.startswith("pay_"):
        parts = call.data.split("_")
        card_id = int(parts[1])
        payment_method_id = int(parts[2])
        
        selected_card = next((card for card in steam_cards if card["id"] == card_id), None)
        payment_method = next((method for method in payment_methods if method["id"] == payment_method_id), None)
        
        if selected_card and payment_method:
            user_states[user_id] = {
                "state": "waiting_for_steam_id",
                "selected_card": selected_card,
                "payment_method": payment_method,
                "promo_code": user_states[user_id].get("promo_code", None)
            }
            
            bot.send_message(
                call.message.chat.id,
                f"Вы выбрали оплату через {payment_method['name']}.\n\n"
                f"Для завершения заказа, пожалуйста, отправьте ваш Steam ID или ссылку на профиль."
            )

    elif call.data.startswith("use_promo_"):
        card_id = int(call.data.split("_")[2])
        selected_card = next((card for card in steam_cards if card["id"] == card_id), None)
        
        if selected_card:
            user_states[user_id] = {
                "state": "entering_promo",
                "selected_card": selected_card
            }
            
            bot.send_message(
                call.message.chat.id,
                "🎁 Введите промокод:"
            )

    elif call.data == "cancel_purchase":
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="❌ Заказ отменен."
        )
        user_states[user_id] = {"state": "main_menu"}

    elif call.data == "admin_add_codes" and user_id in ADMIN_IDS:
        markup = types.InlineKeyboardMarkup(row_width=1)
        
        for card in steam_cards:
            markup.add(types.InlineKeyboardButton(
                text=f"{card['name']}",
                callback_data=f"add_codes_{card['id']}"
            ))
        
        bot.send_message(
            call.message.chat.id,
            "Выберите товар для добавления кодов:",
            reply_markup=markup
        )

    elif call.data.startswith("add_codes_") and user_id in ADMIN_IDS:
        card_id = int(call.data.split("_")[2])
        selected_card = next((card for card in steam_cards if card["id"] == card_id), None)
        
        if selected_card:
            user_states[user_id] = {
                "state": "adding_codes",
                "card_id": card_ 
            user_states[user_id] = {
                "state": "adding_codes",
                "card_id": card_id,
                "card_name": selected_card["name"]
            }
            
            bot.send_message(
                call.message.chat.id,
                f"📝 Добавление кодов для {selected_card['name']}\n\n"
                f"Отправьте коды в одном из форматов:\n"
                f"1. По одному коду на строку\n"
                f"2. CSV файл\n\n"
                f"Для отмены введите /cancel"
            )

    elif call.data == "admin_refresh_inventory" and user_id in ADMIN_IDS:
        inventory = load_inventory()
        
        message_text = "📦 *Обновленный инвентарь:*\n\n"
        
        for card in steam_cards:
            card_id_str = str(card["id"])
            available_count = 0
            sold_count = 0
            
            if card_id_str in inventory:
                available_count = sum(1 for code in inventory[card_id_str] if code["status"] == "available")
                sold_count = sum(1 for code in inventory[card_id_str] if code["status"] == "sold")
            
            message_text += f"🎮 {card['name']}:\n"
            message_text += f"  ✅ Доступно: {available_count} шт.\n"
            message_text += f"  ❌ Продано: {sold_count} шт.\n\n"
        
        bot.send_message(
            call.message.chat.id,
            message_text,
            parse_mode="Markdown"
        )

    elif call.data == "admin_add_promo" and user_id in ADMIN_IDS:
        user_states[user_id] = {"state": "adding_promo"}
        
        bot.send_message(
            call.message.chat.id,
            "🎁 Добавление нового промокода\n\n"
            "Введите данные в формате:\n"
            "КОД|ПРОЦЕНТ_СКИДКИ|СРОК_ДЕЙСТВИЯ|МАКС_ИСПОЛЬЗОВАНИЙ|ОПИСАНИЕ\n\n"
            "Например:\n"
            "SUMMER25|25|2023-08-31|100|Летняя скидка 25%\n\n"
            "Для отмены введите /cancel"
        )

    elif call.data.startswith("admin_delete_promo_") and user_id in ADMIN_IDS:
        promo_code = call.data.split("_")[3]
        promo_codes = load_promo_codes()
        
        if promo_code in promo_codes:
            del promo_codes[promo_code]
            save_promo_codes(promo_codes)
            
            bot.send_message(
                call.message.chat.id,
                f"✅ Промокод {promo_code} успешно удален."
            )
        else:
            bot.send_message(
                call.message.chat.id,
                f"❌ Промокод {promo_code} не найден."
            )

# Handle text messages
@bot.message_handler(func=lambda message: True)
def handle_messages(message):
    user_id = message.from_user.id
    text = message.text
    update_user_activity(user_id)

    # Initialize user state if not exists
    if user_id not in user_states:
        user_states[user_id] = {"state": "main_menu"}

    # Handle cancel command
    if text == "/cancel":
        user_states[user_id] = {"state": "main_menu"}
        bot.send_message(
            message.chat.id,
            "❌ Операция отменена."
        )
        return

    # Handle main menu options
    if text == "🎮 Купить Steam карту":
        show_steam_cards(message.chat.id)

    elif text == "📋 Мои заказы":
        show_user_orders(message.chat.id, user_id)

    elif text == "🔍 Проверить наличие":
        check_inventory_availability(message.chat.id)

    elif text == "🎁 Промокоды":
        show_promo_codes(message.chat.id)

    elif text == "👥 Реферальная программа":
        show_referral_program(message.chat.id, user_id)

    elif text == "ℹ️ О магазине":
        bot.send_message(
            message.chat.id,
            "🏪 *VolkStore* - ваш надежный магазин карт пополнения Steam.\n\n"
            "✅ Мгновенная доставка\n"
            "✅ Выгодные цены\n"
            "✅ Поддержка 24/7\n\n"
            "Спасибо, что выбрали нас!",
            parse_mode="Markdown"
        )

    elif text == "📞 Поддержка":
        bot.send_message(
            message.chat.id,
            "По всем вопросам обращайтесь к администратору: @admin_username"
        )

    # Handle admin menu options
    elif text == "📊 Просмотр заказов" and user_id in ADMIN_IDS:
        orders = load_orders()
        
        if not orders:
            bot.send_message(message.chat.id, "Заказов пока нет.")
            return
        
        for i, order in enumerate(orders, 1):
            bot.send_message(
                message.chat.id,
                f"📝 *Заказ #{order.get('order_id', i)}*\n"
                f"👤 Пользователь: ID {order['user_id']}\n"
                f"🎮 Товар: {order['product_name']}\n"
                f"💰 Цена: {order['price']}₽\n"
                f"💳 Способ оплаты: {order.get('payment_method', 'Не указан')}\n"
                f"🎯 Steam ID: {order.get('steam_id', 'Не указан')}\n"
                f"📊 Статус: {order.get('status', 'Не указан')}\n"
                f"🕒 Дата: {order['date']}\n",
                parse_mode="Markdown"
            )

    elif text == "📦 Управление инвентарем" and user_id in ADMIN_IDS:
        inventory = load_inventory()
        
        message_text = "📦 *Инвентарь:*\n\n"
        
        for card in steam_cards:
            card_id_str = str(card["id"])
            available_count = 0
            sold_count = 0
            
            if card_id_str in inventory:
                available_count = sum(1 for code in inventory[card_id_str] if code["status"] == "available")
                sold_count = sum(1 for code in inventory[card_id_str] if code["status"] == "sold")
            
            message_text += f"🎮 {card['name']}:\n"
            message_text += f"  ✅ Доступно: {available_count} шт.\n"
            message_text += f"  ❌ Продано: {sold_count} шт.\n\n"
        
        bot.send_message(
            message.chat.id,
            message_text,
            parse_mode="Markdown"
        )
        
        # Add inventory management options
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("➕ Добавить коды", callback_data="admin_add_codes"),
            types.InlineKeyboardButton("🔄 Обновить инвентарь", callback_data="admin_refresh_inventory")
        )
        
        bot.send_message(
            message.chat.id,
            "Выберите действие:",
            reply_markup=markup
        )

    elif text == "🎁 Управление промокодами" and user_id in ADMIN_IDS:
        promo_codes = load_promo_codes()
        
        message_text = "🎁 *Промокоды:*\n\n"
        
        if not promo_codes:
            message_text += "Промокоды отсутствуют.\n"
        else:
            for code, data in promo_codes.items():
                message_text += f"🎟️ *{code}*\n"
                message_text += f"📝 {data['description']}\n"
                message_text += f"💰 Скидка: {data['discount_percent']}%\n"
                message_text += f"⏰ Действует до: {data['valid_until']}\n"
                message_text += f"📊 Использовано: {data['used']}/{data['max_uses']}\n\n"
        
        bot.send_message(
            message.chat.id,
            message_text,
            parse_mode="Markdown"
        )
        
        # Add promo code management options
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("➕ Добавить промокод", callback_data="admin_add_promo")
        )
        
        # Add delete buttons for each promo code
        for code in promo_codes:
            markup.add(
                types.InlineKeyboardButton(f"❌ Удалить {code}", callback_data=f"admin_delete_promo_{code}")
            )
        
        bot.send_message(
            message.chat.id,
            "Выберите действие:",
            reply_markup=markup
        )

    elif text == "👥 Пользователи" and user_id in ADMIN_IDS:
        users = load_users()
        
        if not users:
            bot.send_message(message.chat.id, "Пользователей пока нет.")
            return
        
        message_text = "👥 *Пользователи:*\n\n"
        
        for user_id_str, user_data in users.items():
            orders_count = len(user_data.get("orders", []))
            message_text += f"👤 ID: {user_id_str}\n"
            message_text += f"  📋 Заказов: {orders_count}\n"
            message_text += f"  🕒 Регистрация: {user_data.get('registration_date', 'Неизвестно')}\n"
            message_text += f"  🕒 Последняя активность: {user_data.get('last_activity', 'Неизвестно')}\n\n"
        
        bot.send_message(
            message.chat.id,
            message_text,
            parse_mode="Markdown"
        )

    elif text == "📈 Статистика" and user_id in ADMIN_IDS:
        stats = load_statistics()
        orders = load_orders()
        users = load_users()
        inventory = load_inventory()
        
        total_orders = len(orders)
        total_users = len(users)
        
        total_revenue = stats.get("total_revenue", 0)
        
        available_codes = sum(
            sum(1 for code in codes if code["status"] == "available")
            for codes in inventory.values()
        )
        
        sold_codes = sum(
            sum(1 for code in codes if code["status"] == "sold")
            for codes in inventory.values()
        )
        
        # Get daily stats for the last 7 days
        daily_stats = stats.get("daily_sales", {})
        today = datetime.now().date()
        last_7_days = [(today - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)]
        
        daily_text = ""
        for date_str in last_7_days:
            if date_str in daily_stats:
                daily_text += f"📅 {date_str}: {daily_stats[date_str].get('sales', 0)} продаж, {daily_stats[date_str].get('revenue', 0)}₽\n"
            else:
                daily_text += f"📅 {date_str}: 0 продаж, 0₽\n"
        
        message_text = "📈 *Статистика магазина:*\n\n"
        message_text += f"👥 Пользователей: {total_users}\n"
        message_text += f"📋 Заказов: {total_orders}\n"
        message_text += f"💰 Общая выручка: {total_revenue}₽\n\n"
        message_text += f"📦 Доступно кодов: {available_codes}\n"
        message_text += f"📦 Продано кодов: {sold_codes}\n\n"
        message_text += "*Статистика за последние 7 дней:*\n\n"
        message_text += daily_text
        
        bot.send_message(
            message.chat.id,
            message_text,
            parse_mode="Markdown"
        )

    elif text == "📨 Рассылка" and user_id in ADMIN_IDS:
        user_states[user_id] = {"state": "creating_broadcast"}
        
        bot.send_message(
            message.chat.id,
            "📨 *Создание рассылки*\n\n"
            "Введите текст сообщения для рассылки всем пользователям.\n"
            "Поддерживается Markdown форматирование.\n\n"
            "Для отмены введите /cancel",
            parse_mode="Markdown"
        )

    elif text == "🔙 Вернуться в главное меню":
        start(message)

    # Handle Steam ID input
    elif user_id in user_states and user_states[user_id]["state"] == "waiting_for_steam_id":
        selected_card = user_states[user_id]["selected_card"]
        payment_method = user_states[user_id]["payment_method"]
        promo_code = user_states[user_id].get("promo_code", None)
        steam_id = text.strip()
        
        # In a real bot, here you would process the payment
        # For this example, we'll simulate a successful payment
        
        # Process the order
        result = process_order(user_id, selected_card["id"], payment_method["id"], steam_id, promo_code)
        
        if result:
            order, discount_message = result
            
            # Prepare message text
            message_text = f"✅ *Заказ успешно оформлен!*\n\n"
            message_text += f"🎮 Товар: {selected_card['name']}\n"
            
            if discount_message:
                message_text += f"💰 Цена: ~~{selected_card['price']}₽~~ {order['price']}₽\n"
                message_text += f"🏷️ {discount_message}\n"
            else:
                message_text += f"💰 Цена: {order['price']}₽\n"
            
            message_text += f"💳 Способ оплаты: {payment_method['name']}\n"
            message_text += f"🎯 Steam ID: {steam_id}\n\n"
            message_text += f"🔑 *Ваш код:*\n`{order['code']}`\n\n"
            message_text += f"Спасибо за покупку! Приходите еще!"
            
            # Send the code to the user
            bot.send_message(
                message.chat.id,
                message_text,
                parse_mode="Markdown"
            )
            
            # Notify admin
            for admin_id in ADMIN_IDS:
                try:
                    bot.send_message(
                        admin_id,
                        f"🔔 *Новый заказ!*\n\n"
                        f"👤 Пользователь: ID {user_id}\n"
                        f"🎮 Товар: {selected_card['name']}\n"
                        f"💰 Цена: {order['price']}₽\n"
                        f"💳 Способ оплаты: {payment_method['name']}\n"
                        f"🎯 Steam ID: {steam_id}\n"
                        f"🔑 Код: {order['code']}\n",
                        parse_mode="Markdown"
                    )
                except Exception:
                    pass
        else:
            bot.send_message(
                message.chat.id,
                "❌ К сожалению, произошла ошибка при обработке заказа. Пожалуйста, попробуйте позже или обратитесь в поддержку."
            )
        
        # Reset user state
        user_states[user_id] = {"state": "main_menu"}

    # Handle promo code input
    elif user_id in user_states and user_states[user_id]["state"] == "entering_promo":
        selected_card = user_states[user_id]["selected_card"]
        promo_code = text.strip().upper()
        
        # Check if promo code is valid
        new_price, message = apply_promo_code(promo_code, selected_card["price"])
        
        if new_price:
            # Promo code is valid
            user_states[user_id] = {
                "state": "selecting_payment",
                "selected_card": selected_card,
                "promo_code": promo_code
            }
            
            bot.send_message(
                message.chat.id,
                f"✅ {message}\n"
                f"💰 Новая цена: {new_price}₽ (скидка {selected_card['price'] - new_price}₽)\n\n"
                f"Выберите способ оплаты:"
            )
            
            show_payment_methods(message.chat.id, selected_card["id"])
        else:
            # Promo code is invalid
            bot.send_message(
                message.chat.id,
                f"❌ {message}\n\n"
                f"Выберите способ оплаты:"
            )
            
            show_payment_methods(message.chat.id, selected_card["id"])

    # Handle admin adding codes
    elif user_id in user_states and user_states[user_id]["state"] == "adding_codes" and user_id in ADMIN_IDS:
        card_id = user_states[user_id]["card_id"]
        card_name = user_states[user_id]["card_name"]
        
        # Check if this is a file
        if message.document and message.document.mime_type == "text/csv":
            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            
            # Parse CSV file
            csv_data = downloaded_file.decode('utf-8')
            codes = []
            
            try:
                csv_reader = csv.reader(io.StringIO(csv_data))
                for row in csv_reader:
                    if row and row[0].strip():
                        codes.append(row[0].strip())
            except Exception as e:
                bot.send_message(
                    message.chat.id,
                    f"❌ Ошибка при чтении CSV файла: {str(e)}"
                )
                return
        else:
            # Parse text input
            codes = [code.strip() for code in text.split("\n") if code.strip()]
        
        if not codes:
            bot.send_message(
                message.chat.id,
                "❌ Не найдено кодов для добавления."
            )
            return
        
        # Add codes to inventory
        inventory = load_inventory()
        card_id_str = str(card_id)
        
        if card_id_str not in inventory:
            inventory[card_id_str] = []
        
        for code in codes:
            inventory[card_id_str].append({
                "code": code,
                "value": card_name,
                "status": "available",
                "added_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
        
        save_inventory(inventory)
        
        bot.send_message(
            message.chat.id,
            f"✅ Успешно добавлено {len(codes)} кодов для {card_name}."
        )
        
        # Reset user state
        user_states[user_id] = {"state": "admin_menu"}

    # Handle admin adding promo code
    elif user_id in user_states and user_states[user_id]["state"] == "adding_promo" and user_id in ADMIN_IDS:
        parts = text.split("|")
        
        if len(parts) != 5:
            bot.send_message(
                message.chat.id,
                "❌ Неверный формат. Используйте: КОД|ПРОЦЕНТ_СКИДКИ|СРОК_ДЕЙСТВИЯ|МАКС_ИСПОЛЬЗОВАНИЙ|ОПИСАНИЕ"
            )
            return
        
        try:
            code = parts[0].strip().upper()
            discount_percent = int(parts[1].strip())
            valid_until = parts[2].strip()
            max_uses = int(parts[3].strip())
            description = parts[4].strip()
            
            # Validate date format
            datetime.strptime(valid_until, "%Y-%m-%d")
            
            # Add promo code
            promo_codes = load_promo_codes()
            
            promo_codes[code] = {
                "discount_percent": discount_percent,
                "valid_until": valid_until,
                "max_uses": max_uses,
                "used": 0,
                "description": description
            }
            
            save_promo_codes(promo_codes)
            
            bot.send_message(
                message.chat.id,
                f"✅ Промокод {code} успешно добавлен."
            )
        except ValueError as e:
            bot.send_message(
                message.chat.id,
                f"❌ Ошибка при добавлении промокода: {str(e)}"
            )
        
        # Reset user state
        user_states[user_id] = {"state": "admin_menu"}

    # Handle admin creating broadcast
    elif user_id in user_states and user_states[user_id]["state"] == "creating_broadcast" and user_id in ADMIN_IDS:
        broadcast_text = text
        users = load_users()
        
        # Count users
        user_count = len(users)
        
        # Confirm broadcast
        markup = types.InlineKeyboardMarkup()
        markup.add(
            types.InlineKeyboardButton("✅ Отправить", callback_data="confirm_broadcast"),
            types.InlineKeyboardButton("❌ Отменить", callback_data="cancel_broadcast")
        )
        
        bot.send_message(
            message.chat.id,
            f"📨 *Предпросмотр рассылки*\n\n"
            f"{broadcast_text}\n\n"
            f"Сообщение будет отправлено {user_count} пользователям. Подтвердите отправку:",
            parse_mode="Markdown",
            reply_markup=markup
        )
        
        # Store broadcast text
        user_states[user_id] = {
            "state": "confirming_broadcast",
            "broadcast_text": broadcast_text
        }

# Handle document uploads (for CSV files)
@bot.message_handler(content_types=['document'])
def handle_document(message):
    user_id = message.from_user.id

    # Check if user is in the state of adding codes
    if user_id in user_states and user_states[user_id]["state"] == "adding_codes" and user_id in ADMIN_IDS:
        if message.document.mime_type == "text/csv":
            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            
            # Parse CSV file
            csv_data = downloaded_file.decode('utf-8')
            codes = []
            
            try:
                csv_reader = csv.reader(io.StringIO(csv_data))
                for row in csv_reader:
                    if row and row[0].strip():
                        codes.append(row[0].strip())
            except Exception as e:
                bot.send_message(
                    message.chat.id,
                    f"❌ Ошибка при чтении CSV файла: {str(e)}"
                )
                return
            
            if not codes:
                bot.send_message(
                    message.chat.id,
                    "❌ Не найдено кодов в CSV файле."
                )
                return
            
            # Add codes to inventory
            card_id = user_states[user_id]["card_id"]
            card_name = user_states[user_id]["card_name"]
            
            inventory = load_inventory()
            card_id_str = str(card_id)
            
            if card_id_str not in inventory:
                inventory[card_id_str] = []
            
            for code in codes:
                inventory[card_id_str].append({
                    "code": code,
                    "value": card_name,
                    "status": "available",
                    "added_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                })
            
            save_inventory(inventory)
            
            bot.send_message(
                message.chat.id,
                f"✅ Успешно добавлено {len(codes)} кодов для {card_name}."
            )
            
            # Reset user state
            user_states[user_id] = {"state": "admin_menu"}
        else:
            bot.send_message(
                message.chat.id,
                "❌ Пожалуйста, загрузите файл в формате CSV."
            )

# Initialize files before starting the bot
initialize_files()

# Example of running the bot (uncomment to run)
# print("Bot started...")
# bot.polling(none_stop=True)

# For demonstration purposes, let's show what the bot can do
print("Volkstore Telegram Bot initialized!")
print("\nFeatures:")
print("1. User can browse and purchase Steam gift cards")
print("2. User can view their order history")
print("3. User can check product availability")
print("4. User can use promo codes for discounts")
print("5. User can participate in referral program")
print("6. Admin can view all orders")
print("7. Admin can manage inventory (add codes via text or CSV)")
print("8. Admin can manage promo codes")
print("9. Admin can view user statistics")
print("10. Admin can view store statistics")
print("11. Admin can send broadcasts to all users")

print("\nAvailable Steam cards:")
for card in steam_cards:
    print(f"- {card['name']} - {card['price']}₽")

print("\nTo run this bot, you need to:")
print("1. Install the pyTelegramBotAPI library: pip install pyTelegramBotAPI")
print("2. Replace 'YOUR_TELEGRAM_BOT_TOKEN' with your actual bot token from @BotFather")
print("3. Update the ADMIN_IDS list with your Telegram user ID")
print("4. Uncomment the bot.polling() line at the end of the script")

bot.polling(none_stop=True)