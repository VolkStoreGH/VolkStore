import telebot
from telebot import types
import logging
import json
import os
from datetime import datetime, timedelta
import random
import string

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Импортируем основной бот и данные
from telegram_game_store_bot import bot, games, promocodes, user_orders, user_settings, user_carts, user_favorites, user_steam_topup_history

# Настройки админ-панели
ADMIN_PASSWORD = "admin123"  # Пароль для входа в админ-панель
ADMIN_IDS = [123456789, 987654321]  # Список ID администраторов (замените на реальные ID)

# Хранилище состояний админов
admin_states = {}

# Проверка, является ли пользователь администратором
def is_admin(user_id):
    return user_id in ADMIN_IDS

# Клавиатура админ-панели
def get_admin_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    # Управление играми
    games_btn = types.InlineKeyboardButton("🎮 Управление играми", callback_data="admin_games")
    
    # Управление пользователями
    users_btn = types.InlineKeyboardButton("👥 Управление пользователями", callback_data="admin_users")
    
    # Управление заказами
    orders_btn = types.InlineKeyboardButton("📋 Управление заказами", callback_data="admin_orders")
    
    # Управление промокодами
    promo_btn = types.InlineKeyboardButton("🎁 Управление промокодами", callback_data="admin_promo")
    
    # Статистика
    stats_btn = types.InlineKeyboardButton("📊 Статистика", callback_data="admin_stats")
    
    # Рассылка
    broadcast_btn = types.InlineKeyboardButton("📢 Рассылка", callback_data="admin_broadcast")
    
    # Выход из админ-панели
    exit_btn = types.InlineKeyboardButton("🚪 Выход", callback_data="admin_exit")
    
    markup.add(games_btn, users_btn, orders_btn, promo_btn, stats_btn, broadcast_btn, exit_btn)
    
    return markup

# Клавиатура управления играми
def get_games_management_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    add_game_btn = types.InlineKeyboardButton("➕ Добавить игру", callback_data="admin_add_game")
    edit_game_btn = types.InlineKeyboardButton("✏️ Редактировать игру", callback_data="admin_edit_game")
    delete_game_btn = types.InlineKeyboardButton("🗑️ Удалить игру", callback_data="admin_delete_game")
    list_games_btn = types.InlineKeyboardButton("📋 Список игр", callback_data="admin_list_games")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    
    markup.add(add_game_btn, edit_game_btn, delete_game_btn, list_games_btn, back_btn)
    
    return markup

# Клавиатура управления пользователями
def get_users_management_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    search_user_btn = types.InlineKeyboardButton("🔍 Найти пользователя", callback_data="admin_search_user")
    list_users_btn = types.InlineKeyboardButton("📋 Список пользователей", callback_data="admin_list_users")
    block_user_btn = types.InlineKeyboardButton("🚫 Заблокировать пользователя", callback_data="admin_block_user")
    unblock_user_btn = types.InlineKeyboardButton("✅ Разблокировать пользователя", callback_data="admin_unblock_user")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    
    markup.add(search_user_btn, list_users_btn, block_user_btn, unblock_user_btn, back_btn)
    
    return markup

# Клавиатура управления заказами
def get_orders_management_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    search_order_btn = types.InlineKeyboardButton("🔍 Найти заказ", callback_data="admin_search_order")
    list_orders_btn = types.InlineKeyboardButton("📋 Список заказов", callback_data="admin_list_orders")
    change_status_btn = types.InlineKeyboardButton("✏️ Изменить статус заказа", callback_data="admin_change_order_status")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    
    markup.add(search_order_btn, list_orders_btn, change_status_btn, back_btn)
    
    return markup

# Клавиатура управления промокодами
def get_promo_management_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    add_promo_btn = types.InlineKeyboardButton("➕ Добавить промокод", callback_data="admin_add_promo")
    edit_promo_btn = types.InlineKeyboardButton("✏️ Редактировать промокод", callback_data="admin_edit_promo")
    delete_promo_btn = types.InlineKeyboardButton("🗑️ Удалить промокод", callback_data="admin_delete_promo")
    list_promos_btn = types.InlineKeyboardButton("📋 Список промокодов", callback_data="admin_list_promos")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    
    markup.add(add_promo_btn, edit_promo_btn, delete_promo_btn, list_promos_btn, back_btn)
    
    return markup

# Клавиатура для выбора типа промокода
def get_promo_type_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    percent_btn = types.InlineKeyboardButton("% Процентная скидка", callback_data="admin_promo_type_percent")
    fixed_btn = types.InlineKeyboardButton("₽ Фиксированная скидка", callback_data="admin_promo_type_fixed")
    free_game_btn = types.InlineKeyboardButton("🎮 Бесплатная игра", callback_data="admin_promo_type_free_game")
    steam_btn = types.InlineKeyboardButton("🎮 Бонус Steam", callback_data="admin_promo_type_steam_topup")
    first_order_btn = types.InlineKeyboardButton("🛒 Скидка на первый заказ", callback_data="admin_promo_type_first_order")
    cancel_btn = types.InlineKeyboardButton("❌ Отмена", callback_data="admin_back_to_promo")
    
    markup.add(percent_btn, fixed_btn, free_game_btn, steam_btn, first_order_btn, cancel_btn)
    
    return markup

# Клавиатура для статистики
def get_stats_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    sales_btn = types.InlineKeyboardButton("💰 Статистика продаж", callback_data="admin_stats_sales")
    users_btn = types.InlineKeyboardButton("👥 Статистика пользователей", callback_data="admin_stats_users")
    games_btn = types.InlineKeyboardButton("🎮 Статистика игр", callback_data="admin_stats_games")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    
    markup.add(sales_btn, users_btn, games_btn, back_btn)
    
    return markup

# Клавиатура для рассылки
def get_broadcast_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    all_users_btn = types.InlineKeyboardButton("👥 Всем пользователям", callback_data="admin_broadcast_all")
    active_users_btn = types.InlineKeyboardButton("👤 Активным пользователям", callback_data="admin_broadcast_active")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    
    markup.add(all_users_btn, active_users_btn, back_btn)
    
    return markup

# Обработчик команды /admin
@bot.message_handler(commands=['admin'])
def admin_command_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, является ли пользователь администратором
    if is_admin(user_id):
        # Запрашиваем пароль
        bot.send_message(
            message.chat.id,
            "🔐 Введите пароль для доступа к админ-панели:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, check_admin_password)
    else:
        bot.send_message(
            message.chat.id,
            "⛔ У вас нет доступа к админ-панели.",
            parse_mode="Markdown"
        )

# Проверка пароля администратора
def check_admin_password(message):
    user_id = message.from_user.id
    password = message.text.strip()
    
    # Удаляем сообщение с паролем для безопасности
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception as e:
        logger.error(f"Ошибка при удалении сообщения: {e}")
    
    if password == ADMIN_PASSWORD:
        # Показываем админ-панель
        show_admin_panel(message.chat.id, user_id)
    else:
        bot.send_message(
            message.chat.id,
            "❌ Неверный пароль. Доступ запрещен.",
            parse_mode="Markdown"
        )

# Показать админ-панель
def show_admin_panel(chat_id, user_id):
    admin_text = (
        "👨‍💼 *Админ-панель VolkStore*\n\n"
        "Добро пожаловать в панель администратора!\n"
        "Выберите действие из меню ниже:"
    )
    
    bot.send_message(
        chat_id,
        admin_text,
        parse_mode="Markdown",
        reply_markup=get_admin_keyboard()
    )

# Обработчик добавления новой игры
def process_add_game_name(message):
    user_id = message.from_user.id
    
    # Сохраняем название игры
    admin_states[user_id]["game_name"] = message.text.strip()
    
    # Запрашиваем описание
    bot.send_message(
        message.chat.id,
        "📝 Введите описание игры:",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_add_game_description)

# Обработчик добавления описания игры
def process_add_game_description(message):
    user_id = message.from_user.id
    
    # Сохраняем описание игры
    admin_states[user_id]["game_description"] = message.text.strip()
    
    # Запрашиваем цену
    bot.send_message(
        message.chat.id,
        "💰 Введите цену игры (только цифры):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_add_game_price)

# Обработчик добавления цены игры
def process_add_game_price(message):
    user_id = message.from_user.id
    
    try:
        price = int(message.text.strip())
        
        # Сохраняем цену игры
        admin_states[user_id]["game_price"] = price
        
        # Запрашиваем жанр
        bot.send_message(
            message.chat.id,
            "🎭 Введите жанр игры:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_add_game_genre)
    except ValueError:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите корректную цену (только цифры):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_add_game_price)

# Обработчик добавления жанра игры
def process_add_game_genre(message):
    user_id = message.from_user.id
    
    # Сохраняем жанр игры
    admin_states[user_id]["game_genre"] = message.text.strip()
    
    # Запрашиваем платформы
    bot.send_message(
        message.chat.id,
        "💻 Введите платформы игры через запятую (например: PC, PlayStation, Xbox):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_add_game_platforms)

# Обработчик добавления платформ игры
def process_add_game_platforms(message):
    user_id = message.from_user.id
    
    # Сохраняем платформы игры
    platforms = [platform.strip() for platform in message.text.split(",")]
    admin_states[user_id]["game_platforms"] = platforms
    
    # Запрашиваем ссылку на изображение
    bot.send_message(
        message.chat.id,
        "🖼️ Введите ссылку на изображение игры:",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_add_game_image)

# Обработчик добавления изображения игры
def process_add_game_image(message):
    user_id = message.from_user.id
    
    # Сохраняем ссылку на изображение
    admin_states[user_id]["game_image"] = message.text.strip()
    
    # Создаем новую игру
    new_game = {
        "id": max(game["id"] for game in games) + 1,
        "title": admin_states[user_id]["game_name"],
        "description": admin_states[user_id]["game_description"],
        "price": admin_states[user_id]["game_price"],
        "old_price": None,
        "discount": None,
        "image": admin_states[user_id]["game_image"],
        "genre": admin_states[user_id]["game_genre"],
        "platform": admin_states[user_id]["game_platforms"],
        "rating": 0.0,
        "reviews": []
    }
    
    # Добавляем игру в список
    games.append(new_game)
    
    # Отправляем сообщение об успешном добавлении
    bot.send_message(
        message.chat.id,
        f"✅ Игра *{new_game['title']}* успешно добавлена!\n\n"
        f"🆔 ID: {new_game['id']}\n"
        f"💰 Цена: {new_game['price']} ₽\n"
        f"🎭 Жанр: {new_game['genre']}\n"
        f"💻 Платформы: {', '.join(new_game['platform'])}",
        parse_mode="Markdown"
    )
    
    # Очищаем состояние
    del admin_states[user_id]
    
    # Возвращаемся в меню управления играми
    bot.send_message(
        message.chat.id,
        "Выберите действие:",
        reply_markup=get_games_management_keyboard()
    )

# Обработчик поиска игры для редактирования
def process_edit_game_id(message):
    user_id = message.from_user.id
    
    try:
        game_id = int(message.text.strip())
        
        # Ищем игру по ID
        game = next((g for g in games if g["id"] == game_id), None)
        
        if game:
            # Сохраняем ID игры
            admin_states[user_id]["edit_game_id"] = game_id
            
            # Показываем информацию о игре
            game_info = (
                f"🎮 *{game['title']}*\n\n"
                f"📝 Описание: {game['description']}\n"
                f"💰 Цена: {game['price']} ₽\n"
                f"🎭 Жанр: {game['genre']}\n"
                f"💻 Платформы: {', '.join(game['platform'])}\n"
                f"⭐ Рейтинг: {game['rating']}/5\n"
                f"📝 Отзывы: {len(game['reviews'])}"
            )
            
            # Клавиатура для выбора поля для редактирования
            markup = types.InlineKeyboardMarkup(row_width=1)
            name_btn = types.InlineKeyboardButton("✏️ Изменить название", callback_data="admin_edit_game_name")
            desc_btn = types.InlineKeyboardButton("📝 Изменить описание", callback_data="admin_edit_game_description")
            price_btn = types.InlineKeyboardButton("💰 Изменить цену", callback_data="admin_edit_game_price")
            genre_btn = types.InlineKeyboardButton("🎭 Изменить жанр", callback_data="admin_edit_game_genre")
            platforms_btn = types.InlineKeyboardButton("💻 Изменить платформы", callback_data="admin_edit_game_platforms")
            image_btn = types.InlineKeyboardButton("🖼️ Изменить изображение", callback_data="admin_edit_game_image")
            discount_btn = types.InlineKeyboardButton("🔥 Установить скидку", callback_data="admin_edit_game_discount")
            cancel_btn = types.InlineKeyboardButton("❌ Отмена", callback_data="admin_back_to_games")
            
            markup.add(name_btn, desc_btn, price_btn, genre_btn, platforms_btn, image_btn, discount_btn, cancel_btn)
            
            bot.send_message(
                message.chat.id,
                f"{game_info}\n\nВыберите, что хотите изменить:",
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            bot.send_message(
                message.chat.id,
                "❌ Игра с таким ID не найдена. Пожалуйста, введите корректный ID:",
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(message, process_edit_game_id)
    except ValueError:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите корректный ID (только цифры):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_edit_game_id)

# Обработчик поиска игры для удаления
def process_delete_game_id(message):
    user_id = message.from_user.id
    
    try:
        game_id = int(message.text.strip())
        
        # Ищем игру по ID
        game = next((g for g in games if g["id"] == game_id), None)
        
        if game:
            # Запрашиваем подтверждение удаления
            markup = types.InlineKeyboardMarkup(row_width=2)
            yes_btn = types.InlineKeyboardButton("✅ Да, удалить", callback_data=f"admin_confirm_delete_game_{game_id}")
            no_btn = types.InlineKeyboardButton("❌ Нет, отмена", callback_data="admin_back_to_games")
            markup.add(yes_btn, no_btn)
            
            bot.send_message(
                message.chat.id,
                f"⚠️ Вы уверены, что хотите удалить игру *{game['title']}* (ID: {game_id})?",
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            bot.send_message(
                message.chat.id,
                "❌ Игра с таким ID не найдена. Пожалуйста, введите корректный ID:",
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(message, process_delete_game_id)
    except ValueError:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите корректный ID (только цифры):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_delete_game_id)

# Обработчик поиска пользователя
def process_search_user_id(message):
    user_id = message.from_user.id
    search_id = message.text.strip()
    
    try:
        search_id = int(search_id)
        
        # Ищем пользователя
        if search_id in user_settings:
            settings = user_settings[search_id]
            
            # Формируем информацию о пользователе
            user_info = (
                f"👤 *Информация о пользователе*\n\n"
                f"🆔 ID: {search_id}\n"
                f"👤 Имя: {settings.get('name', 'Не указано')}\n"
                f"✉️ Email: {settings.get('email', 'Не указан')}\n"
                f"💰 Валюта: {settings.get('currency', 'RUB')}\n"
                f"🔔 Уведомления: {'Включены' if settings.get('notifications', True) else 'Отключены'}\n"
                f"🌐 Язык: {settings.get('language', 'ru')}\n\n"
            )
            
            # Добавляем информацию о корзине
            if search_id in user_carts and user_carts[search_id]:
                cart_games = [next((g for g in games if g["id"] == game_id), None) for game_id in user_carts[search_id]]
                cart_games = [g for g in cart_games if g]  # Фильтруем None
                
                user_info += f"🛒 *Корзина:* {len(cart_games)} игр\n"
                for game in cart_games:
                    user_info += f"- {game['title']} ({game['price']} ₽)\n"
                user_info += "\n"
            else:
                user_info += "🛒 *Корзина:* пусто\n\n"
            
            # Добавляем информацию об избранном
            if search_id in user_favorites and user_favorites[search_id]:
                favorite_games = [next((g for g in games if g["id"] == game_id), None) for game_id in user_favorites[search_id]]
                favorite_games = [g for g in favorite_games if g]  # Фильтруем None
                
                user_info += f"⭐ *Избранное:* {len(favorite_games)} игр\n"
                for game in favorite_games[:5]:  # Показываем только первые 5 игр
                    user_info += f"- {game['title']}\n"
                
                if len(favorite_games) > 5:
                    user_info += f"- и еще {len(favorite_games) - 5} игр...\n"
                user_info += "\n"
            else:
                user_info += "⭐ *Избранное:* пусто\n\n"
            
            # Добавляем информацию о заказах
            if search_id in user_orders and user_orders[search_id]:
                user_info += f"📋 *Заказы:* {len(user_orders[search_id])} заказов\n"
                for order in user_orders[search_id][:3]:  # Показываем только последние 3 заказа
                    user_info += f"- #{order['id']} от {order['date']} ({order['total']} ₽)\n"
                
                if len(user_orders[search_id]) > 3:
                    user_info += f"- и еще {len(user_orders[search_id]) - 3} заказов...\n"
            else:
                user_info += "📋 *Заказы:* нет заказов\n"
            
            # Клавиатура действий с пользователем
            markup = types.InlineKeyboardMarkup(row_width=1)
            orders_btn = types.InlineKeyboardButton("📋 Все заказы пользователя", callback_data=f"admin_user_orders_{search_id}")
            block_btn = types.InlineKeyboardButton("🚫 Заблокировать пользователя", callback_data=f"admin_block_user_{search_id}")
            back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_users")
            markup.add(orders_btn, block_btn, back_btn)
            
            bot.send_message(
                message.chat.id,
                user_info,
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            bot.send_message(
                message.chat.id,
                "❌ Пользователь с таким ID не найден.",
                parse_mode="Markdown",
                reply_markup=get_users_management_keyboard()
            )
    except ValueError:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите корректный ID пользователя (только цифры).",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_search_user_id)

# Обработчик поиска заказа
def process_search_order_id(message):
    user_id = message.from_user.id
    order_id = message.text.strip()
    
    # Ищем заказ по ID
    found_order = None
    found_user_id = None
    
    for uid, orders in user_orders.items():
        for order in orders:
            if order['id'] == order_id:
                found_order = order
                found_user_id = uid
                break
        if found_order:
            break
    
    if found_order:
        # Формируем информацию о заказе
        order_info = (
            f"📋 *Информация о заказе #{found_order['id']}*\n\n"
            f"👤 ID пользователя: {found_user_id}\n"
            f"📅 Дата: {found_order['date']}\n"
            f"💰 Сумма: {found_order['total']} ₽\n"
            f"✅ Статус: {found_order['status']}\n\n"
            f"🎮 *Игры в заказе:*\n"
        )
        
        for game_id in found_order['games']:
            game = next((g for g in games if g["id"] == game_id), None)
            if game:
                order_info += f"- {game['title']} ({game['price']} ₽)\n"
        
        # Клавиатура действий с заказом
        markup = types.InlineKeyboardMarkup(row_width=1)
        change_status_btn = types.InlineKeyboardButton("✏️ Изменить статус", callback_data=f"admin_change_status_{order_id}")
        user_info_btn = types.InlineKeyboardButton("👤 Информация о пользователе", callback_data=f"admin_user_info_{found_user_id}")
        back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_orders")
        markup.add(change_status_btn, user_info_btn, back_btn)
        
        bot.send_message(
            message.chat.id,
            order_info,
            parse_mode="Markdown",
            reply_markup=markup
        )
    else:
        bot.send_message(
            message.chat.id,
            "❌ Заказ с таким ID не найден.",
            parse_mode="Markdown",
            reply_markup=get_orders_management_keyboard()
        )

# Обработчик добавления промокода
def process_add_promo_code(message):
    user_id = message.from_user.id
    promo_code = message.text.strip().upper()
    
    # Проверяем, существует ли уже такой промокод
    if promo_code in promocodes:
        bot.send_message(
            message.chat.id,
            "❌ Промокод с таким кодом уже существует. Пожалуйста, введите другой код:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_add_promo_code)
        return
    
    # Сохраняем код промокода
    admin_states[user_id]["promo_code"] = promo_code
    
    # Запрашиваем тип
