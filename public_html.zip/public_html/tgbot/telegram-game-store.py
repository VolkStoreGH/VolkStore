import telebot
from telebot import types
import random
import string
import logging
import os
import json
import time
import uuid
from datetime import datetime, timedelta

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Инициализация бота с вашим токеном (получите его у BotFather)
# Замените на ваш реальный токен при использовании
TOKEN = "7774576888:AAFlj3TxwV_BP_c5EN2FaJgcfQlH5IoIdXo"
bot = telebot.TeleBot(TOKEN)

# Данные администраторов
ADMIN_PASSWORD = "admin123456"  # Пароль для доступа к админ-панели
ADMIN_IDS = [123456789, 987654321]  # Список ID администраторов

# Папка с изображениями
IMAGES_FOLDER = "images/"

# Данные игр из вашего сайта
games = [
    {
        "id": 1,
        "title": "Cyberpunk 2077",
        "description": "Action RPG, Открытый мир. Футуристическая игра в жанре экшен-РПГ, действие которой происходит в дистопическом будущем.",
        "price": 5499,
        "old_price": 7999,
        "discount": "31%",
        "image": "cyberpunk.jpg",
        "genre": "Action RPG",
        "platform": ["Steam"],
        "rating": 4.5,
        "reviews": [
            {"user_id": 123456, "username": "CyberFan", "rating": 5, "text": "Отличная игра! Графика на высоте!", "date": "2023-05-15"},
            {"user_id": 789012, "username": "GameMaster", "rating": 4, "text": "Хорошая игра, но есть баги.", "date": "2023-06-20"}
        ]
    },
    {
        "id": 2,
        "title": "Elden Ring",
        "description": "Action RPG, Открытый мир. Экшен-РПГ, разработанная FromSoftware и изданная Bandai Namco Entertainment.",
        "price": 3599,
        "old_price": None,
        "discount": None,
        "image": "eldenring.jpg",
        "genre": "Action RPG",
        "platform": ["PC", "PlayStation", "Xbox"],
        "rating": 5.0,
        "reviews": [
            {"user_id": 345678, "username": "SoulsFan", "rating": 5, "text": "Шедевр! Лучшая игра от FromSoftware!", "date": "2023-04-10"}
        ]
    },
    {
        "id": 3,
        "title": "Teardown",
        "description": "Симулятор, Разрушения. Игра с полностью разрушаемым окружением и физикой воксельного мира.",
        "price": 1399,
        "old_price": None,
        "discount": None,
        "image": "teardown.jpg",
        "genre": "Симулятор",
        "platform": ["PC"],
        "rating": 4.5,
        "reviews": []
    },
    {
        "id": 4,
        "title": "Hogwarts Legacy",
        "description": "RPG, Приключения. Ролевая игра в открытом мире, действие которой происходит в волшебном мире Гарри Поттера.",
        "price": 5299,
        "old_price": None,
        "discount": None,
        "image": "hogwarts.jpg",
        "genre": "RPG",
        "platform": ["PC", "PlayStation", "Xbox", "Switch"],
        "rating": 5.0,
        "reviews": []
    },
    {
        "id": 5,
        "title": "Grand Theft Auto V",
        "description": "Action, Открытый мир. Популярная игра с открытым миром от Rockstar Games.",
        "price": 1999,
        "old_price": 2599,
        "discount": "25%",
        "image": "gta5.jpg",
        "genre": "Action",
        "platform": ["PC", "PlayStation", "Xbox"],
        "rating": 5.0,
        "reviews": []
    },
    {
        "id": 6,
        "title": "RUST",
        "description": "Выживание, Мультиплеер. Многопользовательская игра на выживание в суровом открытом мире.",
        "price": 1499,
        "old_price": None,
        "discount": None,
        "image": "rust.jpg",
        "genre": "Выживание",
        "platform": ["PC"],
        "rating": 4.5,
        "reviews": []
    },
    {
        "id": 7,
        "title": "God of War",
        "description": "Action, Приключения. Эпическое приключение Кратоса и его сына Атрея в мире скандинавской мифологии.",
        "price": 4499,
        "old_price": None,
        "discount": None,
        "image": "godofwar.jpg",
        "genre": "Action",
        "platform": ["PC", "PlayStation"],
        "rating": 5.0,
        "reviews": []
    },
    {
        "id": 8,
        "title": "Red Dead Redemption 2",
        "description": "Action, Открытый мир. Эпическая история о жизни в беспощадном сердце Америки на заре современной эпохи.",
        "price": 2499,
        "old_price": None,
        "discount": None,
        "image": "rdr2.jpg",
        "genre": "Action",
        "platform": ["PC", "PlayStation", "Xbox"],
        "rating": 5.0,
        "reviews": []
    },
    {
        "id": 9,
        "title": "S.T.A.L.K.E.R 2",
        "description": "Шутер, Выживание. Продолжение культовой серии игр, действие которых происходит в Чернобыльской зоне отчуждения.",
        "price": 5299,
        "old_price": None,
        "discount": None,
        "image": "stalker2.jpg",
        "genre": "Шутер",
        "platform": ["PC", "Xbox"],
        "rating": 5.0,
        "reviews": []
    },
    {
        "id": 10,
        "title": "DARK SOULS™ III",
        "description": "Action RPG, Сложная. Заключительная часть знаменитой серии, известной своей высокой сложностью.",
        "price": 2499,
        "old_price": None,
        "discount": None,
        "image": "darksouls3.jpg",
        "genre": "Action RPG",
        "platform": ["PC", "PlayStation", "Xbox"],
        "rating": 4.5,
        "reviews": []
    },
    {
        "id": 11,
        "title": "Far Cry 6",
        "description": "Шутер, Открытый мир. Шутер от первого лица с открытым миром, действие которого происходит на тропическом острове Яра.",
        "price": 1999,
        "old_price": None,
        "discount": None,
        "image": "farcry6.jpg",
        "genre": "Шутер",
        "platform": ["PC", "PlayStation", "Xbox"],
        "rating": 4.5,
        "reviews": []
    },
    {
        "id": 12,
        "title": "Baldur's Gate 3",
        "description": "RPG, Стратегия. Ролевая игра, основанная на правилах и мире Dungeons & Dragons.",
        "price": 4999,
        "old_price": None,
        "discount": None,
        "image": "baldursgate3.jpg",
        "genre": "RPG",
        "platform": ["PC", "PlayStation"],
        "rating": 5.0,
        "reviews": []
    },
    {
        "id": 13,
        "title": "EA Sports FC 24",
        "description": "Спорт, Симулятор. Футбольный симулятор, ранее известный как FIFA.",
        "price": 0,
        "old_price": 0,
        "discount": "0%",
        "image": "fc24.jpg",
        "genre": "Спорт",
        "platform": ["PC", "PlayStation", "Xbox", "Switch"],
        "rating": 4.0,
        "available": False,
        "reviews": []
    },
    {
        "id": 14,
        "title": "The Headliners",
        "description": "Хоррор, Экшен. Атмосферная игра в жанре хоррор с элементами экшена.",
        "price": 320,
        "old_price": None,
        "discount": None,
        "image": "headliners.jpg",
        "genre": "Хоррор",
        "platform": ["PC"],
        "rating": 4.5,
        "reviews": []
    },
    {
        "id": 15,
        "title": "Detroit: Become Human",
        "description": "Симулятор, RPG. Интерактивная драма о будущем, где андроиды становятся разумными.",
        "price": 390,
        "old_price": 1300,
        "discount": "70%",
        "image": "detroit.jpg",
        "genre": "Симулятор",
        "platform": ["PC", "PlayStation"],
        "rating": 5.0,
        "reviews": []
    },
    {
        "id": 16,
        "title": "DayZ",
        "description": "Приключение, Метроидвания. Многопользовательская игра на выживание в постапокалиптическом мире.",
        "price": 2790,
        "old_price": None,
        "discount": None,
        "image": "dayz.jpg",
        "genre": "Приключение",
        "platform": ["PC", "PlayStation", "Xbox"],
        "rating": 5.0,
        "reviews": []
    }
]

# Создаем словарь жанров для быстрого доступа
all_genres = set()
for game in games:
    all_genres.add(game["genre"])
genres_list = sorted(list(all_genres))

# Создаем словарь платформ для быстрого доступа
all_platforms = set()
for game in games:
    for platform in game["platform"]:
        all_platforms.add(platform)
platforms_list = sorted(list(all_platforms))

# Хранилище корзин пользователей
user_carts = {}

# Хранилище настроек пользователей
user_settings = {}

# Хранилище избранных игр пользователей
user_favorites = {}

# Хранилище истории заказов пользователей
user_orders = {}

# Хранилище текущей страницы каталога для пользователей
user_catalog_pages = {}

# Хранилище состояния оплаты пользователей
user_payment_state = {}

# Хранилище временных скидок пользователей (для эмодзи 🐺)
user_wolf_discounts = {}

# Хранилище состояний поиска по цене
user_price_search_state = {}

# Хранилище состояний поиска по имени
user_name_search_state = {}

# Хранилище результатов поиска
user_search_results = {}

# Хранилище истории пополнений Steam
user_steam_topup_history = {}

# Хранилище состояний пополнения Steam
user_steam_topup_state = {}

# Хранилище состояний отзывов
user_review_state = {}

# Хранилище уведомлений о новых играх
user_notifications = {}

# Хранилище состояний админ-панели
admin_state = {}

# Хранилище платежей
user_payments = {}

# Хранилище логинов Steam пользователей
user_steam_logins = {}

# Хранилище заблокированных пользователей
blocked_users = []

# Хранилище промокодов
promocodes = {
    "4hg6sk": {
        "type": "percent",
        "value": 10,
        "description": "Скидка 10% на всю корзину",
        "expires": datetime.now() + timedelta(days=30),
        "min_order": 1000,
        "used_by": []
    },
    "10FHLKS": {
        "type": "percent",
        "value": 20,
        "description": "Скидка 20% на всю корзину",
        "expires": datetime.now() + timedelta(days=15),
        "min_order": 3000,
        "used_by": []
    },
    "DU5GB": {
        "type": "fixed",
        "value": 500,
        "description": "Скидка 500 рублей на заказ",
        "expires": datetime.now() + timedelta(days=7),
        "min_order": 2000,
        "used_by": []
    },
    "MFEVX": {
        "type": "free_game",
        "game_id": 3,  # ID игры, которую можно получить бесплатно
        "description": "Бесплатная игра Teardown при заказе от 5000 рублей",
        "expires": datetime.now() + timedelta(days=10),
        "min_order": 5000,
        "used_by": []
    },
    "STEAM10": {
        "type": "steam_topup",
        "value": 10,
        "description": "Дополнительные 10% при пополнении Steam",
        "expires": datetime.now() + timedelta(days=5),
        "min_amount": 1000,
        "used_by": []
    },
    "WELCOME": {
        "type": "first_order",
        "value": 15,
        "description": "Скидка 15% на первый заказ",
        "expires": datetime.now() + timedelta(days=365),
        "min_order": 0,
        "used_by": []
    }
}

# Хранилище примененных промокодов пользователей
user_applied_promocodes = {}

# Количество игр на одной странице каталога
GAMES_PER_PAGE = 4

# Доступные валюты и их курсы к рублю
currencies = {
    "RUB": {"symbol": "₽", "rate": 1.0, "name": "Российский рубль"},
    "USD": {"symbol": "$", "rate": 0.011, "name": "Доллар США"},
    "EUR": {"symbol": "€", "rate": 0.01, "name": "Евро"}
}

# Доступные языки
languages = {
    "ru": "Русский",
    "en": "English"
}

# Методы оплаты
payment_methods = {
    "card": {
        "name": "Банковская карта",
        "description": "Оплата банковской картой Visa, MasterCard, МИР",
        "commission": 0
    },
    "qiwi": {
        "name": "QIWI",
        "description": "Оплата через QIWI кошелек",
        "commission": 2
    },
    "yoomoney": {
        "name": "ЮMoney",
        "description": "Оплата через ЮMoney (бывшие Яндекс.Деньги)",
        "commission": 2
    },
    "webmoney": {
        "name": "WebMoney",
        "description": "Оплата через WebMoney",
        "commission": 3
    },
    "crypto": {
        "name": "Криптовалюта",
        "description": "Оплата в Bitcoin, Ethereum, USDT",
        "commission": 1
    },
    "sberbank": {
        "name": "СберБанк",
        "description": "Оплата через СберБанк Онлайн",
        "commission": 0
    }
}

# Настройки по умолчанию
default_settings = {
    "currency": "RUB",
    "notifications": True,
    "language": "ru",
    "preferred_genres": [],
    "preferred_platforms": [],
    "name": "",
    "email": ""
}

# Статистика магазина
store_stats = {
    "total_sales": 0,
    "total_orders": 0,
    "total_users": 0,
    "popular_games": {},
    "sales_by_date": {}
}

# Проверка существования папки с изображениями
if not os.path.exists(IMAGES_FOLDER):
    os.makedirs(IMAGES_FOLDER)
    logger.info(f"Создана папка для изображений: {IMAGES_FOLDER}")

# Функция для получения пути к изображению
def get_image_path(image_name):
    return os.path.join(IMAGES_FOLDER, image_name)

# Функция для проверки существования изображения
def image_exists(image_name):
    image_path = get_image_path(image_name)
    return os.path.exists(image_path)

# Функция для отправки изображения из локальной папки
def send_image_from_folder(chat_id, image_name, caption=None, reply_markup=None, parse_mode=None):
    image_path = get_image_path(image_name)
    
    if os.path.exists(image_path):
        try:
            with open(image_path, 'rb') as photo:
                bot.send_photo(
                    chat_id,
                    photo,
                    caption=caption,
                    reply_markup=reply_markup,
                    parse_mode=parse_mode
                )
            return True
        except Exception as e:
            logger.error(f"Ошибка при отправке изображения {image_name}: {e}")
            return False
    else:
        logger.warning(f"Изображение {image_name} не найдено в папке {IMAGES_FOLDER}")
        return False

# Получить настройки пользователя или создать новые
def get_user_settings(user_id):
    if user_id not in user_settings:
        user_settings[user_id] = default_settings.copy()
    return user_settings[user_id]

# Конвертировать цену в выбранную валюту
def convert_price(price, user_id):
    settings = get_user_settings(user_id)
    currency = settings["currency"]
    converted_price = price * currencies[currency]["rate"]
    return f"{converted_price:.2f} {currencies[currency]['symbol']}"

# Конвертировать цену из выбранной валюты в рубли
def convert_to_rub(price, user_id):
    settings = get_user_settings(user_id)
    currency = settings["currency"]
    return price / currencies[currency]["rate"]

# Функция для экранирования специальных символов Markdown
def escape_markdown(text):
    if not text:
        return ""
    # Экранируем специальные символы Markdown
    special_chars = ['_', '*', '`', '[', ']']
    for char in special_chars:
        text = text.replace(char, f'\\{char}')
    return text

# Проверка, является ли пользователь администратором
def is_admin(user_id):
    return user_id in ADMIN_IDS

# Проверка, заблокирован ли пользователь
def is_blocked(user_id):
    return user_id in blocked_users

# Генерация уникального ID для заказа
def generate_order_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

# Генерация уникального ID для платежа
def generate_payment_id():
    return str(uuid.uuid4())

# Обновление статистики магазина
def update_store_stats(order):
    store_stats["total_sales"] += order["total"]
    store_stats["total_orders"] += 1
    
    # Обновляем статистику по популярным играм
    for game_id in order["games"]:
        if game_id not in store_stats["popular_games"]:
            store_stats["popular_games"][game_id] = 0
        store_stats["popular_games"][game_id] += 1
    
    # Обновляем статистику по датам
    date = order["date"].split()[0]  # Берем только дату без времени
    if date not in store_stats["sales_by_date"]:
        store_stats["sales_by_date"][date] = 0
    store_stats["sales_by_date"][date] += order["total"]

# Проверка валидности логина Steam
def is_valid_steam_login(login):
    # Простая проверка: логин должен быть не менее 3 символов и содержать только буквы, цифры и некоторые спецсимволы
    if len(login) < 3:
        return False
    
    valid_chars = set(string.ascii_letters + string.digits + "_-.")
    return all(char in valid_chars for char in login)

# Клавиатура главного меню
def get_main_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    catalog_btn = types.KeyboardButton("🎮 Каталог игр")
    cart_btn = types.KeyboardButton("🛒 Моя корзина")
    search_btn = types.KeyboardButton("🔍 Поиск игр")
    favorites_btn = types.KeyboardButton("⭐ Избранное")
    orders_btn = types.KeyboardButton("📋 Мои заказы")
    settings_btn = types.KeyboardButton("⚙️ Настройки")
    support_btn = types.KeyboardButton("📞 Поддержка")
    promo_btn = types.KeyboardButton("🎁 Промокоды")
    donat_btn = types.KeyboardButton("💲 Донат")
    steam_btn = types.KeyboardButton("🎮 Пополнить Steam")
    markup.add(catalog_btn, cart_btn, search_btn, favorites_btn, orders_btn, settings_btn, support_btn, promo_btn, donat_btn, steam_btn)
    return markup

# Клавиатура админ-панели
def get_admin_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    games_btn = types.KeyboardButton("🎮 Управление играми")
    users_btn = types.KeyboardButton("👥 Управление пользователями")
    stats_btn = types.KeyboardButton("📊 Статистика")
    promo_btn = types.KeyboardButton("🎁 Управление промокодами")
    notify_btn = types.KeyboardButton("📢 Рассылка")
    orders_btn = types.KeyboardButton("📋 Заказы")
    payments_btn = types.KeyboardButton("💰 Платежи")
    exit_btn = types.KeyboardButton("🚪 Выход из админ-панели")
    markup.add(games_btn, users_btn, stats_btn, promo_btn, notify_btn, orders_btn, payments_btn, exit_btn)
    return markup

# Клавиатура управления играми
def get_admin_games_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    add_btn = types.InlineKeyboardButton("➕ Добавить игру", callback_data="admin_add_game")
    edit_btn = types.InlineKeyboardButton("✏️ Редактировать игру", callback_data="admin_edit_game")
    delete_btn = types.InlineKeyboardButton("🗑️ Удалить игру", callback_data="admin_delete_game")
    list_btn = types.InlineKeyboardButton("📋 Список игр", callback_data="admin_list_games")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    markup.add(add_btn, edit_btn, delete_btn, list_btn, back_btn)
    return markup

# Клавиатура управления пользователями
def get_admin_users_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    list_btn = types.InlineKeyboardButton("📋 Список пользователей", callback_data="admin_list_users")
    search_btn = types.InlineKeyboardButton("🔍 Поиск пользователя", callback_data="admin_search_user")
    ban_btn = types.InlineKeyboardButton("🚫 Заблокировать пользователя", callback_data="admin_ban_user")
    unban_btn = types.InlineKeyboardButton("✅ Разблокировать пользователя", callback_data="admin_unban_user")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    markup.add(list_btn, search_btn, ban_btn, unban_btn, back_btn)
    return markup

# Клавиатура управления заказами
def get_orders_management_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    search_order_btn = types.InlineKeyboardButton("🔍 Найти заказ", callback_data="admin_search_order")
    list_orders_btn = types.InlineKeyboardButton("📋 Список заказов", callback_data="admin_list_orders")
    change_status_btn = types.InlineKeyboardButton("✏️ Изменить статус заказа", callback_data="admin_change_order_status")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    
    markup.add(search_order_btn, list_orders_btn, change_status_btn, back_btn)
    
    return markup

# Клавиатура управления промокодами
def get_admin_promo_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    add_btn = types.InlineKeyboardButton("➕ Добавить промокод", callback_data="admin_add_promo")
    edit_btn = types.InlineKeyboardButton("✏️ Редактировать промокод", callback_data="admin_edit_promo")
    delete_btn = types.InlineKeyboardButton("🗑️ Удалить промокод", callback_data="admin_delete_promo")
    list_btn = types.InlineKeyboardButton("📋 Список промокодов", callback_data="admin_list_promos")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    markup.add(add_btn, edit_btn, delete_btn, list_btn, back_btn)
    return markup

# Клавиатура для выбора типа промокода
def get_promo_type_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    percent_btn = types.InlineKeyboardButton("% Процентная скидка", callback_data="admin_promo_type_percent")
    fixed_btn = types.InlineKeyboardButton("₽ Фиксированная скидка", callback_data="admin_promo_type_fixed")
    free_game_btn = types.InlineKeyboardButton("🎮 Бесплатная игра", callback_data="admin_promo_type_free_game")
    steam_btn = types.InlineKeyboardButton("🎮 Бонус Steam", callback_data="admin_promo_type_steam_topup")
    first_order_btn = types.InlineKeyboardButton("🛒 Скидка на первый заказ", callback_data="admin_promo_type_first_order")
    cancel_btn = types.InlineKeyboardButton("❌ Отмена", callback_data="admin_back_to_promo")
    
    markup.add(percent_btn, fixed_btn, free_game_btn, steam_btn, first_order_btn, cancel_btn)
    
    return markup

# Клавиатура для статистики
def get_admin_stats_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    sales_btn = types.InlineKeyboardButton("💰 Статистика продаж", callback_data="admin_stats_sales")
    users_btn = types.InlineKeyboardButton("👥 Статистика пользователей", callback_data="admin_stats_users")
    games_btn = types.InlineKeyboardButton("🎮 Статистика игр", callback_data="admin_stats_games")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    
    markup.add(sales_btn, users_btn, games_btn, back_btn)
    
    return markup

# Клавиатура для рассылки
def get_admin_notify_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    all_btn = types.InlineKeyboardButton("📢 Всем пользователям", callback_data="admin_notify_all")
    selected_btn = types.InlineKeyboardButton("📢 Выбранным пользователям", callback_data="admin_notify_selected")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    markup.add(all_btn, selected_btn, back_btn)
    return markup

# Клавиатура настроек
def get_settings_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    currency_btn = types.InlineKeyboardButton("💰 Изменить валюту", callback_data="settings_currency")
    notifications_btn = types.InlineKeyboardButton("🔔 Настройки уведомлений", callback_data="settings_notifications")
    language_btn = types.InlineKeyboardButton("🌐 Изменить язык", callback_data="settings_language")
    genres_btn = types.InlineKeyboardButton("🎭 Предпочитаемые жанры", callback_data="settings_genres")
    platforms_btn = types.InlineKeyboardButton("💻 Предпочитаемые платформы", callback_data="settings_platforms")
    profile_btn = types.InlineKeyboardButton("👤 Управление профилем", callback_data="settings_profile")
    email_btn = types.InlineKeyboardButton("✉️ Указать email (обязательно)", callback_data="profile_edit_email")
    back_btn = types.InlineKeyboardButton("⬅️ Назад в меню", callback_data="back_to_menu")
    markup.add(currency_btn, notifications_btn, language_btn, genres_btn, platforms_btn, profile_btn, email_btn, back_btn)
    return markup

# Клавиатура выбора валюты
def get_currency_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    for code, info in currencies.items():
        btn = types.InlineKeyboardButton(f"{info['name']} ({info['symbol']})", callback_data=f"currency_{code}")
        markup.add(btn)
    back_btn = types.InlineKeyboardButton("⬅️ Назад к настройкам", callback_data="back_to_settings")
    markup.add(back_btn)
    return markup

# Клавиатура выбора жанров
def get_genres_keyboard(user_id):
    settings = get_user_settings(user_id)
    preferred_genres = settings["preferred_genres"]
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    for genre in genres_list:
        if genre in preferred_genres:
            btn = types.InlineKeyboardButton(f"✅ {genre}", callback_data=f"toggle_genre_{genre}")
        else:
            btn = types.InlineKeyboardButton(f"❌ {genre}", callback_data=f"toggle_genre_{genre}")
        markup.add(btn)
    
    save_btn = types.InlineKeyboardButton("💾 Сохранить", callback_data="save_genres")
    back_btn = types.InlineKeyboardButton("⬅️ Назад к настройкам", callback_data="back_to_settings")
    markup.add(save_btn, back_btn)
    
    return markup

# Клавиатура выбора платформ
def get_platforms_keyboard(user_id):
    settings = get_user_settings(user_id)
    preferred_platforms = settings["preferred_platforms"]
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    for platform in platforms_list:
        if platform in preferred_platforms:
            btn = types.InlineKeyboardButton(f"✅ {platform}", callback_data=f"toggle_platform_{platform}")
        else:
            btn = types.InlineKeyboardButton(f"❌ {platform}", callback_data=f"toggle_platform_{platform}")
        markup.add(btn)
    
    save_btn = types.InlineKeyboardButton("💾 Сохранить", callback_data="save_platforms")
    back_btn = types.InlineKeyboardButton("⬅️ Назад к настройкам", callback_data="back_to_settings")
    markup.add(save_btn, back_btn)
    
    return markup

# Клавиатура для пополнения Steam
def get_steam_topup_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    # Добавляем кнопки с разными суммами пополнения
    amounts = [100, 200, 500, 1000, 2000, 5000]
    buttons = []
    
    for amount in amounts:
        btn = types.InlineKeyboardButton(f"{amount} ₽", callback_data=f"steam_amount_{amount}")
        buttons.append(btn)
    
    markup.add(*buttons)
    
    # Кнопка для ввода произвольной суммы
    custom_btn = types.InlineKeyboardButton("Другая сумма", callback_data="steam_amount_custom")
    history_btn = types.InlineKeyboardButton("📋 История пополнений", callback_data="steam_history")
    back_btn = types.InlineKeyboardButton("⬅️ Назад в меню", callback_data="back_to_menu")
    
    markup.add(custom_btn)
    markup.add(history_btn)
    markup.add(back_btn)
    
    return markup

# Клавиатура подтверждения пополнения Steam
def get_steam_confirm_keyboard(amount):
    markup = types.InlineKeyboardMarkup(row_width=1)
    confirm_btn = types.InlineKeyboardButton("✅ Подтвердить", callback_data=f"steam_confirm_{amount}")
    promo_btn = types.InlineKeyboardButton("🎁 Применить промокод", callback_data=f"steam_apply_promo_{amount}")
    cancel_btn = types.InlineKeyboardButton("❌ Отмена", callback_data="steam_cancel")
    markup.add(confirm_btn, promo_btn, cancel_btn)
    return markup

# Клавиатура выбора способа оплаты для Steam
def get_steam_payment_method_keyboard(amount):
    markup = types.InlineKeyboardMarkup(row_width=1)
    card_btn = types.InlineKeyboardButton("💳 Банковская карта", callback_data=f"steam_payment_card_{amount}")
    yoomoney_btn = types.InlineKeyboardButton("💵 ЮMoney", callback_data=f"steam_payment_yoomoney_{amount}")
    perevod_btn = types.InlineKeyboardButton("💸 Перевод", callback_data=f"steam_payment_perevod_{amount}")
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="steam_back_to_amounts")
    markup.add(card_btn, yoomoney_btn, perevod_btn, back_btn)
    return markup

# Клавиатура уведомлений
def get_notifications_keyboard(user_id):
    settings = get_user_settings(user_id)
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    if settings["notifications"]:
        notifications_btn = types.InlineKeyboardButton("🔕 Отключить уведомления", callback_data="notifications_off")
    else:
        notifications_btn = types.InlineKeyboardButton("🔔 Включить уведомления", callback_data="notifications_on")
    
    back_btn = types.InlineKeyboardButton("⬅️ Назад к настройкам", callback_data="back_to_settings")
    markup.add(notifications_btn, back_btn)
    return markup

# Клавиатура выбора языка
def get_language_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    for code, name in languages.items():
        btn = types.InlineKeyboardButton(name, callback_data=f"language_{code}")
        markup.add(btn)
    back_btn = types.InlineKeyboardButton("⬅️ Назад к настройкам", callback_data="back_to_settings")
    markup.add(back_btn)
    return markup

# Клавиатура управления профилем
def get_profile_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    name_btn = types.InlineKeyboardButton("✏️ Изменить имя", callback_data="profile_edit_name")
    email_btn = types.InlineKeyboardButton("✉️ Изменить email", callback_data="profile_edit_email")
    delete_btn = types.InlineKeyboardButton("🗑️ Удалить мои данные", callback_data="profile_delete_data")
    back_btn = types.InlineKeyboardButton("⬅️ Назад к настройкам", callback_data="back_to_settings")
    markup.add(name_btn, email_btn, delete_btn, back_btn)
    return markup

# Клавиатура каталога
def get_catalog_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    # Категории игр
    action_btn = types.InlineKeyboardButton("🔫 Action", callback_data="catalog_genre_Action")
    rpg_btn = types.InlineKeyboardButton("🧙‍♂️ RPG", callback_data="catalog_genre_RPG")
    shooter_btn = types.InlineKeyboardButton("🎯 Шутер", callback_data="catalog_genre_Шутер")
    adventure_btn = types.InlineKeyboardButton("🌍 Приключение", callback_data="catalog_genre_Приключение")
    simulation_btn = types.InlineKeyboardButton("🚗 Симулятор", callback_data="catalog_genre_Симулятор")
    sports_btn = types.InlineKeyboardButton("⚽ Спорт", callback_data="catalog_genre_Спорт")
    horror_btn = types.InlineKeyboardButton("👻 Хоррор", callback_data="catalog_genre_Хоррор")
    survival_btn = types.InlineKeyboardButton("🏕️ Выживание", callback_data="catalog_genre_Выживание")
    
    # Платформы
    steam_btn = types.InlineKeyboardButton("Steam", callback_data="catalog_platform_Steam")
    pc_btn = types.InlineKeyboardButton("PC", callback_data="catalog_platform_PC")
    playstation_btn = types.InlineKeyboardButton("PlayStation", callback_data="catalog_platform_PlayStation")
    xbox_btn = types.InlineKeyboardButton("Xbox", callback_data="catalog_platform_Xbox")
    switch_btn = types.InlineKeyboardButton("Switch", callback_data="catalog_platform_Switch")
    
    # Специальные категории
    new_btn = types.InlineKeyboardButton("🆕 Новинки", callback_data="catalog_special_new")
    sale_btn = types.InlineKeyboardButton("🔥 Скидки", callback_data="catalog_special_sale")
    popular_btn = types.InlineKeyboardButton("⭐ Популярные", callback_data="catalog_special_popular")
    all_btn = types.InlineKeyboardButton("📋 Все игры", callback_data="catalog_special_all")
    
    # Кнопка возврата в меню
    back_btn = types.InlineKeyboardButton("⬅️ Назад в меню", callback_data="back_to_menu")
    
    # Добавляем кнопки в разметку
    markup.add(action_btn, rpg_btn, shooter_btn, adventure_btn, simulation_btn, sports_btn, horror_btn, survival_btn)
    markup.add(steam_btn, pc_btn, playstation_btn, xbox_btn, switch_btn)
    markup.add(new_btn, sale_btn, popular_btn, all_btn)
    markup.add(back_btn)
    
    return markup

# Клавиатура пагинации для категорий
def get_pagination_keyboard(category, current_page, total_pages):
    markup = types.InlineKeyboardMarkup(row_width=5)
    
    # Кнопки пагинации
    buttons = []
    
    # Кнопка "Назад"
    if current_page > 1:
        prev_btn = types.InlineKeyboardButton("⬅️", callback_data=f"page_{category}_{current_page - 1}")
        buttons.append(prev_btn)
    
    # Кнопка с информацией о текущей странице
    page_info_btn = types.InlineKeyboardButton(f"{current_page}/{total_pages}", callback_data="page_info")
    buttons.append(page_info_btn)
    
    # Кнопка "Вперед"
    if current_page < total_pages:
        next_btn = types.InlineKeyboardButton("➡️", callback_data=f"page_{category}_{current_page + 1}")
        buttons.append(next_btn)
    
    markup.add(*buttons)
    
    # Кнопки действий
    cart_btn = types.InlineKeyboardButton("🛒 Корзина", callback_data="go_to_cart")
    back_btn = types.InlineKeyboardButton("⬅️ Назад в каталог", callback_data="back_to_catalog")
    
    markup.add(cart_btn, back_btn)
    
    return markup

# Клавиатура выбора типа поиска
def get_search_type_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    name_btn = types.InlineKeyboardButton("🔤 Поиск по названию", callback_data="search_by_name")
    price_btn = types.InlineKeyboardButton("💰 Поиск по цене", callback_data="search_by_price")
    genre_btn = types.InlineKeyboardButton("🎭 Поиск по жанру", callback_data="search_by_genre")
    platform_btn = types.InlineKeyboardButton("💻 Поиск по платформе", callback_data="search_by_platform")
    back_btn = types.InlineKeyboardButton("⬅️ Назад в меню", callback_data="back_to_menu")
    markup.add(name_btn, price_btn, genre_btn, platform_btn, back_btn)
    return markup

# Клавиатура сортировки результатов поиска
def get_sort_results_keyboard(category):
    markup = types.InlineKeyboardMarkup(row_width=2)
    price_asc_btn = types.InlineKeyboardButton("💰 По цене (возр.)", callback_data=f"sort_{category}_price_asc")
    price_desc_btn = types.InlineKeyboardButton("💰 По цене (убыв.)", callback_data=f"sort_{category}_price_desc")
    rating_btn = types.InlineKeyboardButton("⭐ По рейтингу", callback_data=f"sort_{category}_rating")
    name_btn = types.InlineKeyboardButton("🔤 По названию", callback_data=f"sort_{category}_name")
    back_btn = types.InlineKeyboardButton("⬅️ Назад к результатам", callback_data=f"back_to_{category}")
    markup.add(price_asc_btn, price_desc_btn, rating_btn, name_btn, back_btn)
    return markup

# Клавиатура для отзывов
def get_reviews_keyboard(game_id, user_id):
    markup = types.InlineKeyboardMarkup(row_width=1)
    add_review_btn = types.InlineKeyboardButton("✍️ Оставить отзыв", callback_data=f"add_review_{game_id}")
    back_btn = types.InlineKeyboardButton("⬅️ Назад к игре", callback_data=f"game_details_{game_id}")
    markup.add(add_review_btn, back_btn)
    
    return markup

# Клавиатура для оценки в отзыве
def get_rating_keyboard(game_id):
    markup = types.InlineKeyboardMarkup(row_width=5)
    
    # Кнопки с оценками от 1 до 5
    rating_buttons = []
    for i in range(1, 6):
        stars = "⭐" * i
        btn = types.InlineKeyboardButton(stars, callback_data=f"rating_{game_id}_{i}")
        rating_buttons.append(btn)
    
    markup.add(*rating_buttons)
    
    # Кнопка отмены
    cancel_btn = types.InlineKeyboardButton("❌ Отмена", callback_data=f"game_details_{game_id}")
    markup.add(cancel_btn)
    
    return markup

# Клавиатура для выбора жанра при поиске
def get_genre_search_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    for genre in genres_list:
        btn = types.InlineKeyboardButton(genre, callback_data=f"search_genre_{genre}")
        markup.add(btn)
    
    back_btn = types.InlineKeyboardButton("⬅️ Назад к поиску", callback_data="back_to_search")
    markup.add(back_btn)
    
    return markup

# Клавиатура для выбора платформы при поиске
def get_platform_search_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    for platform in platforms_list:
        btn = types.InlineKeyboardButton(platform, callback_data=f"search_platform_{platform}")
        markup.add(btn)
    
    back_btn = types.InlineKeyboardButton("⬅️ Назад к поиску", callback_data="back_to_search")
    markup.add(back_btn)
    
    return markup

# Клавиатура выбора способа оплаты
def get_payment_methods_keyboard(order_id):
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    for method_code, method_info in payment_methods.items():
        commission_text = f" (+{method_info['commission']}% комиссия)" if method_info['commission'] > 0 else ""
        btn = types.InlineKeyboardButton(f"{method_info['name']}{commission_text}", callback_data=f"payment_method_{method_code}_{order_id}")
        markup.add(btn)
    
    cancel_btn = types.InlineKeyboardButton("❌ Отмена", callback_data="cancel_payment")
    markup.add(cancel_btn)
    
    return markup

# Функция для отображения игр по категории
def show_category_games(chat_id, category_type, category_value, page=1):
    # Фильтруем игры по категории
    if category_type == "genre":
        filtered_games = [game for game in games if game["genre"] == category_value]
    elif category_type == "platform":
        filtered_games = [game for game in games if category_value in game["platform"]]
    elif category_type == "special":
        if category_value == "new":
            # Предположим, что новые игры - это последние 5 добавленных
            filtered_games = games[-5:]
        elif category_value == "sale":
            # Игры со скидками
            filtered_games = [game for game in games if game.get("discount")]
        elif category_value == "popular":
            # Игры с высоким рейтингом
            filtered_games = sorted(games, key=lambda x: x["rating"], reverse=True)[:8]
        elif category_value == "all":
            # Все игры
            filtered_games = games
        else:
            filtered_games = []
    else:
        filtered_games = []
    
    # Если игр не найдено
    if not filtered_games:
        bot.send_message(
            chat_id,
            "❌ Игры в данной категории не найдены.",
            parse_mode="Markdown"
        )
        return
    
    # Сохраняем категорию для пагинации
    category_key = f"{category_type}_{category_value}"
    
    # Вычисляем общее количество страниц
    total_pages = max(1, (len(filtered_games) + GAMES_PER_PAGE - 1) // GAMES_PER_PAGE)
    
    # Проверяем, не вышли ли мы за пределы диапазона страниц
    if page < 1:
        page = 1
    elif page > total_pages:
        page = total_pages
    
    # Вычисляем индексы для текущей страницы
    start_idx = (page - 1) * GAMES_PER_PAGE
    end_idx = min(start_idx + GAMES_PER_PAGE, len(filtered_games))
    
    # Получаем игры для текущей страницы
    page_games = filtered_games[start_idx:end_idx]
    
    # Формируем заголовок категории
    if category_type == "genre":
        category_title = f"🎭 Жанр: {category_value}"
    elif category_type == "platform":
        category_title = f"💻 Платформа: {category_value}"
    elif category_type == "special":
        if category_value == "new":
            category_title = "🆕 Новинки"
        elif category_value == "sale":
            category_title = "🔥 Скидки"
        elif category_value == "popular":
            category_title = "⭐ Популярные игры"
        elif category_value == "all":
            category_title = "📋 Все игры"
        else:
            category_title = "Игры"
    else:
        category_title = "Игры"
    
    # Отправляем заголовок
    bot.send_message(
        chat_id,
        f"{category_title} (страница {page}/{total_pages}):",
        parse_mode="Markdown"
    )
    
    # Отправляем каждую игру отдельным сообщением
    for game in page_games:
        # Формируем текст с информацией об игре
        game_title = escape_markdown(game['title'])
        game_text = f"🎮 *{game_title}*\n"
        game_text += f"💰 Цена: {convert_price(game['price'], chat_id)}"
        
        if game.get("discount"):
            game_text += f" (скидка {game['discount']})"
        
        game_text += f"\n🎭 Жанр: {escape_markdown(game['genre'])}\n"
        game_text += f"💻 Платформы: {escape_markdown(', '.join(game['platform']))}\n"
        game_text += f"⭐ Рейтинг: {game['rating']}/5 ({len(game.get('reviews', []))} отзывов)"
        
        # Добавляем кнопки для каждой игры
        markup = types.InlineKeyboardMarkup(row_width=2)
        details_btn = types.InlineKeyboardButton("📋 Подробнее", callback_data=f"game_details_{game['id']}")
        cart_btn = types.InlineKeyboardButton("🛒 В корзину", callback_data=f"add_to_cart_{game['id']}")
        fav_btn = types.InlineKeyboardButton("⭐ В избранное", callback_data=f"add_favorite_{game['id']}")
        markup.add(details_btn, cart_btn, fav_btn)
        
        # Отправляем сообщение с игрой
        try:
            # Проверяем, существует ли изображение в локальной папке
            if image_exists(game["image"]):
                send_image_from_folder(
                    chat_id,
                    game["image"],
                    caption=game_text,
                    parse_mode="Markdown",
                    reply_markup=markup
                )
            else:
                # Если изображение не найдено, отправляем сообщение без изображения
                bot.send_message(
                    chat_id,
                    game_text,
                    parse_mode="Markdown",
                    reply_markup=markup
                )
        except Exception as e:
            logger.error(f"Ошибка при отправке фото: {e}")
            bot.send_message(
                chat_id,
                game_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
    
    # Отправляем клавиатуру пагинации
    if total_pages > 1:
        markup = get_pagination_keyboard(category_key, page, total_pages)
        
        bot.send_message(
            chat_id,
            "Используйте кнопки ниже для навигации:",
            reply_markup=markup
        )

# Функция для отображения отзывов игры
def show_game_reviews(message, game_id, user_id):
    game = next((g for g in games if g["id"] == game_id), None)
    if not game:
        bot.send_message(
            message.chat.id,
            "❌ Игра не найдена.",
            parse_mode="Markdown"
        )
        return
    
    game_title = escape_markdown(game['title'])
    reviews_text = f"📝 *Отзывы о игре {game_title}*\n\n"
    
    if not game["reviews"]:
        reviews_text += "Пока нет отзывов. Будьте первым, кто оставит отзыв!"
    else:
        for review in game["reviews"]:
            stars = "⭐" * review["rating"]
            username = escape_markdown(review['username'])
            review_text = escape_markdown(review['text'])
            reviews_text += f"{stars}\n"
            reviews_text += f"👤 {username}\n"
            reviews_text += f"📅 {review['date']}\n"
            reviews_text += f"💬 {review_text}\n\n"
    
    bot.send_message(
        message.chat.id,
        reviews_text,
        parse_mode="Markdown",
        reply_markup=get_reviews_keyboard(game_id, user_id)
    )

# Функция для отображения деталей игры
def show_game_details(message, game_id, user_id):
    game = next((g for g in games if g["id"] == game_id), None)
    if not game:
        bot.send_message(
            message.chat.id,
            "❌ Игра не найдена.",
            parse_mode="Markdown"
        )
        return
    
    # Формируем текст с деталями игры
    game_title = escape_markdown(game['title'])
    game_description = escape_markdown(game['description'])
    details_text = f"🎮 *{game_title}*\n\n"
    details_text += f"{game_description}\n\n"
    details_text += f"💰 Цена: {convert_price(game['price'], user_id)}"
    
    if game.get("discount"):
        details_text += f" (скидка {game['discount']})"
    
    details_text += f"\n🎭 Жанр: {escape_markdown(game['genre'])}\n"
    details_text += f"💻 Платформы: {escape_markdown(', '.join(game['platform']))}\n"
    details_text += f"⭐ Рейтинг: {game['rating']}/5 ({len(game.get('reviews', []))} отзывов)\n"
    
    # Проверяем, доступна ли игра
    if "available" in game and not game["available"]:
        details_text += "\n⚠️ *Игра временно недоступна*\n"
    
    # Формируем клавиатуру для деталей игры
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    # Кнопки действий
    if "available" not in game or game["available"]:
        cart_btn = types.InlineKeyboardButton("🛒 В корзину", callback_data=f"add_to_cart_{game_id}")
        markup.add(cart_btn)
    
    # Проверяем, в избранном ли игра
    if user_id in user_favorites and game_id in user_favorites[user_id]:
        fav_btn = types.InlineKeyboardButton("❌ Удалить из избранного", callback_data=f"remove_favorite_{game_id}")
    else:
        fav_btn = types.InlineKeyboardButton("⭐ В избранное", callback_data=f"add_favorite_{game_id}")
    
    reviews_btn = types.InlineKeyboardButton("📝 Отзывы", callback_data=f"game_reviews_{game_id}")
    
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="back_to_catalog")
    
    markup.add(fav_btn)
    markup.add(reviews_btn)
    markup.add(back_btn)
    
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists(game["image"]):
            send_image_from_folder(
                message.chat.id,
                game["image"],
                caption=details_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            # Если изображение не найдено, отправляем сообщение без изображения
            bot.send_message(
                message.chat.id,
                details_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        bot.send_message(
            message.chat.id,
            details_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Функция для добавления отзыва
def start_add_review(message, game_id):
    user_id = message.from_user.id
    
    # Проверяем, не оставлял ли пользователь уже отзыв
    game = next((g for g in games if g["id"] == game_id), None)
    if game:
        existing_review = next((r for r in game["reviews"] if r["user_id"] == user_id), None)
        if existing_review:
            markup = types.InlineKeyboardMarkup(row_width=1)
            edit_btn = types.InlineKeyboardButton("✏️ Изменить отзыв", callback_data=f"edit_review_{game_id}")
            delete_btn = types.InlineKeyboardButton("🗑️ Удалить отзыв", callback_data=f"delete_review_{game_id}")
            back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data=f"game_reviews_{game_id}")
            markup.add(edit_btn, delete_btn, back_btn)
            
            review_text = escape_markdown(existing_review['text'])
            bot.send_message(
                message.chat.id,
                f"⚠️ Вы уже оставили отзыв для этой игры:\n\n"
                f"{'⭐' * existing_review['rating']}\n"
                f"💬 {review_text}\n\n"
                f"Вы можете изменить или удалить свой отзыв.",
                parse_mode="Markdown",
                reply_markup=markup
            )
            return
    
    # Сохраняем состояние отзыва
    user_review_state[user_id] = {
        "game_id": game_id,
        "step": "rating"
    }
    
    # Запрашиваем оценку
    bot.send_message(
        message.chat.id,
        "⭐ *Оцените игру от 1 до 5 звезд:*",
        parse_mode="Markdown",
        reply_markup=get_rating_keyboard(game_id)
    )

# Обработчик выбора рейтинга
def process_review_rating(message, game_id, rating):
    user_id = message.from_user.id
    
    # Сохраняем рейтинг
    user_review_state[user_id]["rating"] = rating
    user_review_state[user_id]["step"] = "text"
    
    # Запрашиваем текст отзыва
    bot.send_message(
        message.chat.id,
        f"💬 Вы поставили оценку: {'⭐' * rating}\n\n"
        f"Теперь напишите текст отзыва (или отправьте /skip, чтобы пропустить):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_review_text)

# Обработчик ввода текста отзыва
def process_review_text(message):
    user_id = message.from_user.id
    
    if user_id not in user_review_state:
        bot.send_message(
            message.chat.id,
            "❌ Произошла ошибка. Пожалуйста, начните процесс оставления отзыва заново.",
            parse_mode="Markdown"
        )
        return
    
    game_id = user_review_state[user_id]["game_id"]
    rating = user_review_state[user_id]["rating"]
    
    # Получаем текст отзыва
    if message.text == "/skip":
        review_text = "Без комментариев"
    else:
        review_text = message.text
    
    # Сохраняем текст отзыва
    user_review_state[user_id]["text"] = review_text
    
    # Показываем предпросмотр отзыва
    preview_text = (
        f"📝 *Предпросмотр отзыва:*\n\n"
        f"⭐ Оценка: {'⭐' * rating}\n"
        f"💬 Текст: {escape_markdown(review_text)}\n\n"
        f"Подтвердите отправку отзыва:"
    )
    
    markup = types.InlineKeyboardMarkup(row_width=2)
    confirm_btn = types.InlineKeyboardButton("✅ Подтвердить", callback_data=f"confirm_review_{game_id}")
    cancel_btn = types.InlineKeyboardButton("❌ Отмена", callback_data=f"cancel_review_{game_id}")
    markup.add(confirm_btn, cancel_btn)
    
    bot.send_message(
        message.chat.id,
        preview_text,
        parse_mode="Markdown",
        reply_markup=markup
    )

# Функция для сохранения отзыва
def save_review(message, user_id):
    if user_id not in user_review_state:
        bot.send_message(
            message.chat.id,
            "❌ Произошла ошибка. Пожалуйста, начните процесс оставления отзыва заново.",
            parse_mode="Markdown"
        )
        return
    
    game_id = user_review_state[user_id]["game_id"]
    rating = user_review_state[user_id]["rating"]
    text = user_review_state[user_id]["text"]
    
    # Находим игру
    game = next((g for g in games if g["id"] == game_id), None)
    if not game:
        bot.send_message(
            message.chat.id,
            "❌ Игра не найдена.",
            parse_mode="Markdown"
        )
        return
    
    # Проверяем, не оставлял ли пользователь уже отзыв
    existing_review = next((r for r in game["reviews"] if r["user_id"] == user_id), None)
    if existing_review:
        # Обновляем существующий отзыв
        existing_review["rating"] = rating
        existing_review["text"] = text
        existing_review["date"] = datetime.now().strftime("%Y-%m-%d")
    else:
        # Создаем новый отзыв
        username = message.from_user.username or f"user{user_id}"
        new_review = {
            "user_id": user_id,
            "username": username,
            "rating": rating,
            "text": text,
            "date": datetime.now().strftime("%Y-%m-%d")
        }
        game["reviews"].append(new_review)
    
    # Обновляем общий рейтинг игры
    total_rating = sum(review["rating"] for review in game["reviews"])
    game["rating"] = round(total_rating / len(game["reviews"]), 1)
    
    # Очищаем состояние отзыва
    del user_review_state[user_id]
    
    bot.send_message(
        message.chat.id,
        "✅ Ваш отзыв успешно сохранен! Спасибо за ваше мнение.",
        parse_mode="Markdown"
    )
    
    # Показываем обновленные отзывы
    show_game_reviews(message, game_id, user_id)

# Функция для удаления отзыва
def delete_review(message, game_id, user_id):
    # Находим игру
    game = next((g for g in games if g["id"] == game_id), None)
    if not game:
        bot.send_message(
            message.chat.id,
            "❌ Игра не найдена.",
            parse_mode="Markdown"
        )
        return
    
    # Находим и удаляем отзыв пользователя
    game["reviews"] = [r for r in game["reviews"] if r["user_id"] != user_id]
    
    # Обновляем общий рейтинг игры
    if game["reviews"]:
        total_rating = sum(review["rating"] for review in game["reviews"])
        game["rating"] = round(total_rating / len(game["reviews"]), 1)
    else:
        # Если отзывов нет, устанавливаем рейтинг по умолчанию
        game["rating"] = 0.0
    
    bot.send_message(
        message.chat.id,
        "✅ Ваш отзыв успешно удален.",
        parse_mode="Markdown"
    )
    
    # Показываем обновленные отзывы
    show_game_reviews(message, game_id, user_id)

# Показать страницу избранных игр
def show_favorites_page(chat_id, user_id, page):
    if user_id not in user_favorites or not user_favorites[user_id]:
        bot.send_message(
            chat_id,
            "⭐ *Ваш список избранного пуст*\n\nДобавьте игры в избранное из каталога.",
            parse_mode="Markdown",
            reply_markup=get_main_keyboard()
        )
        return

    # Получаем избранные игры
    favorite_game_ids = user_favorites[user_id]
    favorite_games = [game for game in games if game["id"] in favorite_game_ids]

    # Вычисляем общее количество страниц
    total_pages = max(1, (len(favorite_games) + GAMES_PER_PAGE - 1) // GAMES_PER_PAGE)

    # Проверяем, не вышли ли мы за пределы диапазона страниц
    if page < 1:
        page = 1
    elif page > total_pages:
        page = total_pages

    # Вычисляем индексы для текущей страницы
    start_idx = (page - 1) * GAMES_PER_PAGE
    end_idx = min(start_idx + GAMES_PER_PAGE, len(favorite_games))

    # Получаем игры для текущей страницы
    page_games = favorite_games[start_idx:end_idx]

    # Отправляем заголовок
    bot.send_message(
        chat_id,
        f"⭐ *Ваши избранные игры* (страница {page}/{total_pages}):",
        parse_mode="Markdown"
    )

    # Отправляем каждую игру отдельным сообщением
    for game in page_games:
        # Формируем текст с информацией об игре
        game_title = escape_markdown(game['title'])
        game_text = f"🎮 *{game_title}*\n"
        game_text += f"💰 Цена: {convert_price(game['price'], user_id)}"
        
        if game.get("discount"):
            game_text += f" (скидка {game['discount']})"
        
        game_text += f"\n🎭 Жанр: {escape_markdown(game['genre'])}\n"
        game_text += f"💻 Платформы: {escape_markdown(', '.join(game['platform']))}\n"
        game_text += f"⭐ Рейтинг: {game['rating']}/5 ({len(game.get('reviews', []))} отзывов)"
        
        # Добавляем кнопки для каждой игры
        markup = types.InlineKeyboardMarkup(row_width=2)
        details_btn = types.InlineKeyboardButton("📋 Подробнее", callback_data=f"game_details_{game['id']}")
        cart_btn = types.InlineKeyboardButton("🛒 В корзину", callback_data=f"add_to_cart_{game['id']}")
        remove_btn = types.InlineKeyboardButton("❌ Удалить из избранного", callback_data=f"remove_favorite_{game['id']}")
        markup.add(details_btn, cart_btn, remove_btn)
        
        # Отправляем сообщение с игрой
        try:
            # Проверяем, существует ли изображение в локальной папке
            if image_exists(game["image"]):
                send_image_from_folder(
                    chat_id,
                    game["image"],
                    caption=game_text,
                    parse_mode="Markdown",
                    reply_markup=markup
                )
            else:
                # Если изображение не найдено, отправляем сообщение без изображения
                bot.send_message(
                    chat_id,
                    game_text,
                    parse_mode="Markdown",
                    reply_markup=markup
                )
        except Exception as e:
            logger.error(f"Ошибка при отправке фото: {e}")
            bot.send_message(
                chat_id,
                game_text,
                parse_mode="Markdown",
                reply_markup=markup
            )

    # Отправляем клавиатуру пагинации
    if total_pages > 1:
        markup = types.InlineKeyboardMarkup(row_width=5)
        buttons = []
        
        # Кнопка "Назад"
        if page > 1:
            prev_btn = types.InlineKeyboardButton("⬅️", callback_data=f"page_favorites_{page - 1}")
            buttons.append(prev_btn)
        
        # Кнопка с информацией о текущей странице
        page_info_btn = types.InlineKeyboardButton(f"{page}/{total_pages}", callback_data="page_info")
        buttons.append(page_info_btn)
        
        # Кнопка "Вперед"
        if page < total_pages:
            next_btn = types.InlineKeyboardButton("➡️", callback_data=f"page_favorites_{page + 1}")
            buttons.append(next_btn)
        
        markup.add(*buttons)
        
        # Кнопки действий
        catalog_btn = types.InlineKeyboardButton("🎮 В каталог", callback_data="back_to_catalog")
        menu_btn = types.InlineKeyboardButton("🏠 В главное меню", callback_data="back_to_menu")
        markup.add(catalog_btn, menu_btn)
        
        bot.send_message(
            chat_id,
            "Используйте кнопки ниже для навигации:",
            reply_markup=markup
        )

# Показать страницу заказов
def show_orders_page(chat_id, user_id, page):
    if user_id not in user_orders or not user_orders[user_id]:
        bot.send_message(
            chat_id,
            "📋 *У вас пока нет заказов*\n\nОформите заказ в корзине, чтобы увидеть его здесь.",
            parse_mode="Markdown",
            reply_markup=get_main_keyboard()
        )
        return

    # Получаем заказы пользователя
    orders = user_orders[user_id]

    # Вычисляем общее количество страниц
    total_pages = max(1, (len(orders) + GAMES_PER_PAGE - 1) // GAMES_PER_PAGE)

    # Проверяем, не вышли ли мы за пределы диапазона страниц
    if page < 1:
        page = 1
    elif page > total_pages:
        page = total_pages

    # Вычисляем индексы для текущей страницы
    start_idx = (page - 1) * GAMES_PER_PAGE
    end_idx = min(start_idx + GAMES_PER_PAGE, len(orders))

    # Получаем заказы для текущей страницы
    page_orders = orders[start_idx:end_idx]

    # Отправляем заголовок
    bot.send_message(
        chat_id,
        f"📋 *Ваши заказы* (страница {page}/{total_pages}):",
        parse_mode="Markdown"
    )

    # Отправляем каждый заказ отдельным сообщением
    for order in page_orders:
        # Формируем текст с информацией о заказе
        order_text = f"🆔 Заказ #{order['id']}\n"
        order_text += f"📅 Дата: {order['date']}\n"
        order_text += f"💰 Сумма: {convert_price(order['total'], user_id)}\n"
        order_text += f"✅ Статус: {order['status']}\n\n"
        order_text += "🎮 Игры в заказе:\n"
        
        for game_id in order['games']:
            game = next((g for g in games if g["id"] == game_id), None)
            if game:
                game_title = escape_markdown(game['title'])
                order_text += f"- {game_title}\n"
        
        # Добавляем кнопки для каждого заказа
        markup = types.InlineKeyboardMarkup(row_width=1)
        details_btn = types.InlineKeyboardButton("📋 Подробнее", callback_data=f"order_details_{order['id']}")
        markup.add(details_btn)
        
        bot.send_message(
            chat_id,
            order_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

    # Отправляем клавиатуру пагинации
    if total_pages > 1:
        markup = types.InlineKeyboardMarkup(row_width=5)
        buttons = []
        
        # Кнопка "Назад"
        if page > 1:
            prev_btn = types.InlineKeyboardButton("⬅️", callback_data=f"page_orders_{page - 1}")
            buttons.append(prev_btn)
        
        # Кнопка с информацией о текущей странице
        page_info_btn = types.InlineKeyboardButton(f"{page}/{total_pages}", callback_data="page_info")
        buttons.append(page_info_btn)
        
        # Кнопка "Вперед"
        if page < total_pages:
            next_btn = types.InlineKeyboardButton("➡️", callback_data=f"page_orders_{page + 1}")
            buttons.append(next_btn)
        
        markup.add(*buttons)
        
        # Кнопки действий
        menu_btn = types.InlineKeyboardButton("🏠 В главное меню", callback_data="back_to_menu")
        markup.add(menu_btn)
        
        bot.send_message(
            chat_id,
            "Используйте кнопки ниже для навигации:",
            reply_markup=markup
        )

# Функция для отображения результатов поиска
def show_search_results(chat_id, results, category, user_id, page=1):
    if not results:
        bot.send_message(
            chat_id,
            "❌ Ничего не найдено.",
            parse_mode="Markdown"
        )
        return
    
    # Сохраняем результаты поиска
    user_search_results[user_id] = {
        "results": results,
        "category": category
    }
    
    # Вычисляем общее количество страниц
    total_pages = max(1, (len(results) + GAMES_PER_PAGE - 1) // GAMES_PER_PAGE)
    
    # Проверяем, не вышли ли мы за пределы диапазона страниц
    if page < 1:
        page = 1
    elif page > total_pages:
        page = total_pages
    
    # Вычисляем индексы для текущей страницы
    start_idx = (page - 1) * GAMES_PER_PAGE
    end_idx = min(start_idx + GAMES_PER_PAGE, len(results))
    
    # Получаем игры для текущей страницы
    page_games = results[start_idx:end_idx]
    
    # Отправляем заголовок
    bot.send_message(
        chat_id,
        f"🔍 *Результаты поиска* (страница {page}/{total_pages}):",
        parse_mode="Markdown"
    )
    
    # Отправляем каждую игру отдельным сообщением
    for game in page_games:
        # Формируем текст с информацией об игре
        game_title = escape_markdown(game['title'])
        game_text = f"🎮 *{game_title}*\n"
        game_text += f"💰 Цена: {convert_price(game['price'], user_id)}"
        
        if game.get("discount"):
            game_text += f" (скидка {game['discount']})"
        
        game_text += f"\n🎭 Жанр: {escape_markdown(game['genre'])}\n"
        game_text += f"💻 Платформы: {escape_markdown(', '.join(game['platform']))}\n"
        game_text += f"⭐ Рейтинг: {game['rating']}/5 ({len(game.get('reviews', []))} отзывов)"
        
        # Добавляем кнопки для каждой игры
        markup = types.InlineKeyboardMarkup(row_width=2)
        details_btn = types.InlineKeyboardButton("📋 Подробнее", callback_data=f"game_details_{game['id']}")
        cart_btn = types.InlineKeyboardButton("🛒 В корзину", callback_data=f"add_to_cart_{game['id']}")
        
        # Проверяем, в избранном ли игра
        if user_id in user_favorites and game["id"] in user_favorites[user_id]:
            fav_btn = types.InlineKeyboardButton("❌ Удалить из избранного", callback_data=f"remove_favorite_{game['id']}")
        else:
            fav_btn = types.InlineKeyboardButton("⭐ В избранное", callback_data=f"add_favorite_{game['id']}")
        
        markup.add(details_btn, cart_btn, fav_btn)
        
        # Отправляем сообщение с игрой
        try:
            # Проверяем, существует ли изображение в локальной папке
            if image_exists(game["image"]):
                send_image_from_folder(
                    chat_id,
                    game["image"],
                    caption=game_text,
                    parse_mode="Markdown",
                    reply_markup=markup
                )
            else:
                # Если изображение не найдено, отправляем сообщение без изображения
                bot.send_message(
                    chat_id,
                    game_text,
                    parse_mode="Markdown",
                    reply_markup=markup
                )
        except Exception as e:
            logger.error(f"Ошибка при отправке фото: {e}")
            bot.send_message(
                chat_id,
                game_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
    
    # Отправляем клавиатуру пагинации и сортировки
    if total_pages > 1:
        markup = types.InlineKeyboardMarkup(row_width=5)
        buttons = []
        
        # Кнопка "Назад"
        if page > 1:
            prev_btn = types.InlineKeyboardButton("⬅️", callback_data=f"page_search_{page - 1}")
            buttons.append(prev_btn)
        
        # Кнопка с информацией о текущей странице
        page_info_btn = types.InlineKeyboardButton(f"{page}/{total_pages}", callback_data="page_info")
        buttons.append(page_info_btn)
        
        # Кнопка "Вперед"
        if page < total_pages:
            next_btn = types.InlineKeyboardButton("➡️", callback_data=f"page_search_{page + 1}")
            buttons.append(next_btn)
        
        markup.add(*buttons)
        
        # Кнопки сортировки
        price_asc_btn = types.InlineKeyboardButton("💰 По цене (возр.)", callback_data="sort_search_price_asc")
        price_desc_btn = types.InlineKeyboardButton("💰 По цене (убыв.)", callback_data="sort_search_price_desc")
        rating_btn = types.InlineKeyboardButton("⭐ По рейтингу", callback_data=f"sort_search_rating")
        name_btn = types.InlineKeyboardButton("🔤 По названию", callback_data=f"sort_search_name")
        
        markup.add(price_asc_btn, price_desc_btn)
        markup.add(rating_btn, name_btn)
        
        # Кнопки действий
        search_btn = types.InlineKeyboardButton("🔍 Новый поиск", callback_data="back_to_search")
        menu_btn = types.InlineKeyboardButton("🏠 В главное меню", callback_data="back_to_menu")
        markup.add(search_btn, menu_btn)
        
        bot.send_message(
            chat_id,
            "Используйте кнопки ниже для навигации и сортировки:",
            reply_markup=markup
        )

# Функция для создания платежа
def create_payment(user_id, order_id, amount, payment_method):
    payment_id = generate_payment_id()
    
    # Создаем запись о платеже
    payment = {
        "id": payment_id,
        "user_id": user_id,
        "order_id": order_id,
        "amount": amount,
        "method": payment_method,
        "status": "pending",
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    # Сохраняем платеж
    if user_id not in user_payments:
        user_payments[user_id] = []
    user_payments[user_id].append(payment)
    
    return payment

# Функция для обновления статуса платежа
def update_payment_status(payment_id, status):
    for user_id, payments in user_payments.items():
        for payment in payments:
            if payment["id"] == payment_id:
                payment["status"] = status
                payment["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                return True
    return False

# Функция для получения платежа по ID
def get_payment_by_id(payment_id):
    for user_id, payments in user_payments.items():
        for payment in payments:
            if payment["id"] == payment_id:
                return payment
    return None

# Функция для получения заказа по ID
def get_order_by_id(user_id, order_id):
    if user_id in user_orders:
        for order in user_orders[user_id]:
            if order["id"] == order_id:
                return order
    return None

# Функция для отображения деталей платежа
def show_payment_details(chat_id, payment_id):
    payment = get_payment_by_id(payment_id)
    if not payment:
        bot.send_message(
            chat_id,
            "❌ Платеж не найден.",
            parse_mode="Markdown"
        )
        return
    
    # Формируем текст с информацией о платеже
    payment_text = f"💳 *Информация о платеже*\n\n"
    payment_text += f"🆔 ID платежа: {payment['id']}\n"
    payment_text += f"📅 Дата создания: {payment['created_at']}\n"
    payment_text += f"💰 Сумма: {payment['amount']} ₽\n"
    payment_text += f"💳 Способ оплаты: {payment_methods[payment['method']]['name']}\n"
    payment_text += f"✅ Статус: {payment['status']}\n"
    
    # Добавляем информацию о заказе, если это платеж за заказ
    if payment.get("order_id"):
        order = get_order_by_id(payment["user_id"], payment["order_id"])
        if order:
            payment_text += f"\n📦 *Информация о заказе*\n"
            payment_text += f"🆔 ID заказа: {order['id']}\n"
            payment_text += f"📅 Дата заказа: {order['date']}\n"
            payment_text += f"✅ Статус заказа: {order['status']}\n"
    
    # Формируем клавиатуру для платежа
    markup = types.InlineKeyboardMarkup(row_width=1)
    
    if payment["status"] == "pending":
        pay_btn = types.InlineKeyboardButton("💰 Оплатить", callback_data=f"pay_{payment_id}")
        cancel_btn = types.InlineKeyboardButton("❌ Отменить платеж", callback_data=f"cancel_payment_{payment_id}")
        markup.add(pay_btn, cancel_btn)
    
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="back_to_orders")
    markup.add(back_btn)
    
    bot.send_message(
        chat_id,
        payment_text,
        parse_mode="Markdown",
        reply_markup=markup
    )

# Функция для имитации процесса оплаты
def process_payment(chat_id, payment_id):
    payment = get_payment_by_id(payment_id)
    if not payment:
        bot.send_message(
            chat_id,
            "❌ Платеж не найден.",
            parse_mode="Markdown"
        )
        return
    
    # Имитируем процесс оплаты
    bot.send_message(
        chat_id,
        "💳 *Обработка платежа...*\n\nПожалуйста, подождите.",
        parse_mode="Markdown"
    )
    
    # Имитируем задержку
    time.sleep(2)
    
    # Обновляем статус платежа
    update_payment_status(payment_id, "completed")
    
    # Обновляем статус заказа, если это платеж за заказ
    if payment.get("order_id"):
        order = get_order_by_id(payment["user_id"], payment["order_id"])
        if order:
            order["status"] = "Оплачен"
    
    # Отправляем сообщение об успешной оплате
    bot.send_message(
        chat_id,
        "✅ *Платеж успешно выполнен!*\n\nСпасибо за покупку!",
        parse_mode="Markdown"
    )
    
    # Если это платеж за заказ, отправляем ключи активации
    if payment.get("order_id"):
        order = get_order_by_id(payment["user_id"], payment["order_id"])
        if order:
            keys_text = "🔑 *Ключи активации для ваших игр:*\n\n"
            
            for game_id in order["games"]:
                game = next((g for g in games if g["id"] == game_id), None)
                if game:
                    game_title = escape_markdown(game['title'])
                    # Генерируем случайный ключ активации
                    activation_key = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))
                    keys_text += f"🎮 {game_title}: `{activation_key}`\n"
            
            bot.send_message(
                chat_id,
                keys_text,
                parse_mode="Markdown"
            )

# Функция для отображения формы оплаты
def show_payment_form(chat_id, user_id, order_id, amount, payment_method):
    # Получаем информацию о методе оплаты
    method_info = payment_methods.get(payment_method)
    if not method_info:
        bot.send_message(
            chat_id,
            "❌ Выбранный метод оплаты недоступен.",
            parse_mode="Markdown"
        )
        return
    
    # Вычисляем комиссию
    commission = amount * (method_info["commission"] / 100)
    total_amount = amount + commission
    
    # Создаем платеж
    payment = create_payment(user_id, order_id, total_amount, payment_method)
    
    # Формируем текст с информацией о платеже
    payment_text = f"💳 *Оплата заказа #{order_id}*\n\n"
    payment_text += f"💰 Сумма заказа: {amount} ₽\n"
    
    if commission > 0:
        payment_text += f"📊 Комиссия ({method_info['commission']}%): {commission} ₽\n"
    
    payment_text += f"💰 Итого к оплате: {total_amount} ₽\n\n"
    payment_text += f"💳 Способ оплаты: {method_info['name']}\n"
    payment_text += f"📝 Описание: {method_info['description']}\n\n"
    
    # Добавляем инструкции по оплате в зависимости от метода
    if payment_method == "card":
        payment_text += "Для оплаты банковской картой нажмите кнопку 'Оплатить' ниже.\n"
    elif payment_method == "qiwi":
        payment_text += "Для оплаты через QIWI переведите указанную сумму на кошелек +79123456789 с комментарием 'Оплата заказа " + order_id + "'.\n"
    elif payment_method == "yoomoney":
        payment_text += "Для оплаты через ЮMoney переведите указанную сумму на счет 4100123456789 с комментарием 'Оплата заказа " + order_id + "'.\n"
    elif payment_method == "webmoney":
        payment_text += "Для оплаты через WebMoney переведите указанную сумму на кошелек Z123456789012 с комментарием 'Оплата заказа " + order_id + "'.\n"
    elif payment_method == "crypto":
        payment_text += "Для оплаты криптовалютой переведите эквивалент указанной суммы на адрес:\nBTC: 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa\nETH: 0x742d35Cc6634C0532925a3b844Bc454e4438f44e\n"
    elif payment_method == "sberbank":
        payment_text += "Для оплаты через СберБанк Онлайн переведите указанную сумму на карту 1234 5678 9012 3456 с комментарием 'Оплата заказа " + order_id + "'.\n"
    
    # Формируем клавиатуру для оплаты
    markup = types.InlineKeyboardMarkup(row_width=1)
    pay_btn = types.InlineKeyboardButton("💰 Оплатить", callback_data=f"pay_{payment['id']}")
    cancel_btn = types.InlineKeyboardButton("❌ Отменить платеж", callback_data=f"cancel_payment_{payment['id']}")
    back_btn = types.InlineKeyboardButton("⬅️ Назад к выбору способа оплаты", callback_data=f"back_to_payment_methods_{order_id}")
    markup.add(pay_btn, cancel_btn, back_btn)
    
    bot.send_message(
        chat_id,
        payment_text,
        parse_mode="Markdown",
        reply_markup=markup
    )

# Обработчик команды /start
@bot.message_handler(commands=['start'])
def start_handler(message):
    user_first_name = message.from_user.first_name
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    # Инициализируем настройки пользователя, если их еще нет
    get_user_settings(user_id)
    
    # Обновляем статистику
    store_stats["total_users"] += 1
    
    # Отправляем логотип магазина
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists("logo.jpg"):
            send_image_from_folder(
                message.chat.id,
                "logo.jpg",
                caption=f"🐺 *Добро пожаловать в VolkStore, {user_first_name}!*",
                parse_mode="Markdown"
            )
        else:
            # Если изображение не найдено, отправляем только текст
            bot.send_message(
                message.chat.id,
                f"🐺 *Добро пожаловать в VolkStore, {user_first_name}!*",
                parse_mode="Markdown"
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        # Если не удалось отправить изображение, отправляем только текст
        bot.send_message(
            message.chat.id,
            f"🐺 *Добро пожаловать в VolkStore, {user_first_name}!*",
            parse_mode="Markdown"
        )
    
    welcome_text = (
        f"🎮 Мы предлагаем широкий выбор игр для различных платформ.\n"
        f"🛒 Просматривайте наш каталог, добавляйте игры в корзину и наслаждайтесь игровым процессом!\n\n"
        f"Используйте меню ниже для навигации:"
    )
    
    bot.send_message(message.chat.id, welcome_text, parse_mode="Markdown", reply_markup=get_main_keyboard())
    
    # Проверяем, указан ли email
    settings = get_user_settings(user_id)
    if not settings["email"]:
        bot.send_message(
            message.chat.id,
            "⚠️ *Важно:* Для оформления заказов необходимо указать email в настройках профиля.\n\n"
            "Пожалуйста, перейдите в ⚙️ Настройки и укажите ваш email.",
            parse_mode="Markdown"
        )

# Обработчик команды /admin
@bot.message_handler(commands=['admin'])
def admin_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, является ли пользователь администратором
    if is_admin(user_id):
        # Если пользователь уже авторизован как админ
        if user_id in admin_state and admin_state[user_id].get("authorized"):
            bot.send_message(
                message.chat.id,
                "👑 *Админ-панель*\n\nВыберите действие:",
                parse_mode="Markdown",
                reply_markup=get_admin_keyboard()
            )
        else:
            # Запрашиваем пароль
            bot.send_message(
                message.chat.id,
                "🔐 *Вход в админ-панель*\n\nВведите пароль:",
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(message, check_admin_password)
    else:
        bot.send_message(
            message.chat.id,
            "❌ У вас нет доступа к админ-панели.",
            parse_mode="Markdown"
        )

# Проверка пароля администратора
def check_admin_password(message):
    user_id = message.from_user.id
    password = message.text.strip()
    
    # Удаляем сообщение с паролем для безопасности
    bot.delete_message(message.chat.id, message.message_id)
    
    if password == ADMIN_PASSWORD and is_admin(user_id):
        # Авторизуем пользователя как администратора
        if user_id not in admin_state:
            admin_state[user_id] = {}
        admin_state[user_id]["authorized"] = True
        
        bot.send_message(
            message.chat.id,
            "✅ *Авторизация успешна!*\n\nДобро пожаловать в админ-панель.",
            parse_mode="Markdown",
            reply_markup=get_admin_keyboard()
        )
    else:
        bot.send_message(
            message.chat.id,
            "❌ Неверный пароль или у вас нет доступа к админ-панели.",
            parse_mode="Markdown"
        )

# Обработчик кнопки "Каталог игр"
@bot.message_handler(func=lambda message: message.text == "🎮 Каталог игр")
def catalog_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists("catalog.jpg"):
            send_image_from_folder(
                message.chat.id,
                "catalog.jpg",
                caption="🎮 *Каталог игр*\n\nВыберите категорию:",
                parse_mode="Markdown",
                reply_markup=get_catalog_keyboard()
            )
        else:
            # Если изображение не найдено, отправляем сообщение без изображения
            bot.send_message(
                message.chat.id,
                "🎮 *Каталог игр*\n\nВыберите категорию:",
                parse_mode="Markdown",
                reply_markup=get_catalog_keyboard()
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        bot.send_message(
            message.chat.id,
            "🎮 *Каталог игр*\n\nВыберите категорию:",
            parse_mode="Markdown",
            reply_markup=get_catalog_keyboard()
        )

# Обработчик кнопки "Настройки"
@bot.message_handler(func=lambda message: message.text == "⚙️ Настройки")
def settings_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    settings = get_user_settings(user_id)
    
    settings_text = (
        f"⚙️ *Настройки*\n\n"
        f"👤 Имя: {settings['name'] or 'Не указано'}\n"
        f"✉️ Email: {settings['email'] or 'Не указан'}\n"
        f"💰 Валюта: {currencies[settings['currency']]['name']}\n"
        f"🔔 Уведомления: {'Включены' if settings['notifications'] else 'Отключены'}\n"
        f"🌐 Язык: {languages[settings['language']]}\n"
        f"🎭 Предпочитаемые жанры: {', '.join(settings['preferred_genres']) or 'Не указаны'}\n"
        f"💻 Предпочитаемые платформы: {', '.join(settings['preferred_platforms']) or 'Не указаны'}"
    )
    
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists("settings.jpg"):
            send_image_from_folder(
                message.chat.id,
                "settings.jpg",
                caption=settings_text,
                parse_mode="Markdown",
                reply_markup=get_settings_keyboard()
            )
        else:
            # Если изображение не найдено, отправляем сообщение без изображения
            bot.send_message(
                message.chat.id,
                settings_text,
                parse_mode="Markdown",
                reply_markup=get_settings_keyboard()
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        bot.send_message(
            message.chat.id,
            settings_text,
            parse_mode="Markdown",
            reply_markup=get_settings_keyboard()
        )

# Обработчик кнопки "Моя корзина"
@bot.message_handler(func=lambda message: message.text == "🛒 Моя корзина")
def cart_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    # Проверяем, есть ли у пользователя корзина
    if user_id not in user_carts or not user_carts[user_id]:
        bot.send_message(
            message.chat.id,
            "🛒 *Ваша корзина пуста*\n\nДобавьте игры из каталога, чтобы оформить заказ.",
            parse_mode="Markdown",
            reply_markup=get_main_keyboard()
        )
        return
    
    # Формируем текст корзины
    cart_text = "🛒 *Ваша корзина:*\n\n"
    
    total_price = 0
    for game_id in user_carts[user_id]:
        game = next((g for g in games if g["id"] == game_id), None)
        if game:
            price = game["price"]
            total_price += price
            game_title = escape_markdown(game['title'])
            cart_text += f"🎮 *{game_title}*\n💰 Цена: {convert_price(price, user_id)}\n\n"
    
    # Проверяем, применен ли промокод
    discount = 0
    if user_id in user_applied_promocodes:
        promo_code = user_applied_promocodes[user_id]
        promo = promocodes.get(promo_code)
        if promo:
            if promo["type"] == "percent":
                discount = total_price * (promo["value"] / 100)
                cart_text += f"🎁 Промокод: *{promo_code}* (скидка {promo['value']}%)\n"
            elif promo["type"] == "fixed":
                discount = promo["value"]
                cart_text += f"🎁 Промокод: *{promo_code}* (скидка {convert_price(promo['value'], user_id)})\n"
            elif promo["type"] == "free_game":
                free_game = next((g for g in games if g["id"] == promo["game_id"]), None)
                if free_game:
                    free_game_title = escape_markdown(free_game['title'])
                    cart_text += f"🎁 Промокод: *{promo_code}* (бесплатная игра: {free_game_title})\n"
            elif promo["type"] == "first_order":
                if user_id not in user_orders or not user_orders[user_id]:
                    discount = total_price * (promo["value"] / 100)
                    cart_text += f"🎁 Промокод: *{promo_code}* (скидка {promo['value']}% на первый заказ)\n"
    
    # Проверяем, есть ли временная скидка от волка
    if user_id in user_wolf_discounts and user_wolf_discounts[user_id]["expires"] > datetime.now():
        wolf_discount = user_wolf_discounts[user_id]["value"]
        wolf_discount_amount = total_price * (wolf_discount / 100)
        discount += wolf_discount_amount
        cart_text += f"🐺 Скидка от Волка: *{wolf_discount}%*\n"
    
    # Итоговая сумма с учетом скидок
    total_with_discount = total_price - discount
    
    cart_text += f"\n💰 Итого: {convert_price(total_with_discount, user_id)}"
    
    # Формируем клавиатуру для корзины
    markup = types.InlineKeyboardMarkup(row_width=1)
    checkout_btn = types.InlineKeyboardButton("💳 Оформить заказ", callback_data="checkout")
    
    # Кнопка для применения промокода
    if user_id in user_applied_promocodes:
        promo_btn = types.InlineKeyboardButton("🎁 Изменить промокод", callback_data="change_promo")
    else:
        promo_btn = types.InlineKeyboardButton("🎁 Применить промокод", callback_data="apply_promo")
    
    clear_btn = types.InlineKeyboardButton("🗑️ Очистить корзину", callback_data="clear_cart")
    back_btn = types.InlineKeyboardButton("⬅️ Назад в меню", callback_data="back_to_menu")
    
    markup.add(checkout_btn, promo_btn, clear_btn, back_btn)
    
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists("cart.jpg"):
            send_image_from_folder(
                message.chat.id,
                "cart.jpg",
                caption=cart_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            # Если изображение не найдено, отправляем сообщение без изображения
            bot.send_message(
                message.chat.id,
                cart_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        bot.send_message(
            message.chat.id,
            cart_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик кнопки "Поиск игр"
@bot.message_handler(func=lambda message: message.text == "🔍 Поиск игр")
def search_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists("search.jpg"):
            send_image_from_folder(
                message.chat.id,
                "search.jpg",
                caption="🔍 *Поиск игр*\n\nВыберите тип поиска:",
                parse_mode="Markdown",
                reply_markup=get_search_type_keyboard()
            )
        else:
            # Если изображение не найдено, отправляем сообщение без изображения
            bot.send_message(
                message.chat.id,
                "🔍 *Поиск игр*\n\nВыберите тип поиска:",
                parse_mode="Markdown",
                reply_markup=get_search_type_keyboard()
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        bot.send_message(
            message.chat.id,
            "🔍 *Поиск игр*\n\nВыберите тип поиска:",
            parse_mode="Markdown",
            reply_markup=get_search_type_keyboard()
        )

# Обработчик кнопки "Избранное"
@bot.message_handler(func=lambda message: message.text == "⭐ Избранное")
def favorites_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    # Проверяем, есть ли у пользователя избранные игры
    if user_id not in user_favorites or not user_favorites[user_id]:
        bot.send_message(
            message.chat.id,
            "⭐ *Ваш список избранного пуст*\n\nДобавьте игры в избранное из каталога.",
            parse_mode="Markdown",
            reply_markup=get_main_keyboard()
        )
        return
    
    # Показываем первую страницу избранных игр
    show_favorites_page(message.chat.id, user_id, 1)

# Обработчик кнопки "Мои заказы"
@bot.message_handler(func=lambda message: message.text == "📋 Мои заказы")
def orders_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    # Проверяем, есть ли у пользователя заказы
    if user_id not in user_orders or not user_orders[user_id]:
        bot.send_message(
            message.chat.id,
            "📋 *У вас пока нет заказов*\n\nОформите заказ в корзине, чтобы увидеть его здесь.",
            parse_mode="Markdown",
            reply_markup=get_main_keyboard()
        )
        return
    
    # Показываем первую страницу заказов
    show_orders_page(message.chat.id, user_id, 1)

# Обработчик кнопки "Поддержка"
@bot.message_handler(func=lambda message: message.text == "📞 Поддержка")
def support_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    support_text = (
        "📞 *Поддержка*\n\n"
        "Если у вас возникли вопросы или проблемы, вы можете связаться с нами:\n\n"
        "✉️ Email: support@volkstore.ru\n"
        "📱 Telegram: @volkstore\\_support\n"
        "🌐 Сайт: volkstore.ru/support\n\n"
        "Время работы поддержки: ежедневно с 9:00 до 21:00 (МСК)"
    )
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    write_btn = types.InlineKeyboardButton("✍️ Написать сообщение", url="https://t.me/volkstore_support")
    faq_btn = types.InlineKeyboardButton("❓ Часто задаваемые вопросы", url="https://volkstore.ru/faq")
    back_btn = types.InlineKeyboardButton("⬅️ Назад в меню", callback_data="back_to_menu")
    markup.add(write_btn, faq_btn, back_btn)
    
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists("support.jpg"):
            send_image_from_folder(
                message.chat.id,
                "support.jpg",
                caption=support_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            # Если изображение не найдено, отправляем сообщение без изображения
            bot.send_message(
                message.chat.id,
                support_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        bot.send_message(
            message.chat.id,
            support_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик кнопки "Промокоды"
@bot.message_handler(func=lambda message: message.text == "🎁 Промокоды")
def promocodes_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    promo_text = (
        "🎁 *Промокоды*\n\n"
        "Используйте промокоды при оформлении заказа, чтобы получить скидки и бонусы!\n\n"
        "Активные промокоды:\n"
        "- 4hg6sk: Скидка 10% на всю корзину (мин. заказ 1000₽)\n"
        "- WELCOME: Скидка 15% на первый заказ\n"
        "- STEAM10: Дополнительные 10% при пополнении Steam (мин. сумма 1000₽)\n\n"
        "Чтобы применить промокод, добавьте товары в корзину и нажмите кнопку 'Применить промокод'."
    )
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    cart_btn = types.InlineKeyboardButton("🛒 Перейти в корзину", callback_data="go_to_cart")
    back_btn = types.InlineKeyboardButton("⬅️ Назад в меню", callback_data="back_to_menu")
    markup.add(cart_btn, back_btn)
    
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists("promocodes.jpg"):
            send_image_from_folder(
                message.chat.id,
                "promocodes.jpg",
                caption=promo_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            # Если изображение не найдено, отправляем сообщение без изображения
            bot.send_message(
                message.chat.id,
                promo_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        bot.send_message(
            message.chat.id,
            promo_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик кнопки "Донат"
@bot.message_handler(func=lambda message: message.text == "💲 Донат")
def donate_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    donate_text = (
        "💲 *Поддержка проекта*\n\n"
        "Если вам нравится наш сервис, вы можете поддержать его развитие.\n\n"
        "Ваша поддержка поможет нам:\n"
        "- Добавлять больше игр в каталог\n"
        "- Улучшать функциональность бота\n"
        "- Проводить больше акций и раздавать промокоды\n\n"
        "Спасибо за вашу поддержку! ❤️"
    )
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    donate_btn = types.InlineKeyboardButton("💰 Поддержать проект", url="https://volkstore.ru/donate")
    back_btn = types.InlineKeyboardButton("⬅️ Назад в меню", callback_data="back_to_menu")
    markup.add(donate_btn, back_btn)
    
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists("donate.jpg"):
            send_image_from_folder(
                message.chat.id,
                "donate.jpg",
                caption=donate_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            # Если изображение не найдено, отправляем сообщение без изображения
            bot.send_message(
                message.chat.id,
                donate_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        bot.send_message(
            message.chat.id,
            donate_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик кнопки пополнения Steam
@bot.message_handler(func=lambda message: message.text == "🎮 Пополнить Steam")
def steam_topup_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    # Отправляем изображение Steam
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists("steam_logo.jpg"):
            send_image_from_folder(
                message.chat.id,
                "steam_logo.jpg",
                caption="🎮 *Пополнение кошелька Steam*\n\n"
                       "Выберите сумму пополнения или введите свою.\n\n"
                       "⚠️ *Внимание:* При пополнении взимается комиссия 10%.",
                parse_mode="Markdown",
                reply_markup=get_steam_topup_keyboard()
            )
        else:
            # Если изображение не найдено, отправляем сообщение без изображения
            bot.send_message(
                message.chat.id,
                "🎮 *Пополнение кошелька Steam*\n\n"
                "Выберите сумму пополнения или введите свою.\n\n"
                "⚠️ *Внимание:* При пополнении взимается комиссия 10%.",
                parse_mode="Markdown",
                reply_markup=get_steam_topup_keyboard()
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        bot.send_message(
            message.chat.id,
            "🎮 *Пополнение кошелька Steam*\n\n"
            "Выберите сумму пополнения или введите свою.\n\n"
            "⚠️ *Внимание:* При пополнении взимается комиссия 10%.",
            parse_mode="Markdown",
            reply_markup=get_steam_topup_keyboard()
        )

# Обработчики кнопок админ-панели
@bot.message_handler(func=lambda message: message.text == "🎮 Управление играми" and message.from_user.id in admin_state and admin_state[message.from_user.id].get("authorized"))
def admin_games_handler(message):
    bot.send_message(
        message.chat.id,
        "🎮 *Управление играми*\n\nВыберите действие:",
        parse_mode="Markdown",
        reply_markup=get_admin_games_keyboard()
    )

@bot.message_handler(func=lambda message: message.text == "👥 Управление пользователями" and message.from_user.id in admin_state and admin_state[message.from_user.id].get("authorized"))
def admin_users_handler(message):
    bot.send_message(
        message.chat.id,
        "👥 *Управление пользователями*\n\nВыберите действие:",
        parse_mode="Markdown",
        reply_markup=get_admin_users_keyboard()
    )

@bot.message_handler(func=lambda message: message.text == "📊 Статистика" and message.from_user.id in admin_state and admin_state[message.from_user.id].get("authorized"))
def admin_stats_handler(message):
    stats_text = (
        "📊 *Статистика магазина*\n\n"
        f"💰 Общая сумма продаж: {store_stats['total_sales']} ₽\n"
        f"📦 Количество заказов: {store_stats['total_orders']}\n"
        f"👥 Количество пользователей: {store_stats['total_users']}\n\n"
        f"Выберите категорию для подробной статистики:"
    )
    
    bot.send_message(
        message.chat.id,
        stats_text,
        parse_mode="Markdown",
        reply_markup=get_admin_stats_keyboard()
    )

@bot.message_handler(func=lambda message: message.text == "🎁 Управление промокодами" and message.from_user.id in admin_state and admin_state[message.from_user.id].get("authorized"))
def admin_promo_handler(message):
    bot.send_message(
        message.chat.id,
        "🎁 *Управление промокодами*\n\nВыберите действие:",
        parse_mode="Markdown",
        reply_markup=get_admin_promo_keyboard()
    )

@bot.message_handler(func=lambda message: message.text == "📢 Рассылка" and message.from_user.id in admin_state and admin_state[message.from_user.id].get("authorized"))
def admin_notify_handler(message):
    bot.send_message(
        message.chat.id,
        "📢 *Рассылка сообщений*\n\nВыберите тип рассылки:",
        parse_mode="Markdown",
        reply_markup=get_admin_notify_keyboard()
    )

@bot.message_handler(func=lambda message: message.text == "📋 Заказы" and message.from_user.id in admin_state and admin_state[message.from_user.id].get("authorized"))
def admin_orders_handler(message):
    # Собираем все заказы из всех пользователей
    all_orders = []
    for user_id, orders in user_orders.items():
        for order in orders:
            order_copy = order.copy()
            order_copy["user_id"] = user_id
            all_orders.append(order_copy)
    
    # Сортируем заказы по дате (от новых к старым)
    all_orders.sort(key=lambda x: x["date"], reverse=True)
    
    if not all_orders:
        bot.send_message(
            message.chat.id,
            "📋 *Заказы*\n\nНет заказов для отображения.",
            parse_mode="Markdown"
        )
        return
    
    # Отображаем последние 10 заказов
    orders_text = "📋 *Последние заказы:*\n\n"
    
    for order in all_orders[:10]:
        user_id = order["user_id"]
        settings = get_user_settings(user_id)
        user_name = settings.get("name") or f"Пользователь {user_id}"
        
        orders_text += f"🆔 Заказ #{order['id']}\n"
        orders_text += f"👤 Пользователь: {user_name}\n"
        orders_text += f"📅 Дата: {order['date']}\n"
        orders_text += f"💰 Сумма: {order['total']} ₽\n"
        orders_text += f"✅ Статус: {order['status']}\n\n"
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    markup.add(back_btn)
    
    bot.send_message(
        message.chat.id,
        orders_text,
        parse_mode="Markdown",
        reply_markup=markup
    )

@bot.message_handler(func=lambda message: message.text == "💰 Платежи" and message.from_user.id in admin_state and admin_state[message.from_user.id].get("authorized"))
def admin_payments_handler(message):
    # Собираем все платежи из всех пользователей
    all_payments = []
    for user_id, payments in user_payments.items():
        for payment in payments:
            payment_copy = payment.copy()
            all_payments.append(payment_copy)
    
    # Сортируем платежи по дате (от новых к старым)
    all_payments.sort(key=lambda x: x["created_at"], reverse=True)
    
    if not all_payments:
        bot.send_message(
            message.chat.id,
            "💰 *Платежи*\n\nНет платежей для отображения.",
            parse_mode="Markdown"
        )
        return
    
    # Отображаем последние 10 платежей
    payments_text = "💰 *Последние платежи:*\n\n"
    
    for payment in all_payments[:10]:
        user_id = payment["user_id"]
        settings = get_user_settings(user_id)
        user_name = settings.get("name") or f"Пользователь {user_id}"
        
        payments_text += f"🆔 ID платежа: {payment['id']}\n"
        payments_text += f"👤 Пользователь: {user_name}\n"
        payments_text += f"📅 Дата: {payment['created_at']}\n"
        payments_text += f"💰 Сумма: {payment['amount']} ₽\n"
        payments_text += f"💳 Способ оплаты: {payment_methods[payment['method']]['name']}\n"
        payments_text += f"✅ Статус: {payment['status']}\n\n"
    
    markup = types.InlineKeyboardMarkup(row_width=1)
    back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_main")
    markup.add(back_btn)
    
    bot.send_message(
        message.chat.id,
        payments_text,
        parse_mode="Markdown",
        reply_markup=markup
    )

@bot.message_handler(func=lambda message: message.text == "🚪 Выход из админ-панели" and message.from_user.id in admin_state and admin_state[message.from_user.id].get("authorized"))
def admin_exit_handler(message):
    user_id = message.from_user.id
    
    # Удаляем авторизацию администратора
    if user_id in admin_state:
        admin_state[user_id]["authorized"] = False
    
    bot.send_message(
        message.chat.id,
        "✅ Вы вышли из админ-панели.",
        parse_mode="Markdown",
        reply_markup=get_main_keyboard()
    )

# Обработчик ввода произвольной суммы для пополнения Steam
def process_custom_steam_amount(message):
    user_id = message.from_user.id
    
    try:
        amount = int(message.text.strip())
        
        if amount < 50:
            bot.send_message(
                message.chat.id,
                "❌ Минимальная сумма пополнения - 50 ₽. Пожалуйста, введите сумму больше или равную 50 ₽:",
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(message, process_custom_steam_amount)
            return
        
        if amount > 15000:
            bot.send_message(
                message.chat.id,
                "❌ Максимальная сумма пополнения - 15000 ₽. Пожалуйста, введите сумму меньше или равную 15000 ₽:",
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(message, process_custom_steam_amount)
            return
        
        # Запрашиваем логин Steam
        bot.send_message(
            message.chat.id,
            "👤 Введите ваш логин Steam:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_steam_login, amount)
        
    except ValueError:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите корректную сумму (только цифры):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_custom_steam_amount)

# Обработчик ввода логина Steam
def process_steam_login(message, amount):
    user_id = message.from_user.id
    steam_login = message.text.strip()
    
    # Проверяем валидность логина
    if not is_valid_steam_login(steam_login):
        bot.send_message(
            message.chat.id,
            "❌ Некорректный логин Steam. Логин должен содержать не менее 3 символов и состоять из букв, цифр и символов '_', '-', '.'\n\nПожалуйста, введите корректный логин:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_steam_login, amount)
        return
    
    # Сохраняем логин Steam
    user_steam_logins[user_id] = steam_login
    
    # Показываем подтверждение с учетом комиссии
    show_steam_confirmation(message.chat.id, amount)

# Обработчик поиска по имени
def search_by_name_handler(message):
    bot.send_message(
        message.chat.id,
        "🔤 *Поиск игр по названию*\n\nВведите название игры (или часть названия):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_name_search)

# Обработчик ввода названия для поиска
def process_name_search(message):
    user_id = message.from_user.id
    search_query = message.text.strip().lower()
    
    if not search_query:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите название игры для поиска.",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_name_search)
        return
    
    # Ищем игры по названию
    found_games = [
        game for game in games
        if search_query in game["title"].lower()
    ]
    
    if not found_games:
        bot.send_message(
            message.chat.id,
            "❌ Игры с таким названием не найдены.",
            parse_mode="Markdown"
        )
        return
    
    # Показываем результаты поиска
    show_search_results(message.chat.id, found_games, "name", user_id)

# Обработчик поиска по цене
def search_by_price_handler(message):
    bot.send_message(
        message.chat.id,
        "💰 *Поиск игр по цене*\n\nВведите минимальную цену (в вашей текущей валюте):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_min_price_step)

# Обработчик ввода минимальной цены
def process_min_price_step(message):
    user_id = message.from_user.id
    
    try:
        min_price_text = message.text.strip().replace(',', '.')
        min_price = float(min_price_text)
        
        # Сохраняем минимальную цену
        user_price_search_state[user_id] = {"min_price": min_price}
        
        # Запрашиваем максимальную цену
        bot.send_message(
            message.chat.id,
            "💰 Теперь введите максимальную цену (в вашей текущей валюте):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_max_price_step)
        
    except ValueError:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите корректную цену (только цифры):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_min_price_step)

# Обработчик ввода максимальной цены
def process_max_price_step(message):
    user_id = message.from_user.id
    
    try:
        max_price_text = message.text.strip().replace(',', '.')
        max_price = float(max_price_text)
        
        # Получаем минимальную цену
        min_price = user_price_search_state[user_id]["min_price"]
        
        # Конвертируем цены в рубли для поиска
        min_price_rub = convert_to_rub(min_price, user_id)
        max_price_rub = convert_to_rub(max_price, user_id)
        
        # Ищем игры в заданном диапазоне цен
        found_games = [
            game for game in games
            if min_price_rub <= game["price"] <= max_price_rub
        ]
        
        if not found_games:
            bot.send_message(
                message.chat.id,
                "❌ Игры в заданном диапазоне цен не найдены.",
                parse_mode="Markdown"
            )
            return
        
        # Показываем результаты поиска
        show_search_results(message.chat.id, found_games, "price", user_id)
        
        # Очищаем состояние поиска
        del user_price_search_state[user_id]
        
    except ValueError:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите корректную цену (только цифры):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_max_price_step)

# Обработчик поиска по жанру
def search_by_genre_handler(message):
    bot.send_message(
        message.chat.id,
        "🎭 *Поиск игр по жанру*\n\nВыберите жанр:",
        parse_mode="Markdown",
        reply_markup=get_genre_search_keyboard()
    )

# Обработчик поиска по платформе
def search_by_platform_handler(message):
    bot.send_message(
        message.chat.id,
        "💻 *Поиск игр по платформе*\n\nВыберите платформу:",
        parse_mode="Markdown",
        reply_markup=get_platform_search_keyboard()
    )

# Обработчик ввода имени
def process_name_step(message):
    user_id = message.from_user.id
    name = message.text.strip()
    user_settings[user_id]["name"] = name
    bot.send_message(message.chat.id, f"✅ Имя изменено на {name}.", reply_markup=get_main_keyboard())

# Обработчик ввода email
def process_email_step(message):
    user_id = message.from_user.id
    email = message.text.strip()
    user_settings[user_id]["email"] = email
    bot.send_message(message.chat.id, f"✅ Email изменен на {email}.", reply_markup=get_main_keyboard())

# Обработчик ввода промокода
def process_promo_code(message):
    user_id = message.from_user.id
    promo_code = message.text.strip().upper()
    
    # Проверяем, существует ли промокод
    if promo_code in promocodes:
        promo = promocodes[promo_code]
        
        # Проверяем, не истек ли срок действия промокода
        if datetime.now() > promo["expires"]:
            bot.send_message(
                message.chat.id,
                "❌ Срок действия промокода истек.",
                parse_mode="Markdown"
            )
            return
        
        # Проверяем, не использовал ли пользователь этот промокод ранее
        if user_id in promo["used_by"] and promo["type"] != "first_order":
            bot.send_message(
                message.chat.id,
                "❌ Вы уже использовали этот промокод.",
                parse_mode="Markdown"
            )
            return
        
        # Проверяем, есть ли у пользователя корзина
        if user_id not in user_carts or not user_carts[user_id]:
            bot.send_message(
                message.chat.id,
                "❌ Ваша корзина пуста. Добавьте игры в корзину, чтобы применить промокод.",
                parse_mode="Markdown"
            )
            return
        
        # Вычисляем общую стоимость корзины
        total_price = sum(game["price"] for game in games if game["id"] in user_carts[user_id])
        
        # Проверяем минимальную сумму заказа
        if total_price < promo["min_order"]:
            bot.send_message(
                message.chat.id,
                f"❌ Минимальная сумма заказа для этого промокода: {promo['min_order']} ₽.",
                parse_mode="Markdown"
            )
            return
        
        # Применяем промокод
        user_applied_promocodes[user_id] = promo_code
        
        bot.send_message(
            message.chat.id,
            f"✅ Промокод {promo_code} успешно применен!",
            parse_mode="Markdown"
        )
        
        # Показываем обновленную корзину
        cart_handler(message)
    else:
        bot.send_message(
            message.chat.id,
            "❌ Промокод не найден. Пожалуйста, проверьте правильность ввода.",
            parse_mode="Markdown"
        )

# Обработчик добавления игры (админ)
def process_add_game_name(message):
    user_id = message.from_user.id
    
    # Сохраняем название игры
    admin_state[user_id]["game_name"] = message.text.strip()
    
    # Запрашиваем описание
    bot.send_message(
        message.chat.id,
        "📝 Введите описание игры:",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_add_game_description)

# Обработчик добавления описания игры
def process_add_game_description(message):
    user_id = message.from_user.id
    
    # Сохраняем описание игры
    admin_state[user_id]["game_description"] = message.text.strip()
    
    # Запрашиваем цену
    bot.send_message(
        message.chat.id,
        "💰 Введите цену игры (только цифры):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_add_game_price)

# Обработчик добавления цены игры
def process_add_game_price(message):
    user_id = message.from_user.id
    
    try:
        price = int(message.text.strip())
        
        # Сохраняем цену игры
        admin_state[user_id]["game_price"] = price
        
        # Запрашиваем жанр
        bot.send_message(
            message.chat.id,
            "🎭 Введите жанр игры:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_add_game_genre)
    except ValueError:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите корректную цену (только цифры):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_add_game_price)

# Обработчик добавления жанра игры
def process_add_game_genre(message):
    user_id = message.from_user.id
    
    # Сохраняем жанр игры
    admin_state[user_id]["game_genre"] = message.text.strip()
    
    # Запрашиваем платформы
    bot.send_message(
        message.chat.id,
        "💻 Введите платформы игры через запятую (например: PC, PlayStation, Xbox):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_add_game_platforms)

# Обработчик добавления платформ игры
def process_add_game_platforms(message):
    user_id = message.from_user.id
    
    # Сохраняем платформы игры
    platforms = [platform.strip() for platform in message.text.split(",")]
    admin_state[user_id]["game_platforms"] = platforms
    
    # Запрашиваем ссылку на изображение
    bot.send_message(
        message.chat.id,
        "🖼️ Введите имя файла изображения игры (например: game.jpg):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_add_game_image)

# Обработчик добавления изображения игры
def process_add_game_image(message):
    user_id = message.from_user.id
    
    # Сохраняем имя файла изображения
    admin_state[user_id]["game_image"] = message.text.strip()
    
    # Создаем новую игру
    new_game = {
        "id": max(game["id"] for game in games) + 1,
        "title": admin_state[user_id]["game_name"],
        "description": admin_state[user_id]["game_description"],
        "price": admin_state[user_id]["game_price"],
        "old_price": None,
        "discount": None,
        "image": admin_state[user_id]["game_image"],
        "genre": admin_state[user_id]["game_genre"],
        "platform": ["Steam"],  # Теперь только Steam
        "rating": 0.0,
        "reviews": []
    }
    
    # Добавляем игру в список
    games.append(new_game)
    
    # Обновляем список жанров
    if new_game["genre"] not in all_genres:
        all_genres.add(new_game["genre"])
        genres_list = sorted(list(all_genres))
    
    # Отправляем сообщение об успешном добавлении
    bot.send_message(
        message.chat.id,
        f"✅ Игра *{new_game['title']}* успешно добавлена!\n\n"
        f"🆔 ID: {new_game['id']}\n"
        f"💰 Цена: {new_game['price']} ₽\n"
        f"🎭 Жанр: {new_game['genre']}\n"
        f"💻 Платформа: Steam",
        parse_mode="Markdown"
    )
    
    # Очищаем состояние
    del admin_state[user_id]
    
    # Возвращаемся в меню управления играми
    bot.send_message(
        message.chat.id,
        "Выберите действие:",
        reply_markup=get_admin_games_keyboard()
    )

# Функция для показа подтверждения пополнения Steam
def show_steam_confirmation(chat_id, amount):
    # Вычисляем комиссию
    commission = amount * 0.1  # 10% комиссия
    total_amount = amount + commission
    
    confirmation_text = (
        f"🎮 *Пополнение кошелька Steam*\n\n"
        f"💰 Сумма пополнения: {amount} ₽\n"
        f"📊 Комиссия (10%): {commission} ₽\n"
        f"💰 Итого к оплате: {total_amount} ₽\n\n"
        f"Подтвердите пополнение:"
    )
    
    bot.send_message(
        chat_id,
        confirmation_text,
        parse_mode="Markdown",
        reply_markup=get_steam_confirm_keyboard(amount)
    )

# Добавляем новые переменные для хранения данных
user_achievements = {}  # Достижения пользователей
user_levels = {}  # Уровни пользователей
user_daily_bonuses = {}  # Ежедневные бонусы
user_last_activity = {}  # Последняя активность пользователей
user_recommendations = {}  # Рекомендации игр

# Доступные языки (расширенный список)
languages = {
    "ru": "Русский",
    "en": "English",
    "de": "Deutsch",
    "fr": "Français",
    "es": "Español",
    "it": "Italiano",
    "zh": "中文",
    "ja": "日本語"
}

# Локализация текстов
localization = {
    "ru": {
        "welcome": "🐺 *Добро пожаловать в VolkStore, {}!*",
        "catalog": "🎮 *Каталог игр*\n\nВыберите категорию:",
        "cart_empty": "🛒 *Ваша корзина пуста*\n\nДобавьте игры из каталога, чтобы оформить заказ.",
        "settings": "⚙️ *Настройки*",
        "search": "🔍 *Поиск игр*\n\nВыберите тип поиска:",
        "favorites_empty": "⭐ *Ваш список избранного пуст*\n\nДобавьте игры в избранное из каталога.",
        "orders_empty": "📋 *У вас пока нет заказов*\n\nОформите заказ в корзине, чтобы увидеть его здесь.",
        "support": "📞 *Поддержка*",
        "promocodes": "🎁 *Промокоды*",
        "donate": "💲 *Поддержка проекта*",
        "steam_topup": "🎮 *Пополнение кошелька Steam*",
        "achievements": "🏆 *Достижения*",
        "daily_bonus": "🎁 *Ежедневный бонус*",
        "level_up": "🎉 *Поздравляем! Вы достигли уровня {}!*",
        "recommendations": "🔍 *Рекомендуемые игры*"
    },
    "en": {
        "welcome": "🐺 *Welcome to VolkStore, {}!*",
        "catalog": "🎮 *Game Catalog*\n\nSelect a category:",
        "cart_empty": "🛒 *Your cart is empty*\n\nAdd games from the catalog to place an order.",
        "settings": "⚙️ *Settings*",
        "search": "🔍 *Search Games*\n\nSelect search type:",
        "favorites_empty": "⭐ *Your favorites list is empty*\n\nAdd games to favorites from the catalog.",
        "orders_empty": "📋 *You don't have any orders yet*\n\nPlace an order from your cart to see it here.",
        "support": "📞 *Support*",
        "promocodes": "🎁 *Promo Codes*",
        "donate": "💲 *Support the Project*",
        "steam_topup": "🎮 *Steam Wallet Top-up*",
        "achievements": "🏆 *Achievements*",
        "daily_bonus": "🎁 *Daily Bonus*",
        "level_up": "🎉 *Congratulations! You've reached level {}!*",
        "recommendations": "🔍 *Recommended Games*"
    },
    "de": {
        "welcome": "🐺 *Willkommen bei VolkStore, {}!*",
        "catalog": "🎮 *Spielkatalog*\n\nWählen Sie eine Kategorie:",
        "cart_empty": "🛒 *Ihr Warenkorb ist leer*\n\nFügen Sie Spiele aus dem Katalog hinzu, um eine Bestellung aufzugeben.",
        "settings": "⚙️ *Einstellungen*",
        "search": "🔍 *Spiele suchen*\n\nWählen Sie den Suchtyp:",
        "favorites_empty": "⭐ *Ihre Favoritenliste ist leer*\n\nFügen Sie Spiele aus dem Katalog zu Ihren Favoriten hinzu.",
        "orders_empty": "📋 *Sie haben noch keine Bestellungen*\n\nGeben Sie eine Bestellung aus Ihrem Warenkorb auf, um sie hier zu sehen.",
        "support": "📞 *Unterstützung*",
        "promocodes": "🎁 *Gutscheincodes*",
        "donate": "💲 *Projekt unterstützen*",
        "steam_topup": "🎮 *Steam-Guthaben aufladen*",
        "achievements": "🏆 *Erfolge*",
        "daily_bonus": "🎁 *Täglicher Bonus*",
        "level_up": "🎉 *Herzlichen Glückwunsch! Sie haben Level {} erreicht!*",
        "recommendations": "🔍 *Empfohlene Spiele*"
    },
    "fr": {
        "welcome": "🐺 *Bienvenue sur VolkStore, {}!*",
        "catalog": "🎮 *Catalogue de jeux*\n\nSélectionnez une catégorie:",
        "cart_empty": "🛒 *Votre panier est vide*\n\nAjoutez des jeux du catalogue pour passer une commande.",
        "settings": "⚙️ *Paramètres*",
        "search": "🔍 *Rechercher des jeux*\n\nSélectionnez le type de recherche:",
        "favorites_empty": "⭐ *Votre liste de favoris est vide*\n\nAjoutez des jeux aux favoris depuis le catalogue.",
        "orders_empty": "📋 *Vous n'avez pas encore de commandes*\n\nPassez une commande depuis votre panier pour la voir ici.",
        "support": "📞 *Support*",
        "promocodes": "🎁 *Codes promo*",
        "donate": "💲 *Soutenir le projet*",
        "steam_topup": "🎮 *Recharger le portefeuille Steam*",
        "achievements": "🏆 *Réalisations*",
        "daily_bonus": "🎁 *Bonus quotidien*",
        "level_up": "🎉 *Félicitations! Vous avez atteint le niveau {}!*",
        "recommendations": "🔍 *Jeux recommandés*"
    },
    "es": {
        "welcome": "🐺 *Bienvenido a VolkStore, {}!*",
        "catalog": "🎮 *Catálogo de juegos*\n\nSeleccione una categoría:",
        "cart_empty": "🛒 *Su carrito está vacío*\n\nAñada juegos del catálogo para realizar un pedido.",
        "settings": "⚙️ *Configuración*",
        "search": "🔍 *Buscar juegos*\n\nSeleccione el tipo de búsqueda:",
        "favorites_empty": "⭐ *Su lista de favoritos está vacía*\n\nAñada juegos a favoritos desde el catálogo.",
        "orders_empty": "📋 *Aún no tiene pedidos*\n\nRealice un pedido desde su carrito para verlo aquí.",
        "support": "📞 *Soporte*",
        "promocodes": "🎁 *Códigos promocionales*",
        "donate": "💲 *Apoyar el proyecto*",
        "steam_topup": "🎮 *Recargar monedero de Steam*",
        "achievements": "🏆 *Logros*",
        "daily_bonus": "🎁 *Bono diario*",
        "level_up": "🎉 *¡Felicidades! ¡Has alcanzado el nivel {}!*",
        "recommendations": "🔍 *Juegos recomendados*"
    },
    "it": {
        "welcome": "🐺 *Benvenuto su VolkStore, {}!*",
        "catalog": "🎮 *Catalogo giochi*\n\nSeleziona una categoria:",
        "cart_empty": "🛒 *Il tuo carrello è vuoto*\n\nAggiungi giochi dal catalogo per effettuare un ordine.",
        "settings": "⚙️ *Impostazioni*",
        "search": "🔍 *Cerca giochi*\n\nSeleziona il tipo di ricerca:",
        "favorites_empty": "⭐ *La tua lista dei preferiti è vuota*\n\nAggiungi giochi ai preferiti dal catalogo.",
        "orders_empty": "📋 *Non hai ancora ordini*\n\nEffettua un ordine dal tuo carrello per vederlo qui.",
        "support": "📞 *Supporto*",
        "promocodes": "🎁 *Codici promozionali*",
        "donate": "💲 *Supporta il progetto*",
        "steam_topup": "🎮 *Ricarica portafoglio Steam*",
        "achievements": "🏆 *Obiettivi*",
        "daily_bonus": "🎁 *Bonus giornaliero*",
        "level_up": "🎉 *Congratulazioni! Hai raggiunto il livello {}!*",
        "recommendations": "🔍 *Giochi consigliati*"
    },
    "zh": {
        "welcome": "🐺 *欢迎来到 VolkStore, {}!*",
        "catalog": "🎮 *游戏目录*\n\n选择一个类别:",
        "cart_empty": "🛒 *您的购物车是空的*\n\n从目录中添加游戏以下订单。",
        "settings": "⚙️ *设置*",
        "search": "🔍 *搜索游戏*\n\n选择搜索类型:",
        "favorites_empty": "⭐ *您的收藏列表是空的*\n\n从目录中将游戏添加到收藏夹。",
        "orders_empty": "📋 *您还没有订单*\n\n从购物车下订单以在此处查看。",
        "support": "📞 *支持*",
        "promocodes": "🎁 *促销代码*",
        "donate": "💲 *支持项目*",
        "steam_topup": "🎮 *Steam钱包充值*",
        "achievements": "🏆 *成就*",
        "daily_bonus": "🎁 *每日奖励*",
        "level_up": "🎉 *恭喜！您已达到{}级！*",
        "recommendations": "🔍 *推荐游戏*"
    },
    "ja": {
        "welcome": "🐺 *VolkStoreへようこそ、{}さん！*",
        "catalog": "🎮 *ゲームカタログ*\n\nカテゴリを選択してください:",
        "cart_empty": "🛒 *カートは空です*\n\n注文するにはカタログからゲームを追加してください。",
        "settings": "⚙️ *設定*",
        "search": "🔍 *ゲームを検索*\n\n検索タイプを選択してください:",
        "favorites_empty": "⭐ *お気に入りリストは空です*\n\nカタログからゲームをお気に入りに追加してください。",
        "orders_empty": "📋 *まだ注文がありません*\n\nカートから注文すると、ここに表示されます。",
        "support": "📞 *サポート*",
        "promocodes": "🎁 *プロモコード*",
        "donate": "💲 *プロジェクトを支援する*",
        "steam_topup": "🎮 *Steamウォレットのチャージ*",
        "achievements": "🏆 *実績*",
        "daily_bonus": "🎁 *デイリーボーナス*",
        "level_up": "🎉 *おめでとうございます！レベル{}に達しました！*",
        "recommendations": "🔍 *おすすめゲーム*"
    }
}

# Функция для получения локализованного текста
def get_localized_text(key, user_id, *args):
    settings = get_user_settings(user_id)
    lang = settings["language"]
    
    # Если язык не поддерживается, используем русский
    if lang not in localization:
        lang = "ru"
    
    # Получаем текст по ключу
    text = localization[lang].get(key, localization["ru"].get(key, ""))
    
    # Форматируем текст, если есть аргументы
    if args:
        text = text.format(*args)
    
    return text

# Список достижений
achievements = {
    "first_purchase": {
        "id": "first_purchase",
        "name": "Первая покупка",
        "description": "Совершите первую покупку в магазине",
        "reward": 100,  # Бонусные очки
        "icon": "🛒"
    },
    "collector": {
        "id": "collector",
        "name": "Коллекционер",
        "description": "Добавьте 10 игр в избранное",
        "reward": 200,
        "icon": "⭐"
    },
    "big_spender": {
        "id": "big_spender",
        "name": "Большой покупатель",
        "description": "Потратьте в магазине более 10000 ₽",
        "reward": 500,
        "icon": "💰"
    },
    "reviewer": {
        "id": "reviewer",
        "name": "Критик",
        "description": "Оставьте 5 отзывов на игры",
        "reward": 300,
        "icon": "📝"
    },
    "loyal_customer": {
        "id": "loyal_customer",
        "name": "Постоянный клиент",
        "description": "Посещайте магазин 7 дней подряд",
        "reward": 400,
        "icon": "📅"
    },
    "steam_fan": {
        "id": "steam_fan",
        "name": "Фанат Steam",
        "description": "Пополните кошелек Steam на сумму более 5000 ₽",
        "reward": 350,
        "icon": "🎮"
    }
}

# Функция для получения уровня пользователя
def get_user_level(user_id):
    if user_id not in user_levels:
        user_levels[user_id] = {
            "level": 1,
            "experience": 0,
            "next_level": 1000  # Опыт, необходимый для достижения следующего уровня
        }
    return user_levels[user_id]

# Функция для добавления опыта пользователю
def add_user_experience(user_id, amount):
    level_data = get_user_level(user_id)
    level_data["experience"] += amount
    
    # Проверяем, достиг ли пользователь нового уровня
    if level_data["experience"] >= level_data["next_level"]:
        level_data["level"] += 1
        level_data["next_level"] = level_data["level"] * 1000  # Увеличиваем требуемый опыт для следующего уровня
        
        # Отправляем уведомление о повышении уровня
        bot.send_message(
            user_id,
            get_localized_text("level_up", user_id, level_data["level"]),
            parse_mode="Markdown"
        )
        
        # Даем бонус за новый уровень
        give_level_bonus(user_id, level_data["level"])
    
    return level_data

# Функция дл�� выдачи бонуса за новый уровень
def give_level_bonus(user_id, level):
    # Бонус зависит от уровня
    bonus = level * 100
    
    # Создаем временную скидку для пользователя
    user_wolf_discounts[user_id] = {
        "value": min(level * 2, 20),  # Максимальная скидка 20%
        "expires": datetime.now() + timedelta(days=1)  # Скидка действует 1 день
    }
    
    bot.send_message(
        user_id,
        f"🎁 *Бонус за уровень {level}*\n\n"
        f"Вы получили временную скидку {user_wolf_discounts[user_id]['value']}% на все покупки в течение 24 часов!",
        parse_mode="Markdown"
    )

# Функция для проверки и выдачи ежедневного бонуса
def check_daily_bonus(user_id):
    today = datetime.now().date()
    
    if user_id not in user_daily_bonuses or user_daily_bonuses[user_id]["last_claimed"].date() < today:
        # Определяем бонус
        streak = 1
        if user_id in user_daily_bonuses:
            # Если пользователь заходил вчера, увеличиваем серию
            if (today - user_daily_bonuses[user_id]["last_claimed"].date()).days == 1:
                streak = user_daily_bonuses[user_id]["streak"] + 1
        
        # Бонус зависит от серии дней
        bonus_percent = min(streak * 2, 15)  # Максимальная скидка 15%
        
        # Сохраняем информацию о бонусе
        user_daily_bonuses[user_id] = {
            "last_claimed": datetime.now(),
            "streak": streak,
            "bonus": bonus_percent
        }
        
        # Создаем временную скидку для пользователя
        user_wolf_discounts[user_id] = {
            "value": bonus_percent,
            "expires": datetime.now() + timedelta(hours=12)  # Скидка действует 12 часов
        }
        
        # Отправляем уведомление о бонусе
        bot.send_message(
            user_id,
            f"🎁 *Ежедневный бонус*\n\n"
            f"Вы получили ежедневный бонус за посещение магазина {streak} дней подряд!\n"
            f"Скидка {bonus_percent}% на все покупки в течение 12 часов.",
            parse_mode="Markdown"
        )
        
        # Добавляем опыт за ежедневное посещение
        add_user_experience(user_id, 50 * streak)
        
        return True
    
    return False

# Функция для проверки и выдачи достижений
def check_achievements(user_id):
    if user_id not in user_achievements:
        user_achievements[user_id] = []
    
    # Проверяем каждое достижение
    for achievement_id, achievement in achievements.items():
        # Пропускаем уже полученные достижения
        if achievement_id in user_achievements[user_id]:
            continue
        
        # Проверяем условия достижения
        if achievement_id == "first_purchase" and user_id in user_orders and user_orders[user_id]:
            # Первая покупка
            award_achievement(user_id, achievement_id)
        
        elif achievement_id == "collector" and user_id in user_favorites and len(user_favorites[user_id]) >= 10:
            # Коллекционер
            award_achievement(user_id, achievement_id)
        
        elif achievement_id == "big_spender":
            # Большой покупатель
            total_spent = 0
            if user_id in user_orders:
                for order in user_orders[user_id]:
                    total_spent += order["total"]
            
            if total_spent >= 10000:
                award_achievement(user_id, achievement_id)
        
        elif achievement_id == "reviewer":
            # Критик
            review_count = 0
            for game in games:
                for review in game["reviews"]:
                    if review["user_id"] == user_id:
                        review_count += 1
            
            if review_count >= 5:
                award_achievement(user_id, achievement_id)
        
        elif achievement_id == "loyal_customer":
            # Постоянный клиент
            if user_id in user_daily_bonuses and user_daily_bonuses[user_id]["streak"] >= 7:
                award_achievement(user_id, achievement_id)
        
        elif achievement_id == "steam_fan":
            # Фанат Steam
            total_topup = 0
            if user_id in user_steam_topup_history:
                for topup in user_steam_topup_history[user_id]:
                    total_topup += topup["amount"]
            
            if total_topup >= 5000:
                award_achievement(user_id, achievement_id)

# Функция для выдачи достижения
def award_achievement(user_id, achievement_id):
    if achievement_id not in achievements:
        return
    
    if user_id not in user_achievements:
        user_achievements[user_id] = []
    
    # Добавляем достижение в список полученных
    user_achievements[user_id].append(achievement_id)
    
    # Получаем информацию о достижении
    achievement = achievements[achievement_id]
    
    # Добавляем опыт за достижение
    add_user_experience(user_id, achievement["reward"])
    
    # Отправляем уведомление о получении достижения
    bot.send_message(
        user_id,
        f"🏆 *Новое достижение разблокировано!*\n\n"
        f"{achievement['icon']} *{achievement['name']}*\n"
        f"{achievement['description']}\n\n"
        f"Награда: +{achievement['reward']} опыта",
        parse_mode="Markdown"
    )

# Функция для ото��ражения достижений пользователя
def show_user_achievements(chat_id, user_id):
    if user_id not in user_achievements or not user_achievements[user_id]:
        bot.send_message(
            chat_id,
            "🏆 *Достижения*\n\n"
            "У вас пока нет разблокированных достижений. Продолжайте пользоваться магазином, чтобы получать достижения!",
            parse_mode="Markdown"
        )
        return
    
    # Формируем текст с достижениями
    achievements_text = "🏆 *Ваши достижения*\n\n"
    
    for achievement_id in user_achievements[user_id]:
        achievement = achievements[achievement_id]
        achievements_text += f"{achievement['icon']} *{achievement['name']}*\n"
        achievements_text += f"{achievement['description']}\n"
        achievements_text += f"Награда: +{achievement['reward']} опыта\n\n"
    
    # Добавляем информацию о недостигнутых достижениях
    achievements_text += "*Доступные достижения:*\n\n"
    
    for achievement_id, achievement in achievements.items():
        if achievement_id not in user_achievements[user_id]:
            achievements_text += f"❓ *{achievement['name']}*\n"
            achievements_text += f"{achievement['description']}\n\n"
    
    # Формируем клавиатуру
    markup = types.InlineKeyboardMarkup(row_width=1)
    back_btn = types.InlineKeyboardButton("⬅️ Назад в меню", callback_data="back_to_menu")
    markup.add(back_btn)
    
    bot.send_message(
        chat_id,
        achievements_text,
        parse_mode="Markdown",
        reply_markup=markup
    )

# Функция для генерации рекомендаций игр
def generate_recommendations(user_id):
    if user_id not in user_recommendations:
        user_recommendations[user_id] = []
    
    # Получаем предпочтения пользователя
    settings = get_user_settings(user_id)
    preferred_genres = settings["preferred_genres"]
    
    # Получаем историю покупок
    purchased_games = []
    if user_id in user_orders:
        for order in user_orders[user_id]:
            purchased_games.extend(order["games"])
    
    # Получаем избранные игры
    favorite_games = []
    if user_id in user_favorites:
        favorite_games = user_favorites[user_id]
    
    # Формируем список рекомендаций
    recommendations = []
    
    # 1. Рекомендуем игры по жанрам, которые пользователь предпочитает
    if preferred_genres:
        for game in games:
            if game["id"] not in purchased_games and game["id"] not in favorite_games and game["genre"] in preferred_genres:
                recommendations.append(game["id"])
    
    # 2. Рекомендуем игры с высоким рейтингом
    high_rated_games = sorted([g for g in games if g["rating"] >= 4.5 and g["id"] not in purchased_games and g["id"] not in favorite_games], 
                             key=lambda x: x["rating"], reverse=True)
    
    for game in high_rated_games[:5]:
        if game["id"] not in recommendations:
            recommendations.append(game["id"])
    
    # 3. Рекомендуем игры со скидками
    discounted_games = [g for g in games if g.get("discount") and g["id"] not in purchased_games and g["id"] not in favorite_games]
    
    for game in discounted_games[:5  not in purchased_games and g["id"] not in favorite_games]
    
    for game in discounted_games[:5]:
        if game["id"] not in recommendations:
            recommendations.append(game["id"])
    
    # Сохраняем рекомендации
    user_recommendations[user_id] = recommendations[:10]  # Ограничиваем список 10 играми
    
    return user_recommendations[user_id]

# Функция для отображения рекомендаций
def show_recommendations(chat_id, user_id):
    # Генерируем рекомендации, если их нет
    if user_id not in user_recommendations or not user_recommendations[user_id]:
        generate_recommendations(user_id)
    
    # Получаем список рекомендуемых
# Продолжение кода...

# Функция для отображения рекомендаций
def show_recommendations(chat_id, user_id):
    # Генерируем рекомендации, если их нет
    if user_id not in user_recommendations or not user_recommendations[user_id]:
        generate_recommendations(user_id)
    
    # Получаем список рекомендуемых игр
    recommended_game_ids = user_recommendations[user_id]
    recommended_games = [game for game in games if game["id"] in recommended_game_ids]
    
    if not recommended_games:
        bot.send_message(
            chat_id,
            get_localized_text("recommendations_empty", user_id),
            parse_mode="Markdown"
        )
        return
    
    # Отправляем заголовок
    bot.send_message(
        chat_id,
        get_localized_text("recommendations", user_id),
        parse_mode="Markdown"
    )
    
    # Отправляем каждую игру отдельным сообщением
    for game in recommended_games[:5]:  # Показываем только первые 5 рекомендаций
        # Формируем текст с информацией об игре
        game_title = escape_markdown(game['title'])
        game_text = f"🎮 *{game_title}*\n"
        game_text += f"💰 Цена: {convert_price(game['price'], user_id)}"
        
        if game.get("discount"):
            game_text += f" (скидка {game['discount']})"
        
        game_text += f"\n🎭 Жанр: {escape_markdown(game['genre'])}\n"
        game_text += f"💻 Платформа: Steam\n"
        game_text += f"⭐ Рейтинг: {game['rating']}/5 ({len(game.get('reviews', []))} отзывов)"
        
        # Добавляем кнопки для каждой игры
        markup = types.InlineKeyboardMarkup(row_width=2)
        details_btn = types.InlineKeyboardButton("📋 Подробнее", callback_data=f"game_details_{game['id']}")
        cart_btn = types.InlineKeyboardButton("🛒 В корзину", callback_data=f"add_to_cart_{game['id']}")
        fav_btn = types.InlineKeyboardButton("⭐ В избранное", callback_data=f"add_favorite_{game['id']}")
        markup.add(details_btn, cart_btn, fav_btn)
        
        # Отправляем сообщение с игрой
        try:
            # Проверяем, существует ли изображение в локальной папке
            if image_exists(game["image"]):
                send_image_from_folder(
                    chat_id,
                    game["image"],
                    caption=game_text,
                    parse_mode="Markdown",
                    reply_markup=markup
                )
            else:
                # Если изображение не найдено, отправляем сообщение без изображения
                bot.send_message(
                    chat_id,
                    game_text,
                    parse_mode="Markdown",
                    reply_markup=markup
                )
        except Exception as e:
            logger.error(f"Ошибка при отправке фото: {e}")
            bot.send_message(
                chat_id,
                game_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
    
    # Отправляем клавиатуру действий
    markup = types.InlineKeyboardMarkup(row_width=1)
    refresh_btn = types.InlineKeyboardButton("🔄 Обновить рекомендации", callback_data="refresh_recommendations")
    catalog_btn = types.InlineKeyboardButton("🎮 В каталог", callback_data="back_to_catalog")
    menu_btn = types.InlineKeyboardButton("🏠 В главное меню", callback_data="back_to_menu")
    markup.add(refresh_btn, catalog_btn, menu_btn)
    
    bot.send_message(
        chat_id,
        "Используйте кнопки ниже для навигации:",
        reply_markup=markup
    )

# Обработчик кнопки "Достижения"
@bot.message_handler(func=lambda message: message.text == "🏆 Достижения")
def achievements_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    # Проверяем достижения пользователя
    check_achievements(user_id)
    
    # Показываем достижения
    show_user_achievements(message.chat.id, user_id)

# Обработчик кнопки "Рекомендации"
@bot.message_handler(func=lambda message: message.text == "🔍 Рекомендации")
def recommendations_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    # Показываем рекомендации
    show_recommendations(message.chat.id, user_id)

# Обработчик кнопки "Ежедневный бонус"
@bot.message_handler(func=lambda message: message.text == "🎁 Ежедневный бонус")
def daily_bonus_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    # Проверяем и выдаем ежедневный бонус
    if check_daily_bonus(user_id):
        # Бонус уже выдан в функции check_daily_bonus
        pass
    else:
        # Если бонус уже был получен сегодня
        today = datetime.now().date()
        next_bonus_time = datetime.combine(today + timedelta(days=1), datetime.min.time())
        time_left = next_bonus_time - datetime.now()
        hours_left = time_left.seconds // 3600
        minutes_left = (time_left.seconds % 3600) // 60
        
        bot.send_message(
            message.chat.id,
            f"⏰ *Ежедневный бонус уже получен*\n\n"
            f"Вы уже получили ежедневный бонус сегодня.\n"
            f"Следующий бонус будет доступен через {hours_left} ч. {minutes_left} мин.",
            parse_mode="Markdown"
        )

# Обработчик кнопки "Мой профиль"
@bot.message_handler(func=lambda message: message.text == "👤 Мой профиль")
def profile_handler(message):
    user_id = message.from_user.id
    
    # Проверяем, не заблокирован ли пользователь
    if is_blocked(user_id):
        bot.send_message(
            message.chat.id,
            "⛔ Вы заблокированы администратором. Обратитесь в поддержку для разблокировки.",
            parse_mode="Markdown"
        )
        return
    
    # Получаем настройки пользователя
    settings = get_user_settings(user_id)
    
    # Получаем уровень пользователя
    level_data = get_user_level(user_id)
    
    # Формируем текст профиля
    profile_text = (
        f"👤 *Профиль пользователя*\n\n"
        f"🆔 ID: {user_id}\n"
        f"👤 Имя: {settings['name'] or 'Не указано'}\n"
        f"✉️ Email: {settings['email'] or 'Не указан'}\n"
        f"🌐 Язык: {languages[settings['language']]}\n"
        f"💰 Валюта: {currencies[settings['currency']]['name']}\n\n"
        f"🏆 Уровень: {level_data['level']}\n"
        f"📊 Опыт: {level_data['experience']}/{level_data['next_level']}\n"
        f"⭐ Достижения: {len(user_achievements.get(user_id, []))}/{len(achievements)}\n\n"
    )
    
    # Добавляем информацию о заказах
    if user_id in user_orders and user_orders[user_id]:
        profile_text += f"📋 Заказы: {len(user_orders[user_id])}\n"
        total_spent = sum(order['total'] for order in user_orders[user_id])
        profile_text += f"💰 Потрачено: {convert_price(total_spent, user_id)}\n\n"
    else:
        profile_text += "📋 Заказы: 0\n"
        profile_text += "💰 Потрачено: 0\n\n"
    
    # Добавляем информацию о бонусах
    if user_id in user_wolf_discounts and user_wolf_discounts[user_id]["expires"] > datetime.now():
        expires_in = user_wolf_discounts[user_id]["expires"] - datetime.now()
        hours = expires_in.seconds // 3600
        minutes = (expires_in.seconds % 3600) // 60
        profile_text += f"🐺 Активная скидка: {user_wolf_discounts[user_id]['value']}% (истекает через {hours} ч. {minutes} мин.)\n"
    
    # Формируем клавиатуру
    markup = types.InlineKeyboardMarkup(row_width=1)
    settings_btn = types.InlineKeyboardButton("⚙️ Настройки", callback_data="go_to_settings")
    achievements_btn = types.InlineKeyboardButton("🏆 Достижения", callback_data="show_achievements")
    orders_btn = types.InlineKeyboardButton("📋 Мои заказы", callback_data="show_orders")
    favorites_btn = types.InlineKeyboardButton("⭐ Избранное", callback_data="show_favorites")
    back_btn = types.InlineKeyboardButton("⬅️ Назад в меню", callback_data="back_to_menu")
    markup.add(settings_btn, achievements_btn, orders_btn, favorites_btn, back_btn)
    
    # Отправляем сообщение с профилем
    try:
        # Проверяем, существует ли изображение в локальной папке
        if image_exists("profile.jpg"):
            send_image_from_folder(
                message.chat.id,
                "profile.jpg",
                caption=profile_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            # Если изображение не найдено, отправляем сообщение без изображения
            bot.send_message(
                message.chat.id,
                profile_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
    except Exception as e:
        logger.error(f"Ошибка при отправке фото: {e}")
        bot.send_message(
            message.chat.id,
            profile_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обновляем главное меню с новыми кнопками
def get_main_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    catalog_btn = types.KeyboardButton("🎮 Каталог игр")
    cart_btn = types.KeyboardButton("🛒 Моя корзина")
    search_btn = types.KeyboardButton("🔍 Поиск игр")
    favorites_btn = types.KeyboardButton("⭐ Избранное")
    orders_btn = types.KeyboardButton("📋 Мои заказы")
    profile_btn = types.KeyboardButton("👤 Мой профиль")
    settings_btn = types.KeyboardButton("⚙️ Настройки")
    achievements_btn = types.KeyboardButton("🏆 Достижения")
    recommendations_btn = types.KeyboardButton("🔍 Рекомендации")
    daily_bonus_btn = types.KeyboardButton("🎁 Ежедневный бонус")
    support_btn = types.KeyboardButton("📞 Поддержка")
    steam_btn = types.KeyboardButton("🎮 Пополнить Steam")
    markup.add(catalog_btn, cart_btn, search_btn, favorites_btn, orders_btn, profile_btn, 
               settings_btn, achievements_btn, recommendations_btn, daily_bonus_btn, support_btn, steam_btn)
    return markup

# Обработчики callback-запросов для админ-панели
@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_"))
def admin_callback_handler(call):
    user_id = call.from_user.id
    
    # Проверяем, является ли пользователь администратором
    if not is_admin(user_id):
        bot.answer_callback_query(
            call.id,
            "⛔ У вас нет доступа к админ-панели.",
            show_alert=True
        )
        return
    
    # Обработка различных callback-запросов админ-панели
    if call.data == "admin_games":
        # Управление играми
        bot.edit_message_text(
            "🎮 *Управление играми*\n\nВыберите действие:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_games_management_keyboard()
        )
    
    elif call.data == "admin_users":
        # Управление пользователями
        bot.edit_message_text(
            "👥 *Управление пользователями*\n\nВыберите действие:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_users_management_keyboard()
        )
    
    elif call.data == "admin_orders":
        # Управление заказами
        bot.edit_message_text(
            "📋 *Управление заказами*\n\nВыберите действие:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_orders_management_keyboard()
        )
    
    elif call.data == "admin_promo":
        # Управление промокодами
        bot.edit_message_text(
            "🎁 *Управление промокодами*\n\nВыберите действие:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_promo_management_keyboard()
        )
    
    elif call.data == "admin_stats":
        # Статистика
        bot.edit_message_text(
            "📊 *Статистика*\n\nВыберите тип статистики:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_stats_keyboard()
        )
    
    elif call.data == "admin_broadcast":
        # Рассылка
        bot.edit_message_text(
            "📢 *Рассылка сообщений*\n\nВыберите тип рассылки:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_broadcast_keyboard()
        )
    
    elif call.data == "admin_exit":
        # Выход из админ-панели
        bot.edit_message_text(
            "✅ Вы вышли из админ-панели.",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.send_message(
            call.message.chat.id,
            "Выберите действие:",
            reply_markup=get_main_keyboard()
        )
    
    elif call.data == "admin_back_to_main":
        # Возврат в главное меню админ-панели
        bot.edit_message_text(
            "👨‍💼 *Админ-панель VolkStore*\n\n"
            "Добро пожаловать в панель администратора!\n"
            "Выберите действие из меню ниже:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_admin_keyboard()
        )
    
    elif call.data == "admin_add_game":
        # Добавление новой игры
        admin_states[user_id] = {}
        
        bot.edit_message_text(
            "🎮 *Добавление новой игры*\n\n"
            "Пожалуйста, введите название игры:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(call.message, process_add_game_name)
    
    elif call.data == "admin_edit_game":
        # Редактирование игры
        bot.edit_message_text(
            "🎮 *Редактирование игры*\n\n"
            "Пожалуйста, введите ID игры, которую хотите отредактировать:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(call.message, process_edit_game_id)
    
    elif call.data == "admin_delete_game":
        # Удаление игры
        bot.edit_message_text(
            "🎮 *Удаление игры*\n\n"
            "Пожалуйста, введите ID игры, которую хотите удалить:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(call.message, process_delete_game_id)
    
    elif call.data == "admin_list_games":
        # Список игр
        games_text = "🎮 *Список игр:*\n\n"
        
        for game in games:
            games_text += f"🆔 {game['id']} - {game['title']} ({game['price']} ₽)\n"
        
        # Разбиваем на части, если текст слишком длинный
        if len(games_text) > 4000:
            parts = [games_text[i:i+4000] for i in range(0, len(games_text), 4000)]
            for i, part in enumerate(parts):
                if i == 0:
                    bot.edit_message_text(
                        part,
                        call.message.chat.id,
                        call.message.message_id,
                        parse_mode="Markdown"
                    )
                else:
                    bot.send_message(
                        call.message.chat.id,
                        part,
                        parse_mode="Markdown"
                    )
        else:
            bot.edit_message_text(
                games_text,
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
        
        # Отправляем клавиатуру отдельным сообщением
        bot.send_message(
            call.message.chat.id,
            "Выберите действие:",
            reply_markup=get_games_management_keyboard()
        )
    
    elif call.data == "admin_search_user":
        # Поиск пользователя
        bot.edit_message_text(
            "👥 *Поиск пользователя*\n\n"
            "Пожалуйста, введите ID пользователя:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(call.message, process_search_user_id)
    
    elif call.data == "admin_list_users":
        # Список пользователей
        users_text = "👥 *Список пользователей:*\n\n"
        
        for user_id, settings in user_settings.items():
            name = settings.get('name', 'Не указано')
            email = settings.get('email', 'Не указан')
            users_text += f"🆔 {user_id} - {name} ({email})\n"
        
        # Разбиваем на части, если текст слишком длинный
        if len(users_text) > 4000:
            parts = [users_text[i:i+4000] for i in range(0, len(users_text), 4000)]
            for i, part in enumerate(parts):
                if i == 0:
                    bot.edit_message_text(
                        part,
                        call.message.chat.id,
                        call.message.message_id,
                        parse_mode="Markdown"
                    )
                else:
                    bot.send_message(
                        call.message.chat.id,
                        part,
                        parse_mode="Markdown"
                    )
        else:
            bot.edit_message_text(
                users_text,
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
        
        # Отправляем клавиатуру отдельным сообщением
        bot.send_message(
            call.message.chat.id,
            "Выберите действие:",
            reply_markup=get_users_management_keyboard()
        )
    
    elif call.data == "admin_search_order":
        # Поиск заказа
        bot.edit_message_text(
            "📋 *Поиск заказа*\n\n"
            "Пожалуйста, введите ID заказа:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(call.message, process_search_order_id)
    
    elif call.data == "admin_list_orders":
        # Список заказов
        orders_text = "📋 *Список заказов:*\n\n"
        
        all_orders = []
        for uid, user_order_list in user_orders.items():
            for order in user_order_list:
                all_orders.append((uid, order))
        
        # Сортируем по дате (от новых к старым)
        all_orders.sort(key=lambda x: x[1]['date'], reverse=True)
        
        for uid, order in all_orders[:20]:  # Показываем только последние 20 заказов
            orders_text += f"🆔 {order['id']} - Пользователь {uid} - {order['date']} - {order['total']} ₽ - {order['status']}\n"
        
        if len(all_orders) > 20:
            orders_text += f"\n... и еще {len(all_orders) - 20} заказов"
        
        bot.edit_message_text(
            orders_text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        
        # Отправляем клавиатуру отдельным сообщением
        bot.send_message(
            call.message.chat.id,
            "Выберите действие:",
            reply_markup=get_orders_management_keyboard()
        )
    
    elif call.data == "admin_add_promo":
        # Добавление нового промокода
        admin_states[user_id] = {}
        
        bot.edit_message_text(
            "🎁 *Добавление нового промокода*\n\n"
            "Пожалуйста, введите код промокода (буквы и цифры):",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(call.message, process_add_promo_code)
    
    elif call.data == "admin_list_promos":
        # Список промокодов
        promos_text = "🎁 *Список промокодов:*\n\n"
        
        for code, promo in promocodes.items():
            promo_type = ""
            if promo["type"] == "percent":
                promo_type = f"Скидка {promo['value']}%"
            elif promo["type"] == "fixed":
                promo_type = f"Скидка {promo['value']} ₽"
            elif promo["type"] == "free_game":
                game = next((g for g in games if g["id"] == promo["game_id"]), None)
                game_title = game["title"] if game else "Неизвестная игра"
                promo_type = f"Бесплатная игра: {game_title}"
            elif promo["type"] == "steam_topup":
                promo_type = f"Бонус {promo['value']}% при пополнении Steam"
            elif promo["type"] == "first_order":
                promo_type = f"Скидка {promo['value']}% на первый заказ"
            
            expires = promo["expires"].strftime("%d.%m.%Y")
            used_count = len(promo["used_by"])
            
            promos_text += f"🎟️ {code} - {promo_type} - до {expires} - использован {used_count} раз\n"
        
        bot.edit_message_text(
            promos_text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        
        # Отправляем клавиатуру отдельным сообщением
        bot.send_message(
            call.message.chat.id,
            "Выберите действие:",
            reply_markup=get_promo_management_keyboard()
        )
    
    elif call.data == "admin_stats_sales":
        # Статистика продаж
        sales_text = "💰 *Статистика продаж:*\n\n"
        
        # Общая сумма продаж
        total_sales = 0
        for uid, user_order_list in user_orders.items():
            for order in user_order_list:
                total_sales += order["total"]
        
        sales_text += f"💰 Общая сумма продаж: {total_sales} ₽\n"
        sales_text += f"📦 Общее количество заказов: {sum(len(orders) for orders in user_orders.values())}\n"
        sales_text += f"👥 Количество покупателей: {len(user_orders)}\n\n"
        
        # Статистика по дням
        sales_by_day = {}
        for uid, user_order_list in user_orders.items():
            for order in user_order_list:
                date = order["date"].split()[0]  # Берем только дату без времени
                if date not in sales_by_day:
                    sales_by_day[date] = 0
                sales_by_day[date] += order["total"]
        
        sales_text += "📅 *Продажи по дням:*\n"
        for date, amount in sorted(sales_by_day.items(), reverse=True)[:7]:  # Показываем последние 7 дней
            sales_text += f"- {date}: {amount} ₽\n"
        
        # Самые популярные игры
        game_sales = {}
        for uid, user_order_list in user_orders.items():
            for order in user_order_list:
                for game_id in order["games"]:
                    if game_id not in game_sales:
                        game_sales[game_id] = 0
                    game_sales[game_id] += 1
        
        sales_text += "\n🎮 *Самые популярные игры:*\n"
        for game_id, count in sorted(game_sales.items(), key=lambda x: x[1], reverse=True)[:5]:
            game = next((g for g in games if g["id"] == game_id), None)
            if game:
                sales_text += f"- {game['title']}: {count} продаж\n"
        
        bot.edit_message_text(
            sales_text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        
        # Отправляем клавиатуру отдельным сообщением
        bot.send_message(
            call.message.chat.id,
            "Выберите действие:",
            reply_markup=get_stats_keyboard()
        )
    
    elif call.data == "admin_stats_users":
        # Статистика пользователей
        users_text = "👥 *Статистика пользователей:*\n\n"
        
        users_text += f"👥 Общее количество пользователей: {len(user_settings)}\n"
        users_text += f"🛒 Пользователей с корзиной: {len(user_carts)}\n"
        users_text += f"⭐ Пользователей с избранным: {len(user_favorites)}\n"
        users_text += f"📋 Пользователей с заказами: {len(user_orders)}\n\n"
        
        # Статистика по языкам
        languages_stats = {}
        for uid, settings in user_settings.items():
            lang = settings.get("language", "ru")
            if lang not in languages_stats:
                languages_stats[lang] = 0
            languages_stats[lang] += 1
        
        users_text += "🌐 *Языки пользователей:*\n"
        for lang, count in sorted(languages_stats.items(), key=lambda x: x[1], reverse=True):
            lang_name = languages.get(lang, lang)
            users_text += f"- {lang_name}: {count} пользователей\n"
        
        # Статистика по валютам
        currencies_stats = {}
        for uid, settings in user_settings.items():
            currency = settings.get("currency", "RUB")
            if currency not in currencies_stats:
                currencies_stats[currency] = 0
            currencies_stats[currency] += 1
        
        users_text += "\n💰 *Валюты пользователей:*\n"
        for currency, count in sorted(currencies_stats.items(), key=lambda x: x[1], reverse=True):
            currency_name = currencies.get(currency, {}).get("name", currency)
            users_text += f"- {currency_name}: {count} пользователей\n"
        
        bot.edit_message_text(
            users_text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        
        # Отправляем клавиатуру отдельным сообщением
        bot.send_message(
            call.message.chat.id,
            "Выберите действие:",
            reply_markup=get_stats_keyboard()
        )
    
    elif call.data == "admin_stats_games":
        # Статистика игр
        games_text = "🎮 *Статистика игр:*\n\n"
        
        games_text += f"🎮 Общее количество игр: {len(games)}\n\n"
        
        # Статистика по жанрам
        genres_stats = {}
        for game in games:
            genre = game["genre"]
            if genre not in genres_stats:
                genres_stats[genre] = 0
            genres_stats[genre] += 1
        
        games_text += "🎭 *Жанры игр:*\n"
        for genre, count in sorted(genres_stats.items(), key=lambda x: x[1], reverse=True):
            games_text += f"- {genre}: {count} игр\n"
        
        # Статистика по рейтингам
        ratings = [game["rating"] for game in games]
        avg_rating = sum(ratings) / len(ratings) if ratings else 0
        
        games_text += f"\n⭐ Средний рейтинг игр: {avg_rating:.1f}/5\n"
        
        # Игры с наибольшим количеством отзывов
        games_by_reviews = sorted(games, key=lambda g: len(g.get("reviews", [])), reverse=True)
        
        games_text += "\n📝 *Игры с наибольшим количеством отзывов:*\n"
        for game in games_by_reviews[:5]:
            games_text += f"- {game['title']}: {len(game.get('reviews', []))} отзывов\n"
        
        bot.edit_message_text(
            games_text,
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        
        # Отправляем клавиатуру отдельным сообщением
        bot.send_message(
            call.message.chat.id,
            "Выберите действие:",
            reply_markup=get_stats_keyboard()
        )
    
    elif call.data == "admin_broadcast_all":
        # Рассылка всем пользователям
        admin_states[user_id] = {"broadcast_type": "all"}
        
        bot.edit_message_text(
            "📢 *Рассылка всем пользователям*\n\n"
            "Введите текст сообщения для рассылки:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(call.message, process_broadcast_message)
    
    elif call.data == "admin_broadcast_active":
        # Рассылка активным пользователям
        admin_states[user_id] = {"broadcast_type": "active"}
        
        bot.edit_message_text(
            "📢 *Рассылка активным пользователям*\n\n"
            "Введите текст сообщения для рассылки:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(call.message, process_broadcast_message)
    
    elif call.data.startswith("admin_confirm_delete_game_"):
        # Подтверждение удаления игры
        game_id = int(call.data.split("_")[-1])
        
        # Ищем игру по ID
        game = next((g for g in games if g["id"] == game_id), None)
        
        if game:
            # Удаляем игру из списка
            games.remove(game)
            
            bot.edit_message_text(
                f"✅ Игра *{game['title']}* успешно удалена!",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
            
            # Возвращаемся в меню управления играми
            bot.send_message(
                call.message.chat.id,
                "Выберите действие:",
                reply_markup=get_games_management_keyboard()
            )
        else:
            bot.edit_message_text(
                "❌ Игра не найдена.",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown",
                reply_markup=get_games_management_keyboard()
            )
    
    elif call.data.startswith("admin_edit_game_"):
        # Редактирование поля игры
        field = call.data.replace("admin_edit_game_", "")
        
        if "edit_game_id" not in admin_states[user_id]:
            bot.answer_callback_query(
                call.id,
                "❌ Произошла ошибка. Пожалуйста, начните процесс редактирования заново.",
                show_alert=True
            )
            return
        
        game_id = admin_states[user_id]["edit_game_id"]
        game = next((g for g in games if g["id"] == game_id), None)
        
        if not game:
            bot.answer_callback_query(
                call.id,
                "❌ Игра не найдена.",
                show_alert=True
            )
            return
        
        # Запрашиваем новое значение для поля
        field_names = {
            "name": "название",
            "description": "описание",
            "price": "цену",
            "genre": "жанр",
            "platforms": "платформы",
            "image": "ссылку на изображение",
            "discount": "скидку (в процентах, например: 10)"
        }
        
        admin_states[user_id]["edit_field"] = field
        
        bot.edit_message_text(
            f"✏️ *Редактирование игры*\n\n"
            f"Текущее {field_names.get(field, field)}: {game.get(field, 'Не указано')}\n\n"
            f"Введите новое {field_names.get(field, field)}:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(call.message, process_edit_game_field)
    
    elif call.data.startswith("admin_block_user_"):
        # Блокировка пользователя
        block_user_id = int(call.data.split("_")[-1])
        
        # Добавляем пользователя в список заблокированных
        if block_user_id not in blocked_users:
            blocked_users.append(block_user_id)
            
            bot.edit_message_text(
                f"✅ Пользователь с ID {block_user_id} успешно заблокирован!",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
            
            # Отправляем уведомление пользователю
            try:
                bot.send_message(
                    block_user_id,
                    "⛔ *Вы были заблокированы администратором.*\n\n"
                    "Для разблокировки обратитесь в поддержку.",
                    parse_mode="Markdown"
                )
            except Exception as e:
                logger.error(f"Ошибка при отправке уведомления о блокировке: {e}")
        else:
            bot.edit_message_text(
                f"⚠️ Пользователь с ID {block_user_id} уже заблокирован.",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
        
        # Возвращаемся в меню управления пользователями
        bot.send_message(
            call.message.chat.id,
            "Выберите действие:",
            reply_markup=get_users_management_keyboard()
        )
    
    elif call.data.startswith("admin_user_orders_"):
        # Просмотр заказов пользователя
        user_id_to_view = int(call.data.split("_")[-1])
        
        if user_id_to_view in user_orders and user_orders[user_id_to_view]:
            orders_text = f"📋 *Заказы пользователя {user_id_to_view}:*\n\n"
            
            for order in user_orders[user_id_to_view]:
                orders_text += f"🆔 Заказ #{order['id']}\n"
                orders_text += f"📅 Дата: {order['date']}\n"
                orders_text += f"💰 Сумма: {order['total']} ₽\n"
                orders_text += f"✅ Статус: {order['status']}\n"
                orders_text += f"🎮 Игры: {len(order['games'])}\n\n"
            
            bot.edit_message_text(
                orders_text,
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
        else:
            bot.edit_message_text(
                f"📋 *Заказы пользователя {user_id_to_view}:*\n\n"
                f"У пользователя нет заказов.",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
        
        # Добавляем кнопку возврата
        markup = types.InlineKeyboardMarkup(row_width=1)
        back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_users")
        markup.add(back_btn)
        
        bot.edit_message_reply_markup(
            call.message.chat.id,
            call.message.message_id,
            reply_markup=markup
        )
    
    elif call.data == "admin_back_to_users":
        # Возврат в меню управления пользователями
        bot.edit_message_text(
            "👥 *Управление пользователями*\n\nВыберите действие:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_users_management_keyboard()
        )
    
    elif call.data == "admin_back_to_games":
        # Возврат в меню управления играми
        bot.edit_message_text(
            "🎮 *Управление играми*\n\nВыберите действие:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_games_management_keyboard()
        )
    
    elif call.data == "admin_back_to_orders":
        # Возврат в меню управления заказами
        bot.edit_message_text(
            "📋 *Управление заказами*\n\nВыберите действие:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_orders_management_keyboard()
        )
    
    elif call.data == "admin_back_to_promo":
        # Возврат в меню управления промокодами
        bot.edit_message_text(
            "🎁 *Управление промокодами*\n\nВыберите действие:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_promo_management_keyboard()
        )
    
    elif call.data.startswith("admin_change_status_"):
        # Изменение статуса заказа
        order_id = call.data.split("_")[-1]
        
        # Ищем заказ
        found_order = None
        found_user_id = None
        
        for uid, orders in user_orders.items():
            for order in orders:
                if order['id'] == order_id:
                    found_order = order
                    found_user_id = uid
                    break
            if found_order:
                break
        
        if found_order:
            # Клавиатура для выбора нового статуса
            markup = types.InlineKeyboardMarkup(row_width=1)
            
            statuses = ["Новый", "Оплачен", "В обработке", "Отправлен", "Доставлен", "Отменен"]
            
            for status in statuses:
                if status != found_order["status"]:
                    btn = types.InlineKeyboardButton(status, callback_data=f"admin_set_status_{order_id}_{status}")
                    markup.add(btn)
            
            back_btn = types.InlineKeyboardButton("⬅️ Назад", callback_data="admin_back_to_orders")
            markup.add(back_btn)
            
            bot.edit_message_text(
                f"✏️ *Изменение статуса заказа #{order_id}*\n\n"
                f"Текущий статус: {found_order['status']}\n\n"
                f"Выберите новый статус:",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            bot.answer_callback_query(
                call.id,
                "❌ Заказ не найден.",
                show_alert=True
            )
    
    elif call.data.startswith("admin_set_status_"):
        # Установка нового статуса заказа
        parts = call.data.split("_")
        order_id = parts[3]
        new_status = parts[4]
        
        # Ищем заказ
        found_order = None
        found_user_id = None
        
        for uid, orders in user_orders.items():
            for order in orders:
                if order['id'] == order_id:
                    found_order = order
                    found_user_id = uid
                    break
            if found_order:
                break
        
        if found_order:
            # Обновляем статус
            old_status = found_order["status"]
            found_order["status"] = new_status
            
            bot.edit_message_text(
                f"✅ Статус заказа #{order_id} изменен с '{old_status}' на '{new_status}'.",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
            
            # Отправляем уведомление пользователю
            try:
                bot.send_message(
                    found_user_id,
                    f"📋 *Обновление статуса заказа*\n\n"
                    f"Статус вашего заказа #{order_id} изменен на '{new_status}'.",
                    parse_mode="Markdown"
                )
            except Exception as e:
                logger.error(f"Ошибка при отправке уведомления об изменении статуса: {e}")
            
            # Возвращаемся в меню управления заказами
            bot.send_message(
                call.message.chat.id,
                "Выберите действие:",
                reply_markup=get_orders_management_keyboard()
            )
        else:
            bot.answer_callback_query(
                call.id,
                "❌ Заказ не найден.",
                show_alert=True
            )
    
    elif call.data.startswith("admin_promo_type_"):
        # Выбор типа промокода
        promo_type = call.data.replace("admin_promo_type_", "")
        
        if "promo_code" not in admin_states[user_id]:
            bot.answer_callback_query(
                call.id,
                "❌ Произошла ошибка. Пожалуйста, начните процесс добавления промокода заново.",
                show_alert=True
            )
            return
        
        # Сохраняем тип промокода
        admin_states[user_id]["promo_type"] = promo_type
        
        # Запрашиваем значение промокода в зависимости от типа
        if promo_type == "percent":
            bot.edit_message_text(
                "🎁 *Добавление промокода*\n\n"
                "Выбран тип: Процентная скидка\n\n"
                "Введите размер скидки в процентах (только число, например: 10):",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(call.message, process_promo_value)
        
        elif promo_type == "fixed":
            bot.edit_message_text(
                "🎁 *Добавление промокода*\n\n"
                "Выбран тип: Фиксированная скидка\n\n"
                "Введите размер скидки в рублях (только число, например: 500):",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(call.message, process_promo_value)
        
        elif promo_type == "free_game":
            # Формируем список игр для выбора
            markup = types.InlineKeyboardMarkup(row_width=1)
            
            for game in games[:10]:  # Показываем только первые 10 игр
                btn = types.InlineKeyboardButton(game["title"], callback_data=f"admin_promo_game_{game['id']}")
                markup.add(btn)
            
            cancel_btn = types.InlineKeyboardButton("❌ Отмена", callback_data="admin_back_to_promo")
            markup.add(cancel_btn)
            
            bot.edit_message_text(
                "🎁 *Добавление промокода*\n\n"
                "Выбран тип: Бесплатная игра\n\n"
                "Выберите игру, которую можно будет получить бесплатно:",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown",
                reply_markup=markup
            )
        
        elif promo_type == "steam_topup":
            bot.edit_message_text(
                "🎁 *Добавление промокода*\n\n"
                "Выбран тип: Бонус при пополнении Steam\n\n"
                "Введите размер бонуса в процентах (только число, например: 10):",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(call.message, process_promo_value)
        
        elif promo_type == "first_order":
            bot.edit_message_text(
                "🎁 *Добавление промокода*\n\n"
                "Выбран тип: Скидка на первый заказ\n\n"
                "Введите размер скидки в процентах (только число, например: 15):",
                call.message.chat.id,
                call.message.message_id,
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(call.message, process_promo_value)
    
    elif call.data.startswith("admin_promo_game_"):
        # Выбор игры для промокода
        game_id = int(call.data.split("_")[-1])
        
        if "promo_code" not in admin_states[user_id] or "promo_type" not in admin_states[user_id]:
            bot.answer_callback_query(
                call.id,
                "❌ Произошла ошибка. Пожалуйста, начните процесс добавления промокода заново.",
                show_alert=True
            )
            return
        
        # Сохраняем ID игры
        admin_states[user_id]["promo_game_id"] = game_id
        
        # Запрашиваем минимальную сумму заказа
        bot.edit_message_text(
            "🎁 *Добавление промокода*\n\n"
            "Введите минимальную сумму заказа для применения промокода (только число, например: 1000):",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(call.message, process_promo_min_order)
    
    bot.answer_callback_query(call.id)

# Обработчик ввода значения промокода
def process_promo_value(message):
    user_id = message.from_user.id
    
    try:
        value = int(message.text.strip())
        
        if value <= 0:
            bot.send_message(
                message.chat.id,
                "❌ Значение должно быть положительным числом. Пожалуйста, введите корректное значение:",
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(message, process_promo_value)
            return
        
        # Сохраняем значение промокода
        admin_states[user_id]["promo_value"] = value
        
        # Запрашиваем минимальную сумму заказа
        bot.send_message(
            message.chat.id,
            "🎁 *Добавление промокода*\n\n"
            "Введите минимальную сумму заказа для применения промокода (только число, например: 1000):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_promo_min_order)
    except ValueError:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите корректное число:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_promo_value)

# Обработчик ввода минимальной суммы заказа для промокода
def process_promo_min_order(message):
    user_id = message.from_user.id
    
    try:
        min_order = int(message.text.strip())
        
        if min_order < 0:
            bot.send_message(
                message.chat.id,
                "❌ Значение не может быть отрицательным. Пожалуйста, введите корректное значение:",
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(message, process_promo_min_order)
            return
        
        # Сохраняем минимальную сумму заказа
        admin_states[user_id]["promo_min_order"] = min_order
        
        # Запрашиваем срок действия промокода
        bot.send_message(
            message.chat.id,
            "🎁 *Добавление промокода*\n\n"
            "Введите срок действия промокода в днях (только число, например: 30):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_promo_expires)
    except ValueError:
        bot.send_message(
            message.chat.id,
            "❌ Пожалуйста, введите корректное число:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_promo_min_order)

# Обработчик ввода срока действия промокода
def process_promo_expires(message):
    user_id = message.from_user.id
    
    try:
        days = int(message.text.strip())
        
        if days <= 0:
            bot.send_message(
                message.chat.id,
                "❌ Срок действия должен быть положительным числом. Пожалуйста, введите корректное значение:",
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(message, process_promo_expires)
            return
        
        # Вычисляем дату истечения срока действия
        expires = datetime.now() + timedelta(days=days)
        
        # Создаем новый промокод
        promo_code = admin_states[user_id]["promo_code"]
        promo_type = admin_states[user_id]["promo_type"]
        
        new_promo = {
            "type": promo_type,
            "expires": expires,
            "used_by": []
        }
        
        # Добавляем специфические поля в зависимости от типа промокода
        if promo_type == "percent" or promo_type == "fixed" or promo_type == "steam_topup" or promo_type == "first_order":
            new_promo["value"] = admin_states[user_id]["promo_value"]
            new_promo["min_order"] = admin_states[user_id]["promo_min_order"]
            
            if promo_type == "percent":
                new_promo["description"] = f"Скидка {new_promo['value']}% на всю корзину"
            elif promo_type == "fixed":
                new_promo["description"] = f"Скидка {new_promo['value']} ₽ на заказ"
            elif promo_type == "steam_topup":
                new_promo["description"] = f"Дополнительные {new_promo['value']}% при пополнении Steam"
            elif promo_type == "first_order":
                new_promo["description"] = f"Скидка {new_promo['value']}% на первый заказ"
        
        elif promo_type == "free_game":
            new_promo["game_id"] = admin_states[user_id]["promo_game_id"]
            new_promo["min_order"] = admin_states[user_id]["promo_min_order"]
            
            game = next((g for g in games if g["id"] == new_promo["game_id"]), None)
            if game:
                new_promo["description"] = f"Бесплатная игра {game['title']} при заказе от {new_promo['min_order']} ₽"
        
        # Добавляем промокод в список
        promocodes[promo_code] = new_promo
        
        # Отправляем сообщение об успешном добавлении
        bot.send_message(
            message.chat.id,
            f"✅ Промокод *{promo_code}* успешно добавлен!\n\n"
            f"Тип: {new_promo['description']}\n"
            f"Минимальная сумма заказа: {new_promo.get('min_order', 0)} ₽\n"
            f"Срок действия: до {expires.strftime('%d.%m.%Y')}",
            parse_mode="Markdown"
        )
        
        # Очищаем состояние
        del admin_states[user_id]
        
        # Возвращаемся в меню управления промокодами
        bot.send_message(
            message.chat.id,
            "Выберите действие:",
            reply_markup=get_promo_management_keyboard()
        )

# Обработчик ввода текста для рассылки
def process_broadcast_message(message):
    user_id = message.from_user.id
    broadcast_text = message.text.strip()
    
    if not broadcast_text:
        bot.send_message(
            message.chat.id,
            "❌ Текст сообщения не может быть пустым. Пожалуйста, введите текст для рассылки:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_broadcast_message)
        return
    
    # Сохраняем текст рассылки
    admin_states[user_id]["broadcast_text"] = broadcast_text
    
    # Запрашиваем подтверждение
    markup = types.InlineKeyboardMarkup(row_width=2)
    yes_btn = types.InlineKeyboardButton("✅ Да, отправить", callback_data="admin_confirm_broadcast")
    no_btn = types.InlineKeyboardButton("❌ Нет, отмена", callback_data="admin_back_to_main")
    markup.add(yes_btn, no_btn)
    
    bot.send_message(
        message.chat.id,
        f"📢 *Подтверждение рассылки*\n\n"
        f"Текст сообщения:\n\n"
        f"{broadcast_text}\n\n"
        f"Вы уверены, что хотите отправить это сообщение?",
        parse_mode="Markdown",
        reply_markup=markup
    )

# Обработчик редактирования поля игры
def process_edit_game_field(message):
    user_id = message.from_user.id
    
    if "edit_game_id" not in admin_states[user_id] or "edit_field" not in admin_states[user_id]:
        bot.send_message(
            message.chat.id,
            "❌ Произошла ошибка. Пожалуйста, начните процесс редактирования заново.",
            parse_mode="Markdown"
        )
        return
    
    game_id = admin_states[user_id]["edit_game_id"]
    field = admin_states[user_id]["edit_field"]
    
    # Ищем игру по ID
    game = next((g for g in games if g["id"] == game_id), None)
    
    if not game:
        bot.send_message(
            message.chat.id,
            "❌ Игра не найдена.",
            parse_mode="Markdown"
        )
        return
    
    # Обновляем поле игры
    new_value = message.text.strip()
    
    # Преобразуем значение в зависимости от поля
    if field == "price":
        try:
            new_value = int(new_value)
        except ValueError:
            bot.send_message(
                message.chat.id,
                "❌ Некорректное значение для цены. Пожалуйста, введите число:",
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(message, process_edit_game_field)
            return
    
    elif field == "platforms":
        new_value = [platform.strip() for platform in new_value.split(",")]
    
    elif field == "discount":
        try:
            discount_percent = int(new_value)
            if discount_percent <= 0 or discount_percent >= 100:
                bot.send_message(
                    message.chat.id,
                    "❌ Некорректное значение для скидки. Пожалуйста, введите число от 1 до 99:",
                    parse_mode="Markdown"
                )
                bot.register_next_step_handler(message, process_edit_game_field)
                return
            
            # Вычисляем старую цену и устанавливаем скидку
            old_price = game["price"] * 100 // (100 - discount_percent)
            game["old_price"] = old_price
            game["discount"] = f"{discount_percent}%"
            
            bot.send_message(
                message.chat.id,
                f"✅ Скидка {discount_percent}% успешно установлена!\n"
                f"Старая цена: {old_price} ₽\n"
                f"Новая цена: {game['price']} ₽",
                parse_mode="Markdown"
            )
            
            # Очищаем состояние
            del admin_states[user_id]
            
            # Возвращаемся в меню управления играми
            bot.send_message(
                message.chat.id,
                "Выберите действие:",
                reply_markup=get_games_management_keyboard()
            )
            return
    
    # Обновляем поле
    if field == "name":
        game["title"] = new_value
    else:
        game[field] = new_value
    
    bot.send_message(
        message.chat.id,
        f"✅ Поле {field} успешно обновлено!",
        parse_mode="Markdown"
    )
    
    # Очищаем состояние
    del admin_states[user_id]
    
    # Возвращаемся в меню управления играми
    bot.send_message(
        message.chat.id,
        "Выберите действие:",
        reply_markup=get_games_management_keyboard()
    )

# Обработчик callback-запросов для настроек языка
@bot.callback_query_handler(func=lambda call: call.data.startswith("language_"))
def language_callback_handler(call):
    user_id = call.from_user.id
    language_code = call.data.replace("language_", "")
    
    # Проверяем, существует ли выбранный язык
    if language_code in languages:
        # Обновляем язык в настройках пользователя
        settings = get_user_settings(user_id)
        settings["language"] = language_code
        
        # Отправляем сообщение об успешном изменении языка
        bot.edit_message_text(
            get_localized_text("language_changed", user_id),
            call.message.chat.id,
            call.message.message_id,
            parse_mode="Markdown",
            reply_markup=get_settings_keyboard()
        )
    else:
        bot.answer_callback_query(
            call.id,
            "❌ Выбранный язык не поддерживается.",
            show_alert=True
        )

# Обработчик callback-запросов для обновления рекомендаций
@bot.callback_query_handler(func=lambda call: call.data == "refresh_recommendations")
def refresh_recommendations_handler(call):
    user_id = call.from_user.id
    
    # Удаляем текущие рекомендации
    if user_id in user_recommendations:
        del user_recommendations[user_id]
    
    # Показываем новые рекомендации
    bot.delete_message(call.message.chat.id, call.message.message_id)
    show_recommendations(call.message.chat.id, user_id)
    
    bot.answer_callback_query(
        call.id,
        "✅ Рекомендации обновлены!",
        show_alert=False
    )

# Обработчик callback-запросов для показа достижений
@bot.callback_query_handler(func=lambda call: call.data == "show_achievements")
def show_achievements_callback_handler(call):
    user_id = call.from_user.id
    
    # Проверяем достижения пользователя
    check_achievements(user_id)
    
    # Показываем достижения
    bot.delete_message(call.message.chat.id, call.message.message_id)
    show_user_achievements(call.message.chat.id, user_id)
    
    bot.answer_callback_query(call.id)

# Запуск бота
if __name__ == "__main__":
    # Проверяем наличие токена
    if not TOKEN:
        logger.error("Токен бота не указан. Пожалуйста, укажите токен в переменной TOKEN.")
        exit(1)
    
    logger.info("Бот запущен!")
    
    # Запускаем бота
    try:
        bot.polling(none_stop=True, interval=0)
    except Exception as e:
        logger.error(f"Ошибка при запуске бота: {e}")
