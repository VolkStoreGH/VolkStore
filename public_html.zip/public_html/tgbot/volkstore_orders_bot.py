import telebot
from telebot import types
import json
import os
from datetime import datetime

# Инициализация бота с вашим токеном (получите его у BotFather)
TOKEN = "7426865748:AAEIaIfAVo5SaSEWTYziDeElszTsmP-NmOs"  # Замените на ваш реальный токен
bot = telebot.TeleBot(TOKEN)

# Список администраторов, которые могут просматривать заказы
ADMIN_IDS = [5039264444]  # Замените на реальные ID администраторов

# Пути к файлам данных
ORDERS_FILE = 'user_orders.json'
GAMES_FILE = 'games.json'

# Функция для загрузки заказов из файла
def load_orders():
    try:
        if os.path.exists(ORDERS_FILE):
            with open(ORDERS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    except Exception as e:
        print(f"Ошибка при загрузке заказов: {e}")
        return {}

# Функция для загрузки игр из файла
def load_games():
    try:
        if os.path.exists(GAMES_FILE):
            with open(GAMES_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    except Exception as e:
        print(f"Ошибка при загрузке игр: {e}")
        return {}

# Функция для сохранения заказов в файл
def save_orders(orders):
    try:
        with open(ORDERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(orders, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"Ошибка при сохранении заказов: {e}")
        return False

# Функция для сохранения игр в файл
def save_games(games):
    try:
        with open(GAMES_FILE, 'w', encoding='utf-8') as f:
            json.dump(games, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"Ошибка при сохранении игр: {e}")
        return False

# Проверка, является ли пользователь администратором
def is_admin(user_id):
    return user_id in ADMIN_IDS

# Форматирование заказа для отображения
def format_order(order_id, order_data):
    items_text = ""
    for item in order_data["items"]:
        items_text += f"🎮 {item['title']} x{item['quantity']} - {item['price']} {order_data['currency']}\n"
    
    status_emoji = {
        "Оплачен": "✅",
        "Ожидает оплаты": "⏳",
        "Доставлен": "🚚",
        "Отменен": "❌"
    }
    
    status = order_data["status"]
    emoji = status_emoji.get(status, "🔄")
    
    # Формируем информацию о клиенте с дополнительными данными
    customer_info = (
        f"👤 *Информация о клиенте:*\n"
        f"  Имя: {order_data['customer']['name']}\n"
        f"  ID: {order_data['customer']['id']}\n"
        f"  Username: {order_data['customer'].get('username', 'Не указан')}\n"
    )
    
    # Добавляем дополнительную информацию, если она есть
    if 'email' in order_data['customer']:
        customer_info += f"  📧 Email: {order_data['customer']['email']}\n"
    if 'phone' in order_data['customer']:
        customer_info += f"  📱 Телефон: {order_data['customer']['phone']}\n"
    if 'address' in order_data['customer']:
        customer_info += f"  🏠 Адрес: {order_data['customer']['address']}\n"
    if 'comment' in order_data:
        customer_info += f"\n💬 *Комментарий клиента:*\n  {order_data['comment']}\n"
    
    return (
        f"🛍️ *Заказ #{order_id}*\n\n"
        f"{customer_info}\n"
        f"📅 *Информация о заказе:*\n"
        f"  Дата: {order_data['date']}\n"
        f"  Статус: {emoji} {status}\n\n"
        f"📦 *Товары:*\n{items_text}\n"
        f"💰 *Итого: {order_data['total']} {order_data['currency']}*"
    )

# Краткое форматирование заказа для списка
def format_order_short(order_id, order_data):
    status_emoji = {
        "Оплачен": "✅",
        "Ожидает оплаты": "⏳",
        "Доставлен": "🚚",
        "Отменен": "❌"
    }
    
    status = order_data["status"]
    emoji = status_emoji.get(status, "🔄")
    
    # Добавляем email в краткую информацию, если он есть
    email_info = ""
    if 'email' in order_data['customer']:
        email_info = f"📧 {order_data['customer']['email']}\n"
    
    return (
        f"🛍️ *Заказ #{order_id}*\n"
        f"👤 {order_data['customer']['name']}\n"
        f"{email_info}"
        f"📅 {order_data['date']}\n"
        f"💰 {order_data['total']} {order_data['currency']}\n"
        f"🔄 Статус: {emoji} {status}"
    )

# Форматирование игры для отображения
def format_game(game_id, game_data):
    return (
        f"🎮 *{game_data['title']}*\n"
        f"🆔 ID: {game_id}\n"
        f"💰 Цена: {game_data['price']} {game_data['currency']}\n"
        f"📦 В наличии: {'✅' if game_data['in_stock'] else '❌'}\n\n"
        f"📝 *Описание:*\n{game_data['description']}"
    )

# Краткое форматирование игры для списка
def format_game_short(game_id, game_data):
    return (
        f"🎮 *{game_data['title']}*\n"
        f"💰 {game_data['price']} {game_data['currency']}\n"
        f"📦 {('✅ В наличии' if game_data['in_stock'] else '❌ Нет в наличии')}"
    )

# Клавиатура главного меню
def get_main_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    
    # Кнопки для заказов
    all_orders_btn = types.KeyboardButton("📋 Все заказы")
    new_orders_btn = types.KeyboardButton("🆕 Новые заказы")
    paid_orders_btn = types.KeyboardButton("✅ Оплаченные")
    pending_orders_btn = types.KeyboardButton("⏳ Ожидающие оплаты")
    search_btn = types.KeyboardButton("🔍 Поиск заказа")
    
    # Кнопки для игр
    games_btn = types.KeyboardButton("🎮 Управление играми")
    
    # Общие кнопки
    stats_btn = types.KeyboardButton("📊 Статистика")
    refresh_btn = types.KeyboardButton("🔄 Обновить данные")
    
    markup.add(all_orders_btn, new_orders_btn, paid_orders_btn, pending_orders_btn, 
               search_btn, games_btn, stats_btn, refresh_btn)
    return markup

# Клавиатура для управления играми
def get_games_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    
    list_games_btn = types.KeyboardButton("📋 Список игр")
    add_game_btn = types.KeyboardButton("➕ Добавить игру")
    search_game_btn = types.KeyboardButton("🔍 Найти игру")
    back_btn = types.KeyboardButton("⬅️ Назад в главное меню")
    
    markup.add(list_games_btn, add_game_btn, search_game_btn, back_btn)
    return markup

# Клавиатура для управления заказом
def get_order_keyboard(order_id):
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    # Кнопки для изменения статуса
    paid_btn = types.InlineKeyboardButton("✅ Отметить как оплаченный", callback_data=f"status_{order_id}_paid")
    delivered_btn = types.InlineKeyboardButton("🚚 Отметить как доставленный", callback_data=f"status_{order_id}_delivered")
    cancel_btn = types.InlineKeyboardButton("❌ Отменить заказ", callback_data=f"status_{order_id}_cancelled")
    
    # Кнопка для связи с клиентом
    contact_btn = types.InlineKeyboardButton("📞 Связаться с клиентом", callback_data=f"contact_{order_id}")
    
    # Кнопка для возврата к списку заказов
    back_btn = types.InlineKeyboardButton("⬅️ Назад к списку", callback_data="back_to_list")
    
    markup.add(paid_btn, delivered_btn, cancel_btn, contact_btn, back_btn)
    return markup

# Клавиатура для управления игрой
def get_game_keyboard(game_id):
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    edit_btn = types.InlineKeyboardButton("✏️ Редактировать", callback_data=f"edit_game_{game_id}")
    toggle_stock_btn = types.InlineKeyboardButton("📦 Изменить наличие", callback_data=f"toggle_stock_{game_id}")
    delete_btn = types.InlineKeyboardButton("🗑️ Удалить", callback_data=f"delete_game_{game_id}")
    back_btn = types.InlineKeyboardButton("⬅️ Назад к списку", callback_data="back_to_games")
    
    markup.add(edit_btn, toggle_stock_btn, delete_btn, back_btn)
    return markup

# Обработчик команды /start
@bot.message_handler(commands=['start'])
def start_handler(message):
    user_id = message.from_user.id
    
    if is_admin(user_id):
        bot.send_message(
            message.chat.id,
            f"👋 Здравствуйте, {message.from_user.first_name}!\n\n"
            f"Добро пожаловать в панель администратора VolkStore.\n"
            f"Здесь вы можете просматривать и управлять заказами и играми магазина.\n\n"
            f"Используйте кнопки ниже для навигации:",
            reply_markup=get_main_keyboard()
        )
    else:
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )

# Обработчик команды /help
@bot.message_handler(commands=['help'])
def help_handler(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    help_text = (
        "📋 *Справка по панели администратора VolkStore*\n\n"
        "Этот бот позволяет администраторам просматривать и управлять заказами и играми магазина VolkStore.\n\n"
        "*Управление заказами:*\n"
        "/orders - Показать все заказы\n"
        "/new - Показать новые заказы\n"
        "/paid - Показать оплаченные заказы\n"
        "/pending - Показать ожидающие оплаты заказы\n"
        "/search - Поиск заказа по номеру или имени клиента\n\n"
        "*Управление играми:*\n"
        "/games - Показать список игр\n"
        "/addgame - Добавить новую игру\n"
        "/searchgame - Найти игру по названию\n\n"
        "*Общие команды:*\n"
        "/stats - Показать статистику заказов и игр\n"
        "/refresh - Обновить данные заказов и игр\n\n"
        "Вы также можете использовать кнопки меню для навигации."
    )
    
    bot.send_message(message.chat.id, help_text, parse_mode="Markdown")

# Обработчик команды /orders и кнопки "Все заказы"
@bot.message_handler(commands=['orders'])
@bot.message_handler(func=lambda message: message.text == "📋 Все заказы")
def all_orders_handler(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    # Загружаем заказы
    orders = load_orders()
    
    if not orders:
        bot.send_message(
            message.chat.id,
            "📋 Заказов пока нет. Нажмите '🔄 Обновить данные', чтобы проверить наличие новых заказов."
        )
        return
    
    bot.send_message(
        message.chat.id,
        f"📋 *Список всех заказов ({len(orders)}):*",
        parse_mode="Markdown"
    )
    
    # Сортируем заказы по дате (новые сначала)
    sorted_orders = sorted(orders.items(), key=lambda x: x[1]["date"], reverse=True)
    
    # Отправляем список заказов
    for order_id, order_data in sorted_orders:
        order_text = format_order_short(order_id, order_data)
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        details_btn = types.InlineKeyboardButton("🔍 Подробнее", callback_data=f"details_{order_id}")
        markup.add(details_btn)
        
        bot.send_message(
            message.chat.id,
            order_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик команды /games и кнопки "Управление играми"
@bot.message_handler(commands=['games'])
@bot.message_handler(func=lambda message: message.text == "🎮 Управление играми")
def games_menu_handler(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    bot.send_message(
        message.chat.id,
        "🎮 *Управление играми*\n\n"
        "Выберите действие из меню ниже:",
        parse_mode="Markdown",
        reply_markup=get_games_keyboard()
    )

# Обработчик кнопки "Список игр"
@bot.message_handler(func=lambda message: message.text == "📋 Список игр")
def list_games_handler(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    # Загружаем игры
    games = load_games()
    
    if not games:
        bot.send_message(
            message.chat.id,
            "📋 Игр пока нет в базе данных. Используйте кнопку '➕ Добавить игру', чтобы добавить новую игру."
        )
        return
    
    bot.send_message(
        message.chat.id,
        f"📋 *Список всех игр ({len(games)}):*",
        parse_mode="Markdown"
    )
    
    # Сортируем игры по названию
    sorted_games = sorted(games.items(), key=lambda x: x[1]["title"])
    
    # Отправляем список игр
    for game_id, game_data in sorted_games:
        game_text = format_game_short(game_id, game_data)
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        details_btn = types.InlineKeyboardButton("🔍 Подробнее", callback_data=f"game_details_{game_id}")
        markup.add(details_btn)
        
        bot.send_message(
            message.chat.id,
            game_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик кнопки "Добавить игру"
@bot.message_handler(commands=['addgame'])
@bot.message_handler(func=lambda message: message.text == "➕ Добавить игру")
def add_game_handler(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    bot.send_message(
        message.chat.id,
        "🎮 *Добавление новой игры*\n\n"
        "Введите название игры:",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_game_title)

# Обработчик ввода названия игры
def process_game_title(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    # Сохраняем название игры во временный словарь
    chat_id = message.chat.id
    title = message.text.strip()
    
    # Создаем временный словарь для хранения данных игры
    user_data = {}
    user_data[chat_id] = {"title": title}
    
    bot.send_message(
        chat_id,
        f"🎮 Название игры: *{title}*\n\n"
        f"Теперь введите цену игры (только число):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, process_game_price, user_data)

# Обработчик ввода цены игры
def process_game_price(message, user_data):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    if not is_admin(user_id):
        bot.send_message(
            chat_id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    try:
        price = float(message.text.strip())
        user_data[chat_id]["price"] = price
        
        bot.send_message(
            chat_id,
            f"🎮 Название: *{user_data[chat_id]['title']}*\n"
            f"💰 Цена: *{price} RUB*\n\n"
            f"Теперь введите описание игры:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(message, process_game_description, user_data)
    except ValueError:
        bot.send_message(
            chat_id,
            "❌ Ошибка! Цена должна быть числом. Попробуйте еще раз:"
        )
        bot.register_next_step_handler(message, process_game_price, user_data)

# Обработчик ввода описания игры
def process_game_description(message, user_data):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    if not is_admin(user_id):
        bot.send_message(
            chat_id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    description = message.text.strip()
    user_data[chat_id]["description"] = description
    
    # Создаем клавиатуру для выбора наличия
    markup = types.InlineKeyboardMarkup(row_width=2)
    yes_btn = types.InlineKeyboardButton("✅ Да", callback_data="game_stock_yes")
    no_btn = types.InlineKeyboardButton("❌ Нет", callback_data="game_stock_no")
    markup.add(yes_btn, no_btn)
    
    bot.send_message(
        chat_id,
        f"🎮 Название: *{user_data[chat_id]['title']}*\n"
        f"💰 Цена: *{user_data[chat_id]['price']} RUB*\n"
        f"📝 Описание: {description}\n\n"
        f"Игра есть в наличии?",
        parse_mode="Markdown",
        reply_markup=markup
    )
    
    # Сохраняем данные игры для использования в callback
    bot.register_next_step_handler_by_chat_id = user_data

# Обработчик команды /new и кнопки "Новые заказы"
@bot.message_handler(commands=['new'])
@bot.message_handler(func=lambda message: message.text == "🆕 Новые заказы")
def new_orders_handler(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    # Загружаем заказы
    orders = load_orders()
    
    if not orders:
        bot.send_message(
            message.chat.id,
            "📋 Заказов пока нет. Нажмите '🔄 Обновить данные', чтобы проверить наличие новых заказов."
        )
        return
    
    # Фильтруем новые заказы (за последние 24 часа)
    today = datetime.now().strftime("%d.%m.%Y")
    new_orders = {order_id: order_data for order_id, order_data in orders.items() 
                 if order_data["date"].startswith(today)}
    
    if not new_orders:
        bot.send_message(
            message.chat.id,
            f"🆕 Новых заказов за сегодня ({today}) нет."
        )
        return
    
    bot.send_message(
        message.chat.id,
        f"🆕 *Новые заказы за сегодня ({today}):*",
        parse_mode="Markdown"
    )
    
    # Сортируем заказы по дате (новые сначала)
    sorted_orders = sorted(new_orders.items(), key=lambda x: x[1]["date"], reverse=True)
    
    # Отправляем список новых заказов
    for order_id, order_data in sorted_orders:
        order_text = format_order_short(order_id, order_data)
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        details_btn = types.InlineKeyboardButton("🔍 Подробнее", callback_data=f"details_{order_id}")
        markup.add(details_btn)
        
        bot.send_message(
            message.chat.id,
            order_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик команды /paid и кнопки "Оплаченные"
@bot.message_handler(commands=['paid'])
@bot.message_handler(func=lambda message: message.text == "✅ Оплаченные")
def paid_orders_handler(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    # Загружаем заказы
    orders = load_orders()
    
    if not orders:
        bot.send_message(
            message.chat.id,
            "📋 Заказов пока нет. Нажмите '🔄 Обновить данные', чтобы проверить наличие новых заказов."
        )
        return
    
    # Фильтруем оплаченные заказы
    paid_orders = {order_id: order_data for order_id, order_data in orders.items() 
                  if order_data["status"] == "Оплачен"}
    
    if not paid_orders:
        bot.send_message(
            message.chat.id,
            "✅ Оплаченных заказов нет."
        )
        return
    
    bot.send_message(
        message.chat.id,
        f"✅ *Оплаченные заказы ({len(paid_orders)}):*",
        parse_mode="Markdown"
    )
    
    # Сортируем заказы по дате (новые сначала)
    sorted_orders = sorted(paid_orders.items(), key=lambda x: x[1]["date"], reverse=True)
    
    # Отправляем список оплаченных заказов
    for order_id, order_data in sorted_orders:
        order_text = format_order_short(order_id, order_data)
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        details_btn = types.InlineKeyboardButton("🔍 Подробнее", callback_data=f"details_{order_id}")
        markup.add(details_btn)
        
        bot.send_message(
            message.chat.id,
            order_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик команды /pending и кнопки "Ожидающие оплаты"
@bot.message_handler(commands=['pending'])
@bot.message_handler(func=lambda message: message.text == "⏳ Ожидающие оплаты")
def pending_orders_handler(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    # Загружаем заказы
    orders = load_orders()
    
    if not orders:
        bot.send_message(
            message.chat.id,
            "📋 Заказов пока нет. Нажмите '🔄 Обновить данные', чтобы проверить наличие новых заказов."
        )
        return
    
    # Фильтруем ожидающие оплаты заказы
    pending_orders = {order_id: order_data for order_id, order_data in orders.items() 
                     if order_data["status"] == "Ожидает оплаты"}
    
    if not pending_orders:
        bot.send_message(
            message.chat.id,
            "⏳ Заказов, ожидающих оплаты, нет."
        )
        return
    
    bot.send_message(
        message.chat.id,
        f"⏳ *Заказы, ожидающие оплаты ({len(pending_orders)}):*",
        parse_mode="Markdown"
    )
    
    # Сортируем заказы по дате (новые сначала)
    sorted_orders = sorted(pending_orders.items(), key=lambda x: x[1]["date"], reverse=True)
    
    # Отправляем список ожидающих оплаты заказов
    for order_id, order_data in sorted_orders:
        order_text = format_order_short(order_id, order_data)
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        details_btn = types.InlineKeyboardButton("🔍 Подробнее", callback_data=f"details_{order_id}")
        markup.add(details_btn)
        
        bot.send_message(
            message.chat.id,
            order_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик кнопки "Найти игру"
@bot.message_handler(commands=['searchgame'])
@bot.message_handler(func=lambda message: message.text == "🔍 Найти игру")
def search_game_prompt(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    bot.send_message(
        message.chat.id,
        "🔍 Введите название игры для поиска:"
    )
    bot.register_next_step_handler(message, search_games)

def search_games(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    query = message.text.lower()
    
    # Загружаем игры
    games = load_games()
    
    if not games:
        bot.send_message(
            message.chat.id,
            "📋 Игр пока нет в базе данных. Используйте кнопку '➕ Добавить игру', чтобы добавить новую игру."
        )
        return
    
    # Ищем игры по названию
    search_results = {game_id: game_data for game_id, game_data in games.items() 
                     if query in game_data["title"].lower()}
    
    if not search_results:
        bot.send_message(
            message.chat.id,
            f"🔍 По запросу '{message.text}' ничего не найдено."
        )
        return
    
    bot.send_message(
        message.chat.id,
        f"🔍 *Результаты поиска по запросу '{message.text}' ({len(search_results)}):*",
        parse_mode="Markdown"
    )
    
    # Сортируем результаты по названию
    sorted_results = sorted(search_results.items(), key=lambda x: x[1]["title"])
    
    # Отправляем результаты поиска
    for game_id, game_data in sorted_results:
        game_text = format_game_short(game_id, game_data)
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        details_btn = types.InlineKeyboardButton("🔍 Подробнее", callback_data=f"game_details_{game_id}")
        markup.add(details_btn)
        
        bot.send_message(
            message.chat.id,
            game_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик команды /search и кнопки "Поиск заказа"
@bot.message_handler(commands=['search'])
@bot.message_handler(func=lambda message: message.text == "🔍 Поиск заказа")
def search_prompt(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    bot.send_message(
        message.chat.id,
        "🔍 Введите номер заказа, имя клиента или email для поиска:"
    )
    bot.register_next_step_handler(message, search_orders)

def search_orders(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    query = message.text.lower()
    
    # Загружаем заказы
    orders = load_orders()
    
    if not orders:
        bot.send_message(
            message.chat.id,
            "📋 Заказов пока нет. Нажмите '🔄 Обновить данные', чтобы проверить наличие новых заказов."
        )
        return
    
    # Ищем заказы по номеру, имени клиента или email
    search_results = {}
    for order_id, order_data in orders.items():
        customer = order_data["customer"]
        if (query in order_id.lower() or 
            query in customer["name"].lower() or 
            (customer.get("username") and query in customer["username"].lower()) or
            (customer.get("email") and query in customer["email"].lower()) or
            (customer.get("phone") and query in customer["phone"].lower())):
            search_results[order_id] = order_data
    
    if not search_results:
        bot.send_message(
            message.chat.id,
            f"🔍 По запросу '{message.text}' ничего не найдено."
        )
        return
    
    bot.send_message(
        message.chat.id,
        f"🔍 *Результаты поиска по запросу '{message.text}' ({len(search_results)}):*",
        parse_mode="Markdown"
    )
    
    # Сортируем результаты по дате (новые сначала)
    sorted_results = sorted(search_results.items(), key=lambda x: x[1]["date"], reverse=True)
    
    # Отправляем результаты поиска
    for order_id, order_data in sorted_results:
        order_text = format_order_short(order_id, order_data)
        
        markup = types.InlineKeyboardMarkup(row_width=1)
        details_btn = types.InlineKeyboardButton("🔍 Подробнее", callback_data=f"details_{order_id}")
        markup.add(details_btn)
        
        bot.send_message(
            message.chat.id,
            order_text,
            parse_mode="Markdown",
            reply_markup=markup
        )

# Обработчик команды /stats и кнопки "Статистика"
@bot.message_handler(commands=['stats'])
@bot.message_handler(func=lambda message: message.text == "📊 Статистика")
def stats_handler(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    # Загружаем заказы и игры
    orders = load_orders()
    games = load_games()
    
    if not orders and not games:
        bot.send_message(
            message.chat.id,
            "📋 Заказов и игр пока нет. Нажмите '🔄 Обновить данные', чтобы проверить наличие новых данных."
        )
        return
    
    # Статистика заказов
    orders_stats = ""
    if orders:
        # Подсчет статистики
        total_orders = len(orders)
        total_revenue = sum(order_data["total"] for order_data in orders.values())
        
        # Статусы заказов
        status_counts = {
            "Оплачен": 0,
            "Ожидает оплаты": 0,
            "Доставлен": 0,
            "Отменен": 0
        }
        
        for order_data in orders.values():
            status = order_data["status"]
            if status in status_counts:
                status_counts[status] += 1
            else:
                status_counts[status] = 1
        
        # Популярные игры
        game_counts = {}
        for order_data in orders.values():
            for item in order_data["items"]:
                game_title = item["title"]
                quantity = item["quantity"]
                if game_title in game_counts:
                    game_counts[game_title] += quantity
                else:
                    game_counts[game_title] = quantity
        
        # Сортируем игры по популярности
        popular_games = sorted(game_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        
        # Формируем текст статистики заказов
        orders_stats = (
            f"📊 *Статистика заказов:*\n\n"
            f"📦 Всего заказов: {total_orders}\n"
            f"💰 Общая выручка: {total_revenue} RUB\n\n"
            f"*Статусы заказов:*\n"
            f"✅ Оплачено: {status_counts.get('Оплачен', 0)}\n"
            f"⏳ Ожидает оплаты: {status_counts.get('Ожидает оплаты', 0)}\n"
            f"🚚 Доставлено: {status_counts.get('Доставлен', 0)}\n"
            f"❌ Отменено: {status_counts.get('Отменен', 0)}\n\n"
            f"*Топ-5 популярных игр:*\n"
        )
        
        for i, (game, count) in enumerate(popular_games, 1):
            orders_stats += f"{i}. {game}: {count} шт.\n"
    
    # Статистика игр
    games_stats = ""
    if games:
        total_games = len(games)
        in_stock_games = sum(1 for game in games.values() if game["in_stock"])
        out_of_stock_games = total_games - in_stock_games
        
        # Средняя цена игр
        avg_price = sum(game["price"] for game in games.values()) / total_games if total_games > 0 else 0
        
        # Формируем текст статистики игр
        games_stats = (
            f"\n\n📊 *Статистика игр:*\n\n"
            f"🎮 Всего игр в каталоге: {total_games}\n"
            f"✅ Игр в наличии: {in_stock_games}\n"
            f"❌ Игр не в наличии: {out_of_stock_games}\n"
            f"💰 Средняя цена: {avg_price:.2f} RUB\n"
        )
    
    # Отправляем статистику
    bot.send_message(
        message.chat.id,
        f"📊 *Общая статистика VolkStore*\n\n{orders_stats}{games_stats}",
        parse_mode="Markdown"
    )

# Обработчик команды /refresh и кнопки "Обновить данные"
@bot.message_handler(commands=['refresh'])
@bot.message_handler(func=lambda message: message.text == "🔄 Обновить данные")
def refresh_handler(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    # В реальном боте здесь была бы синхронизация с базой данных VolkStore
    # Для примера просто перезагружаем данные из файла
    orders_count = sync_with_volkstore()
    games_count = sync_games()
    
    bot.send_message(
        message.chat.id,
        f"🔄 Данные обновлены.\n"
        f"📦 Загружено {orders_count} заказов.\n"
        f"🎮 Загружено {games_count} игр."
    )

# Обработчик кнопки "Назад в главное меню"
@bot.message_handler(func=lambda message: message.text == "⬅️ Назад в главное меню")
def back_to_main_menu(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    bot.send_message(
        message.chat.id,
        "Главное меню:",
        reply_markup=get_main_keyboard()
    )

# Обработчик callback-запросов
@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    user_id = call.from_user.id
    
    if not is_admin(user_id):
        bot.answer_callback_query(call.id, "⚠️ У вас нет доступа к этой функции.")
        return
    
    # Загружаем заказы и игры
    orders = load_orders()
    games = load_games()
    
    # Обработка наличия игры при добавлении
    if call.data.startswith("game_stock_"):
        in_stock = call.data == "game_stock_yes"
        chat_id = call.message.chat.id
        
        # Получаем данные игры из временного хранилища
        user_data = getattr(bot, "register_next_step_handler_by_chat_id", {})
        if chat_id not in user_data:
            bot.answer_callback_query(call.id, "❌ Ошибка! Данные игры не найдены.")
            return
        
        game_data = user_data[chat_id]
        game_data["in_stock"] = in_stock
        game_data["currency"] = "RUB"
        
        # Генерируем уникальный ID для игры
        game_id = f"GAME-{datetime.now().strftime('%Y%m%d')}-{len(games) + 1:03d}"
        
        # Добавляем игру в базу данных
        games[game_id] = game_data
        save_games(games)
        
        # Очищаем временное хранилище
        del user_data[chat_id]
        
        bot.answer_callback_query(call.id, "✅ Игра успешно добавлена!")
        
        # Отправляем информацию о добавленной игре
        game_text = format_game(game_id, game_data)
        
        bot.send_message(
            chat_id,
            f"✅ *Игра успешно добавлена!*\n\n{game_text}",
            parse_mode="Markdown",
            reply_markup=get_game_keyboard(game_id)
        )
    
    # Просмотр деталей игры
    elif call.data.startswith("game_details_"):
        game_id = call.data.split("_")[2]
        
        if game_id in games:
            game_data = games[game_id]
            game_text = format_game(game_id, game_data)
            
            bot.send_message(
                call.message.chat.id,
                game_text,
                parse_mode="Markdown",
                reply_markup=get_game_keyboard(game_id)
            )
        else:
            bot.answer_callback_query(call.id, "⚠️ Игра не найдена.")
    
    # Редактирование игры
    elif call.data.startswith("edit_game_"):
        game_id = call.data.split("_")[2]
        
        if game_id in games:
            # Сохраняем ID игры для последующего редактирования
            chat_id = call.message.chat.id
            user_data = {}
            user_data[chat_id] = {"game_id": game_id}
            
            bot.send_message(
                chat_id,
                f"✏️ *Редактирование игры #{game_id}*\n\n"
                f"Введите новое название игры (или 'skip' чтобы оставить текущее):",
                parse_mode="Markdown"
            )
            bot.register_next_step_handler(call.message, edit_game_title, user_data, games[game_id])
        else:
            bot.answer_callback_query(call.id, "⚠️ Игра не найдена.")
    
    # Изменение наличия игры
    elif call.data.startswith("toggle_stock_"):
        game_id = call.data.split("_")[2]
        
        if game_id in games:
            # Меняем статус наличия на противоположный
            games[game_id]["in_stock"] = not games[game_id]["in_stock"]
            save_games(games)
            
            new_status = "в наличии" if games[game_id]["in_stock"] else "нет в наличии"
            bot.answer_callback_query(call.id, f"✅ Статус изменен: {new_status}")
            
            # Отправляем обновленную информацию об игре
            game_text = format_game(game_id, games[game_id])
            
            bot.send_message(
                call.message.chat.id,
                f"✅ Статус наличия игры изменен на: {new_status}\n\n{game_text}",
                parse_mode="Markdown",
                reply_markup=get_game_keyboard(game_id)
            )
        else:
            bot.answer_callback_query(call.id, "⚠️ Игра не найдена.")
    
    # Удаление игры
    elif call.data.startswith("delete_game_"):
        game_id = call.data.split("_")[2]
        
        if game_id in games:
            # Создаем клавиатуру для подтверждения удаления
            markup = types.InlineKeyboardMarkup(row_width=2)
            yes_btn = types.InlineKeyboardButton("✅ Да, удалить", callback_data=f"confirm_delete_{game_id}")
            no_btn = types.InlineKeyboardButton("❌ Нет, отмена", callback_data=f"game_details_{game_id}")
            markup.add(yes_btn, no_btn)
            
            bot.send_message(
                call.message.chat.id,
                f"⚠️ *Вы уверены, что хотите удалить игру?*\n\n"
                f"🎮 {games[game_id]['title']}\n"
                f"🆔 {game_id}\n\n"
                f"Это действие нельзя отменить!",
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            bot.answer_callback_query(call.id, "⚠️ Игра не найдена.")
    
    # Подтверждение удаления игры
    elif call.data.startswith("confirm_delete_"):
        game_id = call.data.split("_")[2]
        
        if game_id in games:
            game_title = games[game_id]["title"]
            del games[game_id]
            save_games(games)
            
            bot.answer_callback_query(call.id, "✅ Игра успешно удалена!")
            
            bot.send_message(
                call.message.chat.id,
                f"✅ Игра *{game_title}* (ID: {game_id}) успешно удалена!",
                parse_mode="Markdown"
            )
            
            # Возвращаемся к списку игр
            list_games_handler(call.message)
        else:
            bot.answer_callback_query(call.id, "⚠️ Игра не найдена.")
    
    # Возврат к списку игр
    elif call.data == "back_to_games":
        list_games_handler(call.message)
    
    # Просмотр деталей заказа
    elif call.data.startswith("details_"):
        order_id = call.data.split("_")[1]
        
        if order_id in orders:
            order_data = orders[order_id]
            order_text = format_order(order_id, order_data)
            
            bot.send_message(
                call.message.chat.id,
                order_text,
                parse_mode="Markdown",
                reply_markup=get_order_keyboard(order_id)
            )
        else:
            bot.answer_callback_query(call.id, "⚠️ Заказ не найден.")
    
    # Изменение статуса заказа
    elif call.data.startswith("status_"):
        parts = call.data.split("_")
        order_id = parts[1]
        new_status = parts[2]
        
        if order_id in orders:
            order_data = orders[order_id]
            
            status_map = {
                "paid": "Оплачен",
                "delivered": "Доставлен",
                "cancelled": "Отменен"
            }
            
            if new_status in status_map:
                # Обновляем статус заказа
                order_data["status"] = status_map[new_status]
                
                # Сохраняем изменения
                save_orders(orders)
                
                bot.answer_callback_query(call.id, f"✅ Статус заказа изменен на: {status_map[new_status]}")
                
                # Отправляем обновленные детали заказа
                order_text = format_order(order_id, order_data)
                
                bot.send_message(
                    call.message.chat.id,
                    f"✅ Статус заказа #{order_id} изменен на: {status_map[new_status]}\n\n" + order_text,
                    parse_mode="Markdown",
                    reply_markup=get_order_keyboard(order_id)
                )
        else:
            bot.answer_callback_query(call.id, "⚠️ Заказ не найден.")
    
    # Связь с клиентом
    elif call.data.startswith("contact_"):
        order_id = call.data.split("_")[1]
        
        if order_id in orders:
            order_data = orders[order_id]
            customer = order_data["customer"]
            
            contact_text = (
                f"📞 *Контактная информация клиента:*\n\n"
                f"👤 Имя: {customer['name']}\n"
                f"🆔 ID: {customer['id']}\n"
                f"👤 Username: {customer.get('username', 'Не указан')}\n"
            )
            
            # Добавляем дополнительную контактную информацию, если она есть
            if 'email' in customer:
                contact_text += f"📧 Email: {customer['email']}\n"
            if 'phone' in customer:
                contact_text += f"📱 Телефон: {customer['phone']}\n"
            if 'address' in customer:
                contact_text += f"🏠 Адрес: {customer['address']}\n"
            
            # Добавляем кнопки для связи с клиентом
            markup = types.InlineKeyboardMarkup(row_width=1)
            
            if 'phone' in customer:
                call_btn = types.InlineKeyboardButton("📞 Позвонить", callback_data=f"call_{order_id}")
                markup.add(call_btn)
            
            if 'email' in customer:
                email_btn = types.InlineKeyboardButton("📧 Написать на почту", callback_data=f"email_{order_id}")
                markup.add(email_btn)
            
            back_btn = types.InlineKeyboardButton("⬅️ Назад к заказу", callback_data=f"details_{order_id}")
            markup.add(back_btn)
            
            bot.send_message(
                call.message.chat.id,
                contact_text,
                parse_mode="Markdown",
                reply_markup=markup
            )
        else:
            bot.answer_callback_query(call.id, "⚠️ Заказ не найден.")
    
    # Возврат к списку заказов
    elif call.data == "back_to_list":
        all_orders_handler(call.message)

# Функция для редактирования названия игры
def edit_game_title(message, user_data, old_game_data):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    if not is_admin(user_id):
        bot.send_message(
            chat_id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    title = message.text.strip()
    
    if title.lower() == 'skip':
        title = old_game_data["title"]
    
    user_data[chat_id]["title"] = title
    
    bot.send_message(
        chat_id,
        f"✏️ Название игры: *{title}*\n\n"
        f"Введите новую цену игры (или 'skip' чтобы оставить текущую):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, edit_game_price, user_data, old_game_data)

# Функция для редактирования цены игры
def edit_game_price(message, user_data, old_game_data):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    if not is_admin(user_id):
        bot.send_message(
            chat_id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    price_text = message.text.strip()
    
    if price_text.lower() == 'skip':
        price = old_game_data["price"]
    else:
        try:
            price = float(price_text)
            if price < 0:
                bot.send_message(
                    chat_id,
                    "❌ Ошибка! Цена не может быть отрицательной. Попробуйте еще раз:"
                )
                bot.register_next_step_handler(message, edit_game_price, user_data, old_game_data)
                return
        except ValueError:
            bot.send_message(
                chat_id,
                "❌ Ошибка! Цена должна быть числом. Попробуйте еще раз:"
            )
            bot.register_next_step_handler(message, edit_game_price, user_data, old_game_data)
            return
    
    user_data[chat_id]["price"] = price
    
    bot.send_message(
        chat_id,
        f"✏️ Название: *{user_data[chat_id]['title']}*\n"
        f"💰 Цена: *{price} RUB*\n\n"
        f"Введите новое описание игры (или 'skip' чтобы оставить текущее):",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, edit_game_description, user_data, old_game_data)

# Функция для редактирования описания игры
def edit_game_description(message, user_data, old_game_data):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    if not is_admin(user_id):
        bot.send_message(
            chat_id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    description = message.text.strip()
    
    if description.lower() == 'skip':
        description = old_game_data["description"]
    
    user_data[chat_id]["description"] = description
    
    # Создаем клавиатуру для выбора наличия
    markup = types.InlineKeyboardMarkup(row_width=2)
    yes_btn = types.InlineKeyboardButton("✅ В наличии", callback_data=f"edit_stock_yes_{user_data[chat_id]['game_id']}")
    no_btn = types.InlineKeyboardButton("❌ Нет в наличии", callback_data=f"edit_stock_no_{user_data[chat_id]['game_id']}")
    skip_btn = types.InlineKeyboardButton("⏭️ Оставить как есть", callback_data=f"edit_stock_skip_{user_data[chat_id]['game_id']}")
    markup.add(yes_btn, no_btn, skip_btn)
    
    bot.send_message(
        chat_id,
        f"✏️ Название: *{user_data[chat_id]['title']}*\n"
        f"💰 Цена: *{user_data[chat_id]['price']} RUB*\n"
        f"📝 Описание: {description}\n\n"
        f"Изменить наличие игры?",
        parse_mode="Markdown",
        reply_markup=markup
    )
    
    # Сохраняем данные игры для использования в callback
    bot.register_next_step_handler_by_chat_id = user_data

# Обработчик неизвестных сообщений
@bot.message_handler(func=lambda message: True)
def unknown_message(message):
    user_id = message.from_user.id
    
    if not is_admin(user_id):
        bot.send_message(
            message.chat.id,
            "⚠️ У вас нет доступа к этому боту. Только администраторы могут использовать эту панель управления."
        )
        return
    
    bot.send_message(
        message.chat.id,
        "Я не понимаю эту команду. Используйте кнопки меню или введите /help для получения списка доступных команд.",
        reply_markup=get_main_keyboard()
    )

# Функция для синхронизации с основным ботом VolkStore
def sync_with_volkstore():
    # В реальной реализации здесь был бы код для получения данных из базы данных VolkStore
    # Для примера создадим тестовые данные с расширенной информацией о клиентах
    
    test_orders = {
        "ORD-20250321-123456-789": {
            "customer": {
                "id": 123456,
                "name": "Иван Петров",
                "username": "@ivanpetrov",
                "email": "ivan.petrov@example.com",
                "phone": "+7 (999) 123-45-67",
                "address": "г. Москва, ул. Пушкина, д. 10, кв. 15"
            },
            "date": "21.03.2025 10:15",
            "items": [
                {"title": "Cyberpunk 2077", "quantity": 1, "price": 5499},
                {"title": "Elden Ring", "quantity": 1, "price": 3599}
            ],
            "total": 9098,
            "currency": "RUB",
            "status": "Оплачен",
            "comment": "Хочу получить как можно скорее!"
        },
        "ORD-20250320-654321-987": {
            "customer": {
                "id": 654321,
                "name": "Мария Сидорова",
                "username": "@mariasid",
                "email": "maria.sidorova@example.com",
                "phone": "+7 (999) 987-65-43"
            },
            "date": "20.03.2025 18:30",
            "items": [
                {"title": "God of War", "quantity": 1, "price": 4499}
            ],
            "total": 4499,
            "currency": "RUB",
            "status": "Ожидает оплаты"
        },
        "ORD-20250319-111222-333": {
            "customer": {
                "id": 111222,
                "name": "Алексей Иванов",
                "username": "@alexivanov",
                "email": "alex.ivanov@example.com"
            },
            "date": "19.03.2025 14:15",
            "items": [
                {"title": "Red Dead Redemption 2", "quantity": 1, "price": 2499},
                {"title": "Detroit: Become Human", "quantity": 1, "price": 390}
            ],
            "total": 2889,
            "currency": "RUB",
            "status": "Оплачен",
            "comment": "Подарок для брата"
        },
        "ORD-20250318-444555-666": {
            "customer": {
                "id": 444555,
                "name": "Екатерина Смирнова",
                "username": "@katesmirn",
                "phone": "+7 (999) 555-44-33",
                "address": "г. Санкт-Петербург, Невский пр-т, д. 100, кв. 42"
            },
            "date": "18.03.2025 09:20",
            "items": [
                {"title": "The Last of Us Part II", "quantity": 1, "price": 3999}
            ],
            "total": 3999,
            "currency": "RUB",
            "status": "Доставлен"
        }
    }
    
    # Сохраняем тестовые данные в файл
    save_orders(test_orders)
    return len(test_orders)

# Функция для синхронизации игр
def sync_games():
    # В реальной реализации здесь был бы код для получения данных из базы данных VolkStore
    # Для примера создадим тестовые данные игр
    
    test_games = {
        "GAME-20250321-001": {
            "title": "Cyberpunk 2077",
            "price": 5499,
            "currency": "RUB",
            "description": "Cyberpunk 2077 — приключенческая ролевая игра с открытым миром, рассказывающая о киберпанке-наёмнике Ви и борьбе за жизнь в мегаполисе Найт-Сити.",
            "in_stock": True
        },
        "GAME-20250321-002": {
            "title": "Elden Ring",
            "price": 3599,
            "currency": "RUB",
            "description": "Elden Ring — компьютерная игра в жанре action/RPG с открытым миром, разработанная японской компанией FromSoftware и изданная компанией Bandai Namco Entertainment.",
            "in_stock": True
        },
        "GAME-20250321-003": {
            "title": "God of War",
            "price": 4499,
            "currency": "RUB",
            "description": "God of War — компьютерная игра в жанре action-adventure, разработанная компанией Santa Monica Studio и изданная Sony Interactive Entertainment для платформы PlayStation 4.",
            "in_stock": True
        },
        "GAME-20250321-004": {
            "title": "Red Dead Redemption 2",
            "price": 2499,
            "currency": "RUB",
            "description": "Red Dead Redemption 2 — компьютерная игра в жанрах action-adventure и шутера от третьего лица с открытым миром, разработанная Rockstar Studios.",
            "in_stock": False
        },
        "GAME-20250321-005": {
            "title": "The Last of Us Part II",
            "price": 3999,
            "currency": "RUB",
            "description": "The Last of Us Part II — компьютерная игра в жанре приключенческого боевика с элементами survival horror и стелс-экшена от третьего лица, разработанная Naughty Dog.",
            "in_stock": True
        }
    }
    
    # Сохраняем тестовые данные в файл
    save_games(test_games)
    return len(test_games)

# Инициализация: синхронизируем данные при запуске бота
print("Запуск панели администратора VolkStore...")
orders_count = sync_with_volkstore()
games_count = sync_games()
print(f"Загружено {orders_count} заказов и {games_count} игр.")

# Запуск бота
if __name__ == "__main__":
    bot.polling(none_stop=True)